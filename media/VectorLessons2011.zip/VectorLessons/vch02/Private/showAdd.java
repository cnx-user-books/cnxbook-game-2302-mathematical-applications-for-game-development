// showTranspose.java --- demonstrate transpose of 3 element vector 
//
// applet should set size to width=300 height=200

// <applet code=showAdd width=300 height=200>
// <param name=xvalue value=> 
// <param name=yvalue value=> 
// <param name=zvalue value=>
// </applet>

import java.awt.* ;
import java.applet.*;
import java.lang.Math;

public class showAdd extends Applet 
{
 
  // components
  Label      axL  = new Label("A0");
  TextField  axTF = new TextField(  7);
  Label      ayL  = new Label("A1");
  TextField  ayTF = new TextField(  7);
  Label      azL  = new Label("A2");
  TextField  azTF = new TextField(  7);

  Label      bxL  = new Label("B0");
  TextField  bxTF = new TextField(  7);
  Label      byL  = new Label("B1");
  TextField  byTF = new TextField(  7);
  Label      bzL  = new Label("B2");
  TextField  bzTF = new TextField(  7);

  Label      cxL  = new Label("C0");
  TextField  cxTF = new TextField(  7);
  Label      cyL  = new Label("C1");
  TextField  cyTF = new TextField(  7);
  Label      czL  = new Label("C2");
  TextField  czTF = new TextField(  7);

  myCanvas myC;


  // data
  double ax=1.0, ay=2.0, az=3.0, bx=-1.0, by=4.0, bz=0.0, 
         cx=ax+bx, cy=ay+by, cz=az+bz;

  public void init()
  {
    
    myC = new myCanvas( ax, ay, az, bx, by, bz, cx, cy, cz   );
    myC.resize( bounds().width, (int)Math.round( bounds().height*0.60) );
    add( myC );

    axTF.setText( " "+ax ); bxTF.setText( " "+bx ); cxTF.setText( " "+cx ); 
    ayTF.setText( " "+ay ); byTF.setText( " "+by ); cyTF.setText( " "+cy );
    azTF.setText( " "+az ); bzTF.setText( " "+bz ); czTF.setText( " "+cz );

    add( axL ); add( axTF ); add( bxL ); add( bxTF ); add( cxL ); add( cxTF );
    add( ayL ); add( ayTF ); add( byL ); add( byTF ); add( cyL ); add( cyTF );
    add( azL ); add( azTF ); add( bzL ); add( bzTF ); add( czL ); add( czTF );

    cxTF.setEditable(false); cyTF.setEditable(false); czTF.setEditable(false);


  }

  public void paint(Graphics  g)
  {
    cxTF.setText( cx+" ");
    cyTF.setText( cy+" ");
    czTF.setText( cz+" ");
    myC.repaint();
  }

  // Respond to click on the gridCB checkBox and the labelsCB checkBox
  public boolean action ( Event evt, Object obj )
  {
    if ( evt.target instanceof TextField )
    {
      ax = new Double( axTF.getText().trim() ).doubleValue();
      ay = new Double( ayTF.getText().trim() ).doubleValue();
      az = new Double( azTF.getText().trim() ).doubleValue();

      bx = new Double( bxTF.getText().trim() ).doubleValue();
      by = new Double( byTF.getText().trim() ).doubleValue();
      bz = new Double( bzTF.getText().trim() ).doubleValue();

      cx = ax + bx; cy = ay + by; cz = az + bz;
      myC.setValues( ax, ay, az, bx, by, bz, cx, cy, cz );
      repaint();
      return true;
    }
    return true;
  }

}


////////////////////////////////////////////////////////////////////////////////
//
// class transCanvas does the actual drawing of the vectors
//
class myCanvas extends Canvas
{

  // values 
  double  ax, ay, az, bx, by, bz, cx, cy, cz ;


  public myCanvas( double ax, double ay, double az,
                         double bx, double by, double bz, 
                         double cx, double cy, double cz)
  {
    this.ax = ax; this.ay = ay; this.az = az;
    this.bx = bx; this.by = by; this.bz = bz;
    this.cx = cx; this.cy = cy; this.cz = cz;
  }


  public void setValues( double ax, double ay, double az,
                         double bx, double by, double bz, 
                         double cx, double cy, double cz)
  {
    this.ax = ax; this.ay = ay; this.az = az;
    this.bx = bx; this.by = by; this.bz = bz;
    this.cx = cx; this.cy = cy; this.cz = cz;
  }


  int drawVector( Graphics g, int loc, double x, double y, double z )
  {
    int width  =  bounds().width;
    int height =  bounds().height;
    
    Font ft = new Font("Courier", Font.BOLD, 16 );
    g.setFont( ft );

    int elWidth = 
      Math.max( (" "+x).length(), 
      Math.max( (" "+y).length(), (" "+z).length() ) );

    g.drawString( " "+x , loc,   height/3  );
    g.drawString( " "+y , loc ,  height/2  );
    g.drawString( " "+z , loc , 2*height/3 );    
    g.drawArc(  loc ,              height/4,  8, height/2,  90, 180 );
    g.drawArc(  loc+elWidth*11,    height/4,  8, height/2, -90, 180 );

    return loc+elWidth*11+8;
    

  }

  // draw the picture --- applet should be sized to width=300, height=200 or so
  public void paint(Graphics  g)
  {
    
    int width  =  bounds().width;
    int height =  bounds().height;
    int lastLoc;

    lastLoc = drawVector( g, width/12, ax, ay, az );
    g.drawString( "+", lastLoc+5, height/2 );
    lastLoc = drawVector( g, lastLoc+17, bx, by, bz );
    g.drawString( "=", lastLoc+5, height/2 );
    lastLoc = drawVector( g, lastLoc+17, cx, cy, cz );

  }

}
