// showTranspose.java --- demonstrate transpose of 3 element vector 
//
// applet should set size to width=300 height=200

// <applet code=showTranspose width=300 height=200>
// <param name=xvalue value=> 
// <param name=yvalue value=> 
// <param name=zvalue value=>
// </applet>

// October 19, 2003 -- extensive revision from 1997 version

import java.awt.* ;
import java.awt.event.* ;
import java.applet.*;
import java.lang.Math;

public class showTranspose extends Applet implements ActionListener, KeyListener
{
 
  // components
  Label      xL  = new Label("A0");
  TextField  xTF = new TextField(7);
  Label      yL  = new Label("A1");
  TextField  yTF = new TextField(7);
  Label      zL  = new Label("A2");
  TextField  zTF = new TextField(7);

  Button      transB = new Button("transpose");
  transCanvas transC;

  public void init()
  {
    double xvalue  = 1.0 ;
    double yvalue  = 2.0 ;
    double zvalue  = 3.0 ;

    try
    {
      String xparm = getParameter("xvalue");
      xvalue  = new Double( xparm ).doubleValue() ;
      String yparm = getParameter("yvalue");
      yvalue  = new Double( yparm ).doubleValue() ;
      String zparm = getParameter("zvalue");
      zvalue  = new Double( zparm ).doubleValue() ;
      xTF.setText( xparm ); yTF.setText( yparm ); zTF.setText( zparm );
    }
    catch( Exception e )
    {
      showStatus("missing applet parameters");
      xTF.setText( "1.0" ); yTF.setText( "2.0" ); zTF.setText( "3.0" );
    }
    
    transC = new transCanvas( xvalue, yvalue, zvalue );
    transC.setSize( getSize().width, (int)Math.round( getSize().height*0.75) );
    add( transC );

    add( xL ); add( xTF );
    add( yL ); add( yTF );
    add( zL ); add( zTF );

    xTF.addKeyListener( this );
    yTF.addKeyListener( this );
    zTF.addKeyListener( this );
    transB.addActionListener( this );
    transB.setActionCommand("toggle");
    add( transB );
  }

  // ActionListener methods 
  public void actionPerformed ( ActionEvent evt )
  {
    if ( evt.getActionCommand().equals("toggle" ) )
    {
      transC.toggleSwitch( );
    }
    try
    {
      transC.setXYZ( Double.parseDouble( xTF.getText() ), 
                     Double.parseDouble( yTF.getText() ),
                     Double.parseDouble( zTF.getText() ) );
    }
    catch ( NumberFormatException nfe )
    {
    }
    transC.repaint();
  }

  // KeyListener methods 
  public void keyPressed (KeyEvent event ) {}
  public void keyTyped   (KeyEvent event ) {}
  public void keyReleased(KeyEvent event ) 
  {
    try
    {
      transC.setXYZ( Double.parseDouble( xTF.getText() ), 
                     Double.parseDouble( yTF.getText() ),
                     Double.parseDouble( zTF.getText() ) );
    }
    catch ( NumberFormatException nfe )
    {
    }
    transC.repaint();
  }
}

////////////////////////////////////////////////////////////////////////////////
//
// class transCanvas does the actual drawing of the vectors
//
class transCanvas extends Canvas
{
  // values for the vector
  double vx, vy, vz;

  // if the column vector is displayed as a column (=true) or not
  boolean asColumn ;

  public transCanvas( double x, double y, double z )
  {
    vx = x; vy = y; vz = z;
    asColumn = true;
    setBackground( new Color( 255, 255, 255) );
  }

  public void toggleSwitch()
  {
    asColumn = !asColumn;
  }

  public void setXYZ( double x, double y, double z )
  {
    vx = x; vy = y; vz = z;
  }

  // draw the picture --- applet should be sized to width=300, height=200
  public void paint(Graphics  g)
  {
    int width  =  getBounds().width;
    int height =  getBounds().height;
    
    Font ft = new Font("Courier", Font.BOLD, 16 );
    g.setFont( ft );

    if ( asColumn )
    {
      int elWidth = 
        Math.max( (" "+vx).length(), 
                  Math.max( (" "+vy).length(), (" "+vz).length() ) );

      g.drawString( "A =  ",  width/6,  height/2 );
      g.drawString( " "+vx ,  width/3,  height/3 );
      g.drawString( " "+vy ,  width/3,  height/2 );
      g.drawString( " "+vz ,  width/3, 2*height/3 );
      
      g.drawArc(   width/3,             height/4, 8, height/2,  90, 180 );
      g.drawArc(   width/3+elWidth*11,  height/4, 8, height/2, -90, 180 );
    } 
    
    else
    {
      String vec = "A = (" + vx + ", " + vy + ", " + vz ;
      int start = (width-vec.length()*11)/2;

      g.drawString( vec,  start, height/2 );
      g.drawString( ")", start+vec.length()*11, height/2 );
      g.drawString( " T", start+vec.length()*11+5, height/2-6 );
    }
 
  }

}
