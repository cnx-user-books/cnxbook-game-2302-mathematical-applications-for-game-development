/* Read each line of the index file, looking for 

  HREF="ch99_


when ever this is found, replace it with

  HREF="chap99/ch99_

*/

import java.io.*;
  
class insertChapterDirs
{

  public static void main ( String[] args )  throws IOException
  {
    String line;
    int start=0;

    BufferedReader in = new BufferedReader(
        new InputStreamReader( System.in ) );

    while ( (line = in.readLine()) != null )
    {
      start = line.indexOf( "HREF=\"vch" );
      if ( start != -1 )
      {

        String chapStr = 
          line.substring( start+8, start+12 );
        
        chapStr =  chapStr + "/" ;

        line = line.substring( 0, start+"HREF=\"".length() ) + chapStr +
               line.substring( start+"HREF=\"".length() );

      }

      System.out.println( line );
    }
  
  }


}