// drawArrow.java --- vector-drawing tool for web pages.
//
// revised version 09-25-97

import java.awt.* ;
import java.applet.*;
import java.lang.Math;
import java.util.StringTokenizer;
import java.lang.Thread;


class grLabel
{
  String text = null;
  double x, y;

  public grLabel(){}
  
  public grLabel( String st, double x, double y )
  {
    text = new String(st);
    this.x = x;
    this.y = y;
  }
}

class graphPaperObject
{
  Color   color = null;
  grLabel label = null;
  static  int colorCycle = 0;

  public graphPaperObject()
  {
    switch ( colorCycle = ((colorCycle < 12) ? colorCycle+1: 0) )
    {
    case  0: color =  Color.black ;    break;
    case  1: color =  Color.blue ;     break;
    case  2: color =  Color.cyan ;     break;
    case  3: color =  Color.darkGray ; break;
    case  4: color =  Color.gray ;     break;
    case  5: color =  Color.green.darker() ;  break;
    case  6: color =  Color.orange.darker() ; break;
    case  7: color =  Color.magenta ;  break;
    case  8: color =  Color.orange ;   break;
    case  9: color =  Color.pink ;     break;
    case 10: color =  Color.red ;      break;
    case 11: color =  Color.white ;    break;
    case 12: color =  Color.yellow ;   break;
    default: color =  Color.black ;    break;     
    }
  }

  public void setColor( Color c )
  {
    color =  c;
  }

  public void setLabel( String lb, double x, double y )
  {
    if ( lb != null )
      label = new grLabel( lb, x, y );
  }
}

class grPoint extends graphPaperObject
{
  double x, y;

  public grPoint( )
  {
    super();
    x = 0.0; y = 0.0;
  }

  public grPoint( double x, double y )
  {
    this.x = x; this.y = y;
  }

  public grPoint (double x, double y, Color c )
  {
    this( x, y );
    color = c;
  }

  public grPoint (double x, double y, Color c, String lb )
  {
    this( x, y, c );
    setLabel( lb, x+0.5, y );
  }

}// end grPoint

class Ant extends grPoint
{
  public Ant( )
  {
    super();
  }

  public Ant( double x, double y )
  {
    super(x, y);
  }

  public Ant (double x, double y, Color c )
  {
    super(x, y, c);
  }

  public Ant (double x, double y, Color c, String lb )
  {
    super(x, y, c, lb );
  }
}

class Arrow extends graphPaperObject
{
  double x1, y1, x2, y2;

  public Arrow( )
  {
    super();
    this.x1 = 0; this.y1 = 0; this.x2 = 0; this.y2 = 0;
  }

  public Arrow( double x1, double y1, double x2, double y2 )
  {
    this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
  }

  public Arrow (double x1, double y1, double x2, double y2, Color c )
  {
    this( x1, y1, x2, y2 );
    color = c;
  }

  public Arrow (double x1, double y1, double x2, double y2, Color c, String lb )
  {
    this( x1, y1, x2, y2, c );

    // midpoint of the arrow
    double xm = (x1+x2)/2.0; double ym = (y1+y2)/2.0; 

    // perpendicular to the arrow
    double xp = -y2+y1;      double yp = x2-x1;
    double plength = Math.sqrt( xp*xp + yp*yp );
    xp /= plength;
    yp /= plength;

    // where to place the label
    setLabel( lb, xm+xp/3, ym+yp/3 );
  }

}// end Arrow

// class drawArrow deals with applet events and gets the parameters from the web page
public class drawArrow extends Applet 
{
 
  // range of the values graphed, with defaults
  double xMin = -10;
  double xMax =  10;
  double yMin = -10;
  double yMax =  10;

  // components
  graphPaper gr;
  Checkbox   labelsCB;
  Checkbox   gridCB;
  Button     eraseB;
  boolean drawGrids  = false;
  boolean drawLabels = true;

  boolean enableDraw = false;

  // number of vectors, number of points, number of ants
  final int aSize = 16;

  // get parameters from the applet
  //
  public void getAppletDimensions()
  {
    // get parameters for range of the x and y values
    try
    {
      String parameter;
      parameter = getParameter("xMin") ;
      xMin = (parameter == null ? -10 : new Double( parameter ).doubleValue() );
      parameter = getParameter("xMax") ;
      xMax = (parameter == null ?  10 : new Double( parameter ).doubleValue() ); 
      parameter = getParameter("yMin") ;
      yMin = (parameter == null ? -10 : new Double( parameter ).doubleValue() ); 
      parameter = getParameter("yMax") ;
      yMax = (parameter == null ?  10 : new Double( parameter ).doubleValue() ); 
    }
    catch ( NumberFormatException e )
    {
      showStatus("bad range parameter --- ignored");
      xMin = -10;
      xMax =  10;
      yMin = -10;
      yMax =  10;
    }
  }

  // get parameters for the points to plot
  public void getPoints()
  {
    for ( int pt=0; pt<15; pt++ )
    {
      String pointName = "point" + pt;
      String parameter = getParameter(pointName) ;
      showStatus( parameter );
      {
        if ( parameter != null )
        {
          try
          {
            StringTokenizer st = new StringTokenizer( parameter, ",", true ); 
            String x1parm      = st.nextToken();
            String delimiter   = st.nextToken();
            String y1parm      = st.nextToken();
            
            double x = new Double( x1parm ).doubleValue() ;
            double y = new Double( y1parm ).doubleValue() ;
            Color  cl = getColor( "pcolor", pt) ;
            String lb = getLabel( "plabel", pt) ;
            gr.addPoint( new grPoint( x, y, cl, lb ) );
            
          }
          catch (NumberFormatException e )
          {
            showStatus("bad point " + pt + " parameter.");
          }
        }
        
      }
    }
    
  }

  // get parameters for the ants
  public void getAnts()
  {
    for ( int pt=0; pt<15; pt++ )
    {
      String pointName = "ant" + pt;
      String parameter = getParameter(pointName) ;
      {
        if ( parameter != null )
        {
          try
          {
            StringTokenizer st = new StringTokenizer( parameter, ",", true ); 
            String x1parm      = st.nextToken();
            String delimiter   = st.nextToken();
            String y1parm      = st.nextToken();
            
            double x = new Double( x1parm ).doubleValue() ;
            double y = new Double( y1parm ).doubleValue() ;
            Color  cl = getColor( "acolor", pt) ;
            String lb = getLabel( "alabel", pt) ;
            gr.addAnt( new Ant( x, y, cl, lb ) );
            
          }
          catch (NumberFormatException e )
          {
            showStatus("bad ant " + pt + " parameter.");
          }
        }
        
      }
    }
    
  }

  // get parameters for the vectors to draw
  public void getVectors()
  {
    for ( int vect=0; vect<15; vect++ )
    {
      String vectorName = "vector" + vect ;
      String parameter  = getParameter(vectorName) ;

      if ( parameter != null )
      {
        try
        {
          StringTokenizer st = new StringTokenizer( parameter, ",", true ) ; 
          String x1parm      = st.nextToken() ;
          String delimiter   = st.nextToken() ;
          String y1parm      = st.nextToken() ;
          delimiter          = st.nextToken() ;
          String x2parm      = st.nextToken() ;
          delimiter          = st.nextToken() ;
          String y2parm      = st.nextToken() ;
          
          double x1 = new Double( x1parm ).doubleValue() ;
          double y1 = new Double( y1parm ).doubleValue() ;
          double x2 = new Double( x2parm ).doubleValue() ;
          double y2 = new Double( y2parm ).doubleValue() ;
                   
          Color  cl = getColor( "color", vect) ;
          String lb = getLabel( "label", vect) ;
          gr.addVector( new Arrow( x1, y1, x2, y2, cl, lb ) ) ;
        }
        catch (NumberFormatException e )
        {
          showStatus("bad vector parameter") ;
        }
      }
      
    }
    
  }


  public Color getColor( String parmName, int count )
  {
    String colorNumber = parmName + count;
    String parameter   = getParameter(colorNumber) ;
    
    if ( parameter != null )
    {
      parameter = parameter.trim();
      if      ( parameter.equalsIgnoreCase("black") )     
        return( Color.black );
      else if ( parameter.equalsIgnoreCase("blue") )      
        return( Color.blue  );
      else if ( parameter.equalsIgnoreCase("cyan") )      
        return( Color.cyan );
      else if ( parameter.equalsIgnoreCase("darkGray") )  
        return( Color.darkGray  );
      else if ( parameter.equalsIgnoreCase("gray") )      
        return( Color.gray  );
      else if ( parameter.equalsIgnoreCase("green") )     
        return( Color.green.darker()  );
      else if ( parameter.equalsIgnoreCase("lightGray") ) 
        return( Color.lightGray  );
      else if ( parameter.equalsIgnoreCase("magenta") )  
        return( Color.magenta  );
      else if ( parameter.equalsIgnoreCase("orange") )    
        return( Color.orange  );
      else if ( parameter.equalsIgnoreCase("pink") )      
        return( Color.pink  );
      else if ( parameter.equalsIgnoreCase("red") )       
        return( Color.red  );
      else if ( parameter.equalsIgnoreCase("white") )     
        return( Color.white  );
      else if ( parameter.equalsIgnoreCase("yellow") )    
        return( Color.yellow  );
      else
        return( Color.black );     
    }
    else
    {
      return( Color.black );     
    }
  }
      
 
  // get labels  
  public String getLabel( String parmName, int count )
  {
    String labelNumber = parmName  + count;
    String parameter   = getParameter(labelNumber) ;    
    if ( parameter != null )
      return( parameter.trim() );    
    else
      return null;
  }

  public void  getDrawEnable()
  {
    String parameter = getParameter("enableDraw");
    if ( parameter != null )
      enableDraw = true;
    else
      enableDraw = false;
  }

  public void init()
  {
    getAppletDimensions();
    gr = new graphPaper( xMin, xMax, yMin, yMax );
    getVectors();
    getPoints();
    getAnts();
    getDrawEnable();

    gr.resize( bounds().width, (int)Math.round( bounds().height*0.80) );
    gr.setDrawEnabled( enableDraw );
    gr.setBackground(  new Color(245, 245, 245) );
    add( gr );

    labelsCB = new Checkbox("labels");
    labelsCB.setState( drawLabels );
    gridCB   = new Checkbox("grid");
    gridCB.setState( drawGrids );
    add( labelsCB );
    add( gridCB );
    if ( enableDraw ) 
    {
      eraseB = new Button("erase");
      add( eraseB );
    }

  }


  // Respond to click on the gridCB checkBox and the labelsCB checkBox
  public boolean action ( Event evt, Object obj )
  {
    if ( evt.target == gridCB )
    {
      gr.setGrids( gridCB.getState() );
    }
    else if ( evt.target == labelsCB )
    {
      gr.setLabels( labelsCB.getState() );
    }
    else if ( evt.target == eraseB )
    {
      gr.eraseUserArrows();
    }
    return true;
  }

}


////////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////////
class graphPaper extends Canvas
{
  
  // range of values that this graphPaper is expected to plot
  double xMin = -10;
  double xMax =  10;
  double yMin = -10;
  double yMax =  10;
  
  boolean drawGrids     = false; 
  boolean drawLabels    = true;
  boolean workingOnLine = false;
  boolean drawEnabled   = false;

  // array of vectors to draw. 
  final int  aSize   = 15;
  Arrow[]    vector  = new Arrow[aSize];
  int        startingNumberOfVectors = 0;
  int        numberOfVectors  = 0;

  // array of points to draw.
  grPoint[]  point   = new grPoint[aSize];
  int        numberOfPoints = 0;

  // array of ants to draw
  Ant[]      ant     = new Ant[aSize];
  int        numberOfAnts = 0;
  
  // graphics context
  Graphics grContext;

  public graphPaper( double xm, double xM, double ym, double yM )
  {
    xMin = xm;
    xMax = xM;
    yMin = ym;
    yMax = yM;
  }
  
  public void setGrids( boolean value )
  { 
    drawGrids = value;
    repaint();
  }
  
  public void setLabels( boolean value )
  {
    drawLabels = value ;
    repaint();
  }
  
  public void setDrawEnabled ( boolean value )
  {
    drawEnabled = value;
    repaint();
  }
  
  public void eraseUserArrows()
  {
    numberOfVectors =startingNumberOfVectors;
    repaint();
  }

  // transform a graph paper x into an applet x
  int transformX( double x )
  {
    double range = (xMax - xMin) ;
    if ( range == 0.0 ) range = 1.0;
    double width = bounds().width-1;
    return (int)Math.round( (width/range)*x - (width*xMin)/range );
  }
  
  // transform a graph paper y into an applet y
  int transformY( double y )
  {
    double range  = yMax - yMin;
    if ( range == 0.0 ) range = 1.0;
    double height = bounds().height-1;
    return (int)Math.round( (-height/range)*y + (height*yMax)/range );
  }
  
  // transform an applet x into a graph paper x
  double inverseX ( int x )
  {
    double range = xMax - xMin;
    double width = bounds().width-1;
    return (range/width)*x + xMin;
  }
  
  // transform an applet y into a graph paper y
  double inverseY ( int y )
  {
    double range = yMax - yMin;
    double height = bounds().height-1;
    return (-range/height)*y + yMax;
  }
  
  public void addVector( Arrow v )
  {
    vector[ numberOfVectors++ ] = v;
    startingNumberOfVectors++ ;
  }

  public void addPoint( grPoint p )
  {
    point[ numberOfPoints++ ] = p;
  }

  public void addAnt( Ant p )
  {
    ant[ numberOfAnts++ ] = p;
  }
  
  // draw the grid lines on the graph paper
  void drawGrid()
  {
    // draw vertical lines
    for ( double x = xMin; x < xMax; x++ )
      drawLine( x, yMin, x, yMax );
    
    // draw horizontal lines
    for ( double y = yMin; y < yMax; y++ )
      drawLine( xMin, y, xMax, y );
  }
  
  // draw a graphpaper line
  void drawLine(  double x1, double y1, double x2, double y2 )
  {
    grContext.drawLine( transformX( x1 ), transformY( y1 ), 
      transformX( x2 ), transformY( y2 ) );
  }

  void drawPoint( grPoint p )
  {
    if ( p.color != null ) grContext.setColor( p.color );
    grContext.fillOval( transformX( p.x )-2, transformY( p.y )-2, 4, 4 );
  }

  public void placeLabel( grLabel label )
  {
    if ( label != null )
    {
      // draw the label
      int lx = transformX( label.x );
      int ly = transformY( label.y );
      grContext.drawString( label.text, lx, ly );
    }
  }

  public boolean mouseDown ( Event evt, int x, int y)
  {
    if ( (numberOfVectors < vector.length ) && drawEnabled ) 
    {
      workingOnLine = true;
      numberOfVectors++ ;
      vector[ numberOfVectors-1 ] = 
        new Arrow( inverseX( x ), inverseY( y ), 
                   inverseX( x ), inverseY( y )  );
    }
    return true;
  }

  public boolean mouseDrag (  Event evt, int x, int y)
  {
    if ( workingOnLine )
    {
      vector[ numberOfVectors-1 ].x2 = inverseX( x );
      vector[ numberOfVectors-1 ].y2 = inverseY( y );
      repaint();
    }
    return true;
  }


  public boolean mouseUp  ( Event evt, int x, int y)
  {
    if ( workingOnLine )
    {
      workingOnLine = false;
      vector[ numberOfVectors-1 ].x2 = inverseX( x );
      vector[ numberOfVectors-1 ].y2 = inverseY( y );
      repaint();
   }
    return true;
  }
 
  // draw the picture on the graphpaper
  public void paint( Graphics g)
  {
    grContext =   getGraphics();

    // possibly draw grid lines---do this first
    if ( drawGrids )
    {
      grContext.setColor( Color.gray.brighter() );
      drawGrid();
    }
    
    // outline the graph paper---overwrite grid lines
    grContext.setColor( Color.gray );
    drawLine( xMin, yMax, xMax, yMax );
    drawLine( xMax, yMax, xMax, yMin );
    drawLine( xMax, yMin, xMin, yMin );
    drawLine( xMin, yMin, xMin, yMax );
    
    // draw the coordinate axes
    drawLine( xMin, 0, xMax, 0 );
    drawLine( 0, yMin, 0, yMax );
    
    // put in the tick marks
    for ( double tick = xMin; tick<=xMax; tick++ )
      drawLine( tick, 0.2, tick, -0.2 );
    for ( double tick = yMin; tick<=yMax; tick++ )
      drawLine( 0.2, tick, -0.2, tick);
    
    // draw each vector
    for ( int j=0; j< numberOfVectors; j++ )
    {
      drawArrow( vector[j] );
      if (drawLabels) placeLabel( vector[j].label );
    }

    // draw each point
    for ( int j=0; j< numberOfPoints; j++ )
    {
      drawPoint( point[j] );
      if (drawLabels) placeLabel( point[j].label );
    }

    // draw each ant
    for ( int j=0; j< numberOfAnts; j++ )
    {
      drawAnt( ant[j] );
      if (drawLabels) placeLabel( ant[j].label );
    }
      
  }


  public void drawArrow( Arrow a )
  {
    grContext.setColor( a.color );
    double length = Math.sqrt( (a.x2-a.x1)*(a.x2-a.x1) + 
                               (a.y2-a.y1)*(a.y2-a.y1) ) + 0.2;
    double angle  = 0.2/Math.pow( length, 1.3);

    // draw the shaft of the arrow
    drawLine( a.x1, a.y1, a.x2, a.y2 );

    // translate end of arrow to origin
    double tipx = a.x2 - a.x1;
    double tipy = a.y2 - a.y1;

    // draw two barbs
    for ( int barb = 0; barb<2; barb++ )
    {
      // rotate shaft to slight angle from its original position
      double newx = tipx*Math.cos( angle ) - tipy*Math.sin( angle );
      double newy = tipx*Math.sin( angle ) + tipy*Math.cos( angle );
      
      // shrink it, so its end is now endpoint of a barb
      newx *= 0.90; newy *= 0.90;
      
      // translate endpoint back to original location
      newx += a.x1;   newy += a.y1;

      // connect tip of arrow to end of barb
      drawLine( a.x2, a.y2, newx, newy );
      
      // start second barb
      angle *= -1;
    }
  }
  
  void drawAnt( Ant a )
  {
    int x = transformX( a.x );
    int y = transformY( a.y );

    if ( a.color != null ) grContext.setColor( a.color );
    grContext.fillOval( x, y-6, 4, 4 );
    grContext.fillOval( x, y-2, 4, 4 );
    grContext.fillOval( x, y+1, 4, 8 );

    grContext.drawLine( x+4, y,   x+7, y-3 );
    grContext.drawLine( x+4, y+2, x+7, y+3 );

    grContext.drawLine( x,   y,   x-3, y-3 );
    grContext.drawLine( x,   y+2, x-3, y+3 );
  }

}
