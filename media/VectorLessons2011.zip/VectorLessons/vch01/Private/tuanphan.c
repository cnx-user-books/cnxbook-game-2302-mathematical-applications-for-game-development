// Assign #6: Sacred Grove		       	                      Tuan Phan - CS423

#include <GL/glut.h>
#include <stdlib.h>
#include <Math.h>
#include <time.h>
#include <process.h>
#include <windows.h>
#include <stdio.h>

#define PI 3.14159265358979				
#define feet 3.0								      
#define Distance 30*feet
#define numSnow 500
#define num 20

const float maxSpeed = 5*feet;
float snowX[numSnow], snowY[numSnow], snowZ[numSnow];
float snowDX[numSnow], snowDY[numSnow], snowDZ[numSnow];
float timeQuantum = 0.025, alpha[numSnow];
float xCoord[num][num], yCoord[num][num], zCoord[num][num];
float xCoordTemp, zCoordTemp;
int angle = 60, lookRightLeft = 0.0, lookUpDown = 5*feet;

GLfloat xEye = 0.0, yEye = Distance/2, zEye = Distance;
GLdouble theta  = 0.0;
GLUquadricObj  *r;

void initSnow(int i)
{  snowX[i] = Distance*((double) rand()/RAND_MAX);
   snowY[i] = Distance;
   snowZ[i] = Distance*((double) rand()/RAND_MAX);
   snowDX[i] = maxSpeed*((double) rand()/RAND_MAX);
   snowDY[i] = maxSpeed*((double) rand()/RAND_MAX);
   snowDZ[i] = maxSpeed*((double) rand()/RAND_MAX);
   alpha[i] = 180*(double) rand()/RAND_MAX;
}

void updateSnow(void)
{ int i=0;
  while (i < numSnow)
  {  if (snowY[i] <= 0 || snowX[i] <= -Distance || snowZ[i] <= -Distance)
        initSnow(i);
     else
	    {  snowX[i] -= timeQuantum*snowDX[i];   
           snowY[i] -= timeQuantum*snowDY[i];	 
           snowZ[i] -= timeQuantum*snowDZ[i];
		   alpha[i] += 10;
		}
     i++;
  }
}

void myIdle(void)
{ Sleep(1000*timeQuantum);
  updateSnow();
  glutPostRedisplay();
}


void surface(void)
{  int i, j;

   GLfloat ambient [] = {0.5, 0.5, 0.6, 1 }; //gray
   GLfloat diffuse [] = {0.5, 0.5, 0.6, 1 };
   GLfloat specular[] = {0.5, 0.5, 0.6, 1 };

   glPushAttrib( GL_ALL_ATTRIB_BITS);
   	  glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular);
      glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 100.0);
	   for (i=0; i < num-1; i++)
		 for (j=0; j < num-1; j++)
		 {  glBegin(GL_POLYGON) ;	
	  	    glPushMatrix (); 
		     glTranslatef(xCoord[i][j], yCoord[i][j], zCoord[i][j]);	
	          glVertex3f(xCoord[i][j], yCoord[i][j], zCoord[i][j]);
	          glVertex3f(xCoord[i][j+1], yCoord[i][j+1], zCoord[i][j+1]);
	          glVertex3f(xCoord[i+1][j+1], yCoord[i+1][j+1], zCoord[i+1][j+1]);
	          glVertex3f(xCoord[i+1][j], yCoord[i+1][j], zCoord[i+1][j]);
		    glPopMatrix ();
           glEnd();
								}
	  glPopAttrib();
}

void tree(GLfloat radius, GLfloat height, GLfloat x, GLfloat y, GLfloat z)
{  GLfloat ambient1 [] = {0.0, 0.3, 0.0, 1 }; //lighter green
   GLfloat diffuse1 [] = {0.0, 0.7, 0.0, 1 };
   GLfloat specular1[] = {0.0, 0.9, 0.0, 1 };
   GLfloat ambient2 [] = {0.0, 0.1, 0.0, 1 }; //darker green
   GLfloat diffuse2 [] = {0.0, 0.7, 0.0, 1 };
   GLfloat specular2[] = {0.0, 0.9, 0.0, 1 };
   GLfloat ambient3 [] = {0.8, 0.2, 0.0, 1 }; //brown
   GLfloat diffuse3 [] = {0.6, 0.3, 0.0, 1 };
   GLfloat specular3[] = {0.6, 0.3, 0.0, 1 };
 
   glPushAttrib( GL_ALL_ATTRIB_BITS);
   glPushMatrix (); //upper tree top 
  	glTranslatef(x, y + height/1.2, z);
      glRotatef(-90.0, 1.0, 0.0, 0.0);
  	  glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient1);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse1);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular1);
      glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      gluCylinder(r, 4.5*radius, 0.0, height, 50, 50);
    glPopMatrix ();

    glPushMatrix (); //lower tree top 
	  glTranslatef(x, y + height/2, z);
      glRotatef(-90.0, 1.0, 0.0, 0.0);
	  glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient2);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse2);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular2);
      glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      gluCylinder(r, 5*radius, radius, height/1.5, 50, 50);
    glPopMatrix ();

	glPushMatrix (); //tree body 
	  glTranslatef(x, y, z);
      glRotatef(-90.0, 1.0, 0.0, 0.0);
						glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient3);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse3);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular3);
      glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      gluCylinder(r, radius, radius, height/2, 50, 50);
    glPopMatrix ();
  glPopAttrib();
}

void snowman(GLfloat base, GLfloat x, GLfloat y, GLfloat z)
{  float m;
   GLfloat ambient1 [] = {0.5, 0.5, 0.5, 1 }; //white
   GLfloat diffuse1 [] = {0.5, 0.5, 0.5, 1 };
   GLfloat specular1[] = {0.5, 0.5, 0.5, 1 };
			GLfloat ambient2 [] = {0.4, 0.4, 0.4, 1 }; //gray
   GLfloat diffuse2 [] = {0.4, 0.4, 0.4, 1 };
   GLfloat specular2[] = {0.4, 0.4, 0.4, 1 };
			GLfloat ambient3 [] = {0.0, 0.0, 0.8, 1 }; //blue
   GLfloat diffuse3 [] = {0.0, 0.0, 0.8, 1 };
   GLfloat specular3[] = {0.0, 0.0, 0.8, 1 };
			GLfloat ambient4 [] = {0.2, 0.2, 1.0, 1 }; //lighter blue
   GLfloat diffuse4 [] = {0.2, 0.2, 1.0, 1 };
   GLfloat specular4[] = {0.2, 0.2, 1.0, 1 };
			GLfloat ambient5 [] = {0.0, 0.0, 0.0, 1 }; //black
   GLfloat diffuse5 [] = {0.0, 0.0, 0.0, 1 };
   GLfloat specular5[] = {0.0, 0.0, 0.0, 1 };
			GLfloat ambient6 [] = {0.8, 0.3, 0.0, 1 }; //orange
   GLfloat diffuse6 [] = {0.9, 0.4, 0.0, 1 };
   GLfloat specular6[] = {0.9, 0.4, 0.0, 1 };
			GLfloat ambient7 [] = {1.0, 0.0, 0.0, 1 }; //red
   GLfloat diffuse7 [] = {1.0, 0.0, 0.0, 1 };
   GLfloat specular7[] = {1.0, 0.0, 0.0, 1 };

   glPushAttrib( GL_ALL_ATTRIB_BITS);
	   glPushMatrix (); //feet
      glTranslatef(x, y + base, z);
						glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient1);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse1);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular1);
      glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      glutSolidSphere(base, 50, 50);
    glPopMatrix ();

	   glPushMatrix (); //body
      glTranslatef(x, y + 2.25*base, z);
						glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient2);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse2);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular2);
      glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      glutSolidSphere(0.65*base, 50, 50);
    glPopMatrix ();

	   glPushMatrix (); //head
      glTranslatef(x, y + 3.15*base, z);
						glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient1);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse1);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular1);
      glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      glutSolidSphere(0.45*base, 50, 50);
    glPopMatrix ();

				glPushMatrix (); //hat bottom
						glTranslatef(x, y + 3.55*base, z);
      glRotatef(-90.0, 1.0, 0.0, 0.0);
						glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient3);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse3);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular3);
      glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      glBegin(GL_POLYGON) ;								
        for (m=0; m <= 2*PI; m += 0.1)
           glVertex3f(0.5*base*sin(m), 0.5*base*cos(m), 0);
      glEnd();
    glPopMatrix ();

				glPushMatrix (); //hat body
      glTranslatef(x, y + 3.55*base, z);
						glRotatef(-90.0, 1.0, 0.0, 0.0);
						glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient4);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse4);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular4);
      glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      gluCylinder(r, 0.3*base, 0.3*base, 0.45*base, 50, 50);
    glPopMatrix ();

				glPushMatrix (); //hat top
						glTranslatef(x, y + 4.0*base, z);
      glRotatef(-90.0, 1.0, 0.0, 0.0);
						glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient3);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse3);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular3);
      glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      glBegin(GL_POLYGON) ;								
        for (m=0; m <= 2*PI; m += 0.1)
           glVertex3f(0.3*base*sin(m), 0.3*base*cos(m), 0);
      glEnd();
    glPopMatrix ();

				glPushMatrix (); //right eye
      glTranslatef(x - 0.2*base, y + 3.3*base, z + 0.35*base);
						glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient5);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse5);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular5);
      glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      glutSolidSphere(0.1*base, 15, 15);
    glPopMatrix ();

				glPushMatrix (); //left eye
      glTranslatef(x + 0.2*base, y + 3.3*base, z + 0.35*base);
						glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient5);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse5);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular5);
						glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      glutSolidSphere(0.1*base, 15, 15);
    glPopMatrix ();

				glPushMatrix (); //nose
      glTranslatef(x, y + 3.2*base, z + 0.45*base);
						glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient6);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse6);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular6);
						glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      gluCylinder(r, 0.075*base, 0.0, 0.4*base, 50, 50);
    glPopMatrix ();

	   glPushMatrix (); //upper button
      glTranslatef(x, y + 2.6*base, z + 0.55*base);
      glRotatef(-30.0, 1.0, 0.0, 0.0);
						glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient7);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse7);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular7);
						glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 800.0);
      glBegin(GL_POLYGON) ;										
        for (m=0; m <= 2*PI; m += 0.1)
          glVertex3f(0.1*base*sin(m), 0.1*base*cos(m), 0);
      glEnd();
    glPopMatrix ();

				glPushMatrix (); //lower button
      glTranslatef(x, y + 2.25*base, z + 0.655*base);
      glRotatef(0.0, 1.0, 0.0, 0.0);
      glBegin(GL_POLYGON) ;											
        for (m=0; m <= 2*PI; m += 0.1)
          glVertex3f(0.1*base*sin(m), 0.1*base*cos(m), 0);
      glEnd();
    glPopMatrix ();
  glPopAttrib();
}

void display(void)
{ int i;
  float m;
	 GLfloat ambient [] = {1.0, 1.0, 1.0, 1 }; //white
  GLfloat diffuse [] = {1.0, 1.0, 1.0, 1 };
  GLfloat specular[] = {1.0, 1.0, 1.0, 1 };

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  
  glMatrixMode( GL_PROJECTION ); 
  glLoadIdentity();
		gluPerspective( angle, 1.0, 0.5, 50*Distance );
  gluLookAt (xEye, yEye, zEye, lookRightLeft, lookUpDown, 0.0, 0.0, 1.0, 0.0);

		glMatrixMode( GL_MODELVIEW ); 
  glLoadIdentity ();   
		glRotatef(theta, 0.0, 1.0, 0.0);
      surface();
      snowman(2*feet,0,0,0);
						tree(0.5*feet, 8*feet, -8*feet, 0.0, 8*feet);
						tree(0.5*feet, 6*feet, 10*feet, 0.0, 10*feet);
						tree(0.5*feet, 10*feet, -15*feet, 0.0, -10*feet);
      tree(1*feet, 12*feet, 10*feet, 0.0, -15*feet);
						tree(1.5*feet, 12*feet, -15*feet, 0.0, -20*feet);
						tree(1*feet, 11*feet, -15*feet, 0.0, 1*feet);
      tree(1*feet, 15*feet, -6*feet, 0.0, -25*feet);
				  tree(0.5*feet, 9*feet, 10*feet, 0.0, -10*feet);
						tree(0.5*feet, 7*feet, 15*feet, 0.0, -5*feet);
						tree(0.5*feet, 10*feet, -25*feet, 0.0, -15*feet);

  glPointSize(3.0); //snow
  for (i=0; i < numSnow; i++)
  { glPushMatrix (); 
						glTranslatef(snowX[i], snowY[i], snowZ[i]);
      glRotatef(alpha[i], 1.0, 1.0, 1.0);
						glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,  ambient);
      glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,  diffuse);
      glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular);
      glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 100.0);
      glBegin(GL_POLYGON) ;								
        for (m=0; m <= 2*PI; m += 0.1)
           glVertex3f(0.3*sin(m), 0.3*cos(m), 0);
      glEnd();
    glPopMatrix ();
  }
		glutSwapBuffers ();
}

void myInit(void)
{  int i,j=0;
   
	  GLfloat red   [] = { 1.0, 0.0, 0.0, 1.0 };
			GLfloat blue  [] = { 0.0, 0.0, 1.0, 1.0 };
   GLfloat green [] = { 0.0, 1.0, 0.0, 1.0 };
			GLfloat posit0[] = { Distance/10, Distance/6, Distance, 1.0 };
   GLfloat posit1[] = { Distance/3, Distance/6, Distance/3, 1.0 };
			GLfloat posit2[] = { Distance, Distance/6, Distance/10, 1.0 };
			GLfloat glow1[]     = {1.0, 0.0, 0.0, 1 };
			GLfloat glow2[]     = {0.0, 1.0, 0.0, 1 };
			GLfloat glow3[]     = {0.0, 0.0, 1.0, 1 };

   srand((unsigned) time( 0 ));
 	 glClear(GL_COLOR_BUFFER_BIT);
   glClearColor(0.0, 0.0, 0.0, 1.0);
   r=gluNewQuadric(); /* allocate quadric object */
   gluQuadricDrawStyle(r, GLU_FILL);   	
			
			glEnable(GL_LIGHT0);
   glLightfv( GL_LIGHT0, GL_POSITION, posit0 );
   glLightfv( GL_LIGHT0, GL_AMBIENT,  red );
   glLightfv( GL_LIGHT0, GL_DIFFUSE,  red );
   glLightfv( GL_LIGHT0, GL_SPECULAR, red );
			glMaterialf(GL_FRONT, GL_SHININESS, 100.0);

		 glEnable ( GL_LIGHT1 );
   glLightfv( GL_LIGHT1, GL_POSITION, posit1 );
   glLightfv( GL_LIGHT1, GL_AMBIENT,  green );
   glLightfv( GL_LIGHT1, GL_DIFFUSE,  green );
			glLightfv( GL_LIGHT0, GL_SPECULAR, green );
   glMaterialf(GL_FRONT, GL_SHININESS, 100.0);

		 glEnable ( GL_LIGHT2 );
   glLightfv( GL_LIGHT2, GL_POSITION, posit2 );
   glLightfv( GL_LIGHT2, GL_AMBIENT,  blue );
   glLightfv( GL_LIGHT2, GL_DIFFUSE,  blue );
			glLightfv( GL_LIGHT0, GL_SPECULAR, blue );
   glMaterialf(GL_FRONT, GL_SHININESS, 100.0);

   glShadeModel(GL_SMOOTH);
   glEnable(GL_LIGHTING); 
   glEnable(GL_DEPTH_TEST); 	

   for (i = 0; i < numSnow; i++)  //initialize snow
      initSnow(i);   

   xCoordTemp = -Distance;								//initialize surface
			zCoordTemp = -Distance;
   for (j=0; j < num;j++)
			{	 for (i=0; i < num;i++)
						{		xCoord[i][j] = xCoordTemp;
			      yCoord[i][j] = feet*((double) rand()/RAND_MAX);
									zCoord[i][j] = zCoordTemp;
									zCoordTemp += (2*Distance/num); 
						}
			   xCoordTemp += (2*Distance/num);
						zCoordTemp = -Distance;
			}

		 printf("Press key 1 to 6 for different view.\n");	          //Display key using information
			printf("Press key C to rotate right.\nPress key V to rotate left.\n");
		 printf("Press key X to zoom out.\nPress key Z to zoom in.\n");
		 printf("Press key U to look up.\nPress key D to look down.\n");
		 printf("Press key R to look right.\nPress key L to look left.\n");
		 printf("Press key S to move right.\nPress key A to move left.\n");
		 printf("Press key Q to move up.\nPress key W to move down.\n");
		 printf("Press key N to move near.\nPress key M to move far.\n");
		 printf("Press any key for reset to default value.\n");
}

void keyboard(unsigned char key, int x, int y)
{ if ( key == '1' )
		{  xEye = Distance*sin(PI/3); zEye = Distance*cos(PI/3);}
  else if ( key == '2' )
  {  xEye = Distance*sin(PI/3); zEye = -Distance*cos(PI/3);}
  else if ( key == '3' )
  {  xEye = 0; zEye = -Distance;}
  else if ( key == '4' )
  {  xEye = -Distance*sin(PI/3); zEye = -Distance*cos(PI/3);}
  else if ( key == '5' )
  {  xEye = -Distance*sin(PI/3); zEye = Distance*cos(PI/3);}
  else if ( key == 'C' || key == 'c')
    theta +=  1;
		else if ( key == 'V' || key == 'v')
    theta -=  1;
		else if ( key == 'X' || key == 'x')
			 angle += 5;
		else if ( key == 'Z' || key == 'z')
			 angle -= 5;
		else if ( key == 'U' || key == 'u')
			 lookUpDown += feet;
		else if ( key == 'D' || key == 'd')
			 lookUpDown -= feet;
		else if ( key == 'R' || key == 'r')
			 lookRightLeft += feet;
		else if ( key == 'L' || key == 'l')
			 lookRightLeft -= feet;
		else if ( key == 'S' || key == 's')
			 xEye += feet;
		else if ( key == 'A' || key == 'a')
			 xEye -= feet;
		else if ( key == 'Q' || key == 'q')
			 yEye += feet;
		else if ( key == 'W' || key == 'w')
			 yEye -= feet;
		else if ( key == 'N' || key == 'n')
			 zEye -= feet;
		else if ( key == 'M' || key == 'm')
		  zEye += feet;
		else
		{ theta = 0; 
		  xEye = 0.0; 
				yEye = Distance/2; 
				zEye = Distance; 
				angle = 60;
				lookRightLeft = 0.0;
				lookUpDown = 5*feet;
		}
  glutPostRedisplay();
}

int main (int argc, char** argv)
{ glutInit (&argc, argv);
  glutInitDisplayMode (GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGB);
  glutInitWindowSize (500, 500);
		glutInitWindowPosition (400, 0);
  glutCreateWindow ("Sacred Grove - Tuan Phan");
  myInit ();
  glutKeyboardFunc(keyboard);
  glutDisplayFunc (display);
		glutIdleFunc(myIdle);
  glutMainLoop ();
}
