// arrow.java --- vector-drawing tool for web pages.

import java.awt.* ;
import java.applet.*;
import java.lang.Math;
import java.util.StringTokenizer;
import java.lang.Thread;

// The applet frame will be divided into graph paper with xCols columns and yRows rows.
// The origin will be in the center, and y increases upward.

// class arrow deals with applet events and get the parameter from the web page
public class arrow extends Applet 
{
 
  // range of the values graphed, with defaults
  double xMin = -10;
  double xMax =  10;
  double yMin = -10;
  double yMax =  10;

  // components
  graphPaper gr;
  Checkbox   labelsCB;
  Checkbox   gridCB;
  Button     eraseB;
  boolean drawGrids  = false;
  boolean drawLabels = true;

  boolean enableDraw = false;

  // number of vectors, number of points, number of ants
  final int aSize = 16;

  // array of points to plot. One point per row, (x, y)
  double[][] points  = new double[aSize][2];
  String[]   pLabels = new String[aSize];
  int        numberOfPoints = 0;

  // array of ants to plot. One ant per row, (x, y)
  double[][] ants  = new double[aSize][2];
  String[]   antLabels = new String[aSize];
  int        numberOfAnts = 0;

  // array of vectors to draw. One vector per row, (x1, y1, x2, y2)
  double[][] vector  = new double[aSize][4];
  Color[]    colors  = new Color[aSize];
  String[]   labels  = new String[aSize];
  int        numberOfVectors  = 0;

  // get parameters from the applet
  //
  public void getAppletDimensions()
  {
    // get parameters for range of the x and y values
    try
    {
      String parameter;
      parameter = getParameter("xMin") ;
      xMin = (parameter == null ? -10 : new Double( parameter ).doubleValue() );
      parameter = getParameter("xMax") ;
      xMax = (parameter == null ?  10 : new Double( parameter ).doubleValue() ); 
      parameter = getParameter("yMin") ;
      yMin = (parameter == null ? -10 : new Double( parameter ).doubleValue() ); 
      parameter = getParameter("yMax") ;
      yMax = (parameter == null ?  10 : new Double( parameter ).doubleValue() ); 
    }
    catch ( NumberFormatException e )
    {
      showStatus("bad range parameter --- ignored");
      xMin = -10;
      xMax =  10;
      yMin = -10;
      yMax =  10;
    }
  }

  // get parameters for the points to plot
  public void getAppletPoints()
  {
    
    String parameter;
    
    String pointName = "point" + numberOfPoints;
    while ( (numberOfPoints < points.length) && 
            (parameter = getParameter(pointName)) != null )
    {
      if ( parameter != null )
      {
        try
        {
          StringTokenizer st = new StringTokenizer( parameter, ",", true ); 
          String x1parm      = st.nextToken();
          String delimiter   = st.nextToken();
          String y1parm      = st.nextToken();
          
          points[numberOfPoints][0] = new Double( x1parm ).doubleValue() ;
          points[numberOfPoints][1] = new Double( y1parm ).doubleValue() ;
          
        }
        catch (NumberFormatException e )
        {
          showStatus("bad point " + numberOfPoints + " parameter.");
        }
      }
      
      numberOfPoints++ ;
      pointName = "point" + numberOfPoints;
    }
    
  }

  // get labels for  the points
  public void getAppletPLabels()
  {
    for ( int count=0; count<numberOfPoints; count++ )
    {
      String labelNumber = "plabel" + count;
      String parameter   = getParameter(labelNumber) ;
    
      if ( parameter != null )
      {
        parameter = parameter.trim();
        pLabels[ count ] = parameter;
      }
    }
    
  }

  // get parameters for the ants to plot
  public void getAppletAnts()
  {
    
    String parameter;
    
    String Name = "ant" + numberOfAnts;
    while ( (numberOfAnts < ants.length) && 
            (parameter = getParameter(Name)) != null )
    {
      if ( parameter != null )
      {
        try
        {
          StringTokenizer st = new StringTokenizer( parameter, ",", true ); 
          String x1parm      = st.nextToken();
          String delimiter   = st.nextToken();
          String y1parm      = st.nextToken();
          
          ants[numberOfAnts][0] = new Double( x1parm ).doubleValue() ;
          ants[numberOfAnts][1] = new Double( y1parm ).doubleValue() ;
          
        }
        catch (NumberFormatException e )
        {
          showStatus("bad ant " + numberOfAnts + " parameter.");
        }
      }
      
      numberOfAnts++ ;
      Name = "ant" + numberOfAnts;
    }
    
  }

  // get labels for  the ants
  public void getAppletALabels()
  {
    for ( int count=0; count<numberOfAnts; count++ )
    {
      String labelNumber = "alabel" + count;
      String parameter   = getParameter(labelNumber) ;
    
      if ( parameter != null )
      {
        antLabels[ count ] = parameter.trim();
      }
    }
    
  }

  // get parameters for the vectors to draw
  public void getAppletVectors()
  {
    
    String parameter;
    
    String vectorName = "vector" + numberOfVectors;
    while ( (numberOfVectors < vector.length) &&
            (parameter = getParameter(vectorName)) != null )
    {
      if ( parameter != null )
      {
        try
        {
          StringTokenizer st = new StringTokenizer( parameter, ",", true ); 
          String x1parm      = st.nextToken();
          String delimiter   = st.nextToken();
          String y1parm      = st.nextToken();
          delimiter          = st.nextToken();
          String x2parm      = st.nextToken();
          delimiter          = st.nextToken();
          String y2parm      = st.nextToken();
          
          vector[numberOfVectors][0] = new Double( x1parm ).doubleValue() ;
          vector[numberOfVectors][1] = new Double( y1parm ).doubleValue() ;
          vector[numberOfVectors][2] = new Double( x2parm ).doubleValue() ;
          vector[numberOfVectors][3] = new Double( y2parm ).doubleValue() ;
          
        }
        catch (NumberFormatException e )
        {
          showStatus("bad vector parameter");
        }
      }
      
      numberOfVectors++ ;
      vectorName = "vector" + numberOfVectors;
    }
    
  }


  // get the colors of the vectors (if any)
  public void getAppletColors()
  {
    
    for ( int count=0; count<numberOfVectors; count++ )
    {
      String colorNumber = "color" + count;
      String parameter   = getParameter(colorNumber) ;
    
      if ( parameter != null )
      {
        parameter = parameter.trim();
        if      ( parameter.equalsIgnoreCase("black") )     
          colors[count] = Color.black ;
        else if ( parameter.equalsIgnoreCase("blue") )      
          colors[count] = Color.blue ;
        else if ( parameter.equalsIgnoreCase("cyan") )      
          colors[count] = Color.cyan ;
        else if ( parameter.equalsIgnoreCase("darkGray") )  
          colors[count] = Color.darkGray ;
        else if ( parameter.equalsIgnoreCase("gray") )      
          colors[count] = Color.gray ;
        else if ( parameter.equalsIgnoreCase("green") )     
          colors[count] = Color.green.darker() ;
        else if ( parameter.equalsIgnoreCase("lightGray") ) 
          colors[count] = Color.lightGray ;
        else if ( parameter.equalsIgnoreCase("magenta") )  
          colors[count] = Color.magenta ;
        else if ( parameter.equalsIgnoreCase("orange") )    
          colors[count] = Color.orange ;
        else if ( parameter.equalsIgnoreCase("pink") )      
          colors[count] = Color.pink ;
        else if ( parameter.equalsIgnoreCase("red") )       
          colors[count] = Color.red ;
        else if ( parameter.equalsIgnoreCase("white") )     
          colors[count] = Color.white ;
        else if ( parameter.equalsIgnoreCase("yellow") )    
          colors[count] = Color.yellow ;
      }
      
    }
    
  }

  // get labels for  the vectors (if any)
  public void getAppletLabels()
  {
    for ( int count=0; count<numberOfVectors; count++ )
    {
      String labelNumber = "label" + count;
      String parameter   = getParameter(labelNumber) ;
    
      if ( parameter != null )
      {
        parameter = parameter.trim();
        labels[ count ] = parameter;
      }
    }
    
  }

  public void  getAppletDrawEnable()
  {
    String parameter = getParameter("enableDraw");
    if ( parameter != null )
      enableDraw = true;
    else
      enableDraw = false;
  }

  public void init()
  {
    for ( int j=0; j<colors.length; j++ )
    {
      if      ( j%7 == 0 ) colors[j] = Color.blue;
      else if ( j%7 == 1 ) colors[j] = Color.green;
      else if ( j%7 == 2 ) colors[j] = Color.red;
      else if ( j%7 == 3 ) colors[j] = Color.cyan;
      else if ( j%7 == 4 ) colors[j] = Color.magenta;
      else if ( j%7 == 5 ) colors[j] = Color.orange;
      else if ( j%7 == 6 ) colors[j] = Color.white;
    }

    getAppletDimensions();
    getAppletVectors();
    getAppletColors(); 
    getAppletLabels();
    getAppletPoints();
    getAppletPLabels();
    getAppletAnts();
    getAppletALabels();
    getAppletDrawEnable();

    gr = new graphPaper( xMin, xMax, yMin, yMax,
      points, pLabels, numberOfPoints,ants, antLabels, numberOfAnts,
      vector, labels, numberOfVectors, colors );

    gr.resize( bounds().width, (int)Math.round( bounds().height*0.90) );
    gr.setDrawEnabled( enableDraw );
    add( gr );

    labelsCB = new Checkbox("labels");
    labelsCB.setState( drawLabels );
    gridCB   = new Checkbox("grid");
    gridCB.setState( drawGrids );
    add( labelsCB );
    add( gridCB );
    if ( enableDraw ) 
    {
      eraseB = new Button("erase");
      add( eraseB );
    }

  }


  // Respond to click on the gridCB checkBox and the labelsCB checkBox
  public boolean action ( Event evt, Object obj )
  {
    if ( evt.target == gridCB )
    {
      gr.setGrids( gridCB.getState() );
      return true;
    }
    else if ( evt.target == labelsCB )
    {
      gr.setLabels( labelsCB.getState() );
      return true;
    }
    else if ( evt.target == eraseB )
    {
      gr.setnumberOfVectors (numberOfVectors );
      return true;
    }
    return true;
  }

}


////////////////////////////////////////////////////////////////////////////////
//
//  class graphPaper does the actual drawing of the vectors, points, and ants on
//  the applet
//
////////////////////////////////////////////////////////////////////////////////
class graphPaper extends Canvas
{
 
  // range of values that this graphPaper is expected to plot
  double xMin = -10;
  double xMax =  10;
  double yMin = -10;
  double yMax =  10;

  // array of points to plot. One point per row, (x, y)
  double[][] points  ;
  String[]   pLabels ;
  int        numberOfPoints = 0;

  // array of ants to plot. One ant per row, (x, y)
  double[][] ants  ;
  String[]   antLabels  ;
  int        numberOfAnts  ;

  // array of vectors to draw. One vector per row, (x1, y1, x2, y2)
  double[][] vector  ;
  Color[]    colors  ;
  String[]   labels  ;

  // numberOfVectors will become the number of vectors in the parameter list
  int numberOfVectors  = 0;

  //
  boolean drawGrids     = false; 
  boolean drawLabels    = true;
  boolean workingOnLine = false;
  boolean drawEnabled   = false;

  // graphics context
  Graphics gr;

  public graphPaper( double xm, double xM, double ym, double yM,
    double[][] pt, String[] pL, int pN, double[][] at, String[] aL, int aN,
    double[][] vt, String[] vL, int vN, Color[] cl )
  {
    xMin = xm;
    xMax = xM;
    yMin = ym;
    yMax = yM;
    points = pt; pLabels = pL; numberOfPoints= pN;
    ants   = at; antLabels = aL; numberOfAnts = aN;
    vector = vt; labels = vL; numberOfVectors = vN; colors = cl;
  }

  public void setGrids( boolean value )
  { 
    drawGrids = value;
    repaint();
  }

  public void setLabels( boolean value )
  {
    drawLabels = value ;
    repaint();
  }

  public void setnumberOfVectors ( int value )
  {
    numberOfVectors = value;
    repaint();
  }

  public void setDrawEnabled ( boolean value )
  {
    drawEnabled = value;
    repaint();
  }

  // transform a graph paper x into an applet x
  int transformX( double x )
  {
    double range = (xMax - xMin) ;
    if ( range == 0.0 ) range = 1.0;
    double width = bounds().width-1;
    return (int)Math.round( (width/range)*x - (width*xMin)/range );
  }

  // transform a graph paper y into an applet y
  int transformY( double y )
  {
    double range  = yMax - yMin;
    if ( range == 0.0 ) range = 1.0;
    double height = bounds().height-1;
    return (int)Math.round( (-height/range)*y + (height*yMax)/range );
  }

  // transform an applet x into a graph paper x
  double inverseX ( int x )
  {
    double range = xMax - xMin;
    double width = bounds().width-1;
    return (range/width)*x + xMin;
  }

  // transform an applet y into a graph paper y
  double inverseY ( int y )
  {
    double range = yMax - yMin;
    double height = bounds().height-1;
    return (-range/height)*y + yMax;
  }

  // draw the grid lines on the graph paper
  void drawGrid()
  {
    // draw vertical lines
    for ( double x = xMin; x < xMax; x++ )
      drawLine( x, yMin, x, yMax );
   
    // draw horizontal lines
    for ( double y = yMin; y < yMax; y++ )
      drawLine( xMin, y, xMax, y );
  }

  // draw a graphpaper point
  void drawPoint(  double x1, double y1 )
  {
     gr.fillOval( transformX( x1 )-2, transformY( y1 )-2, 4, 4 );
  }

  void labelPoint( String label, double x, double y)
  {
    gr.drawString( label, transformX(x)+5, transformY(y)+5 );
  }

  void drawAnt(  double x1, double y1 )
  {
    int x = transformX( x1 );
    int y = transformY( y1 );

    gr.fillOval( x, y-6, 4, 4 );
    gr.fillOval( x, y-2, 4, 4 );
    gr.fillOval( x, y+1, 4, 8 );

    gr.drawLine( x+4, y,   x+7, y-3 );
    gr.drawLine( x+4, y+2, x+7, y+3 );

    gr.drawLine( x,   y,   x-3, y-3 );
    gr.drawLine( x,   y+2, x-3, y+3 );
  }

  void labelAnt( String label, double x, double y)
  {
    gr.drawString( label, transformX(x)+10, transformY(y) );
  }

  // draw a graphpaper line
  void drawLine(  double x1, double y1, double x2, double y2 )
  {
    gr.drawLine( transformX( x1 ), transformY( y1 ), 
                 transformX( x2 ), transformY( y2 ) );
  }

  // draw an arrow with an arrow head
  void drawArrow( double x1, double y1, double x2, double y2 )
  {
    double length = Math.sqrt( (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1) ) + 0.2;
    double angle  = 0.2/Math.pow( length, 1.3);

    // draw the shaft of the arrow
    drawLine( x1, y1, x2, y2 );

    // translate end of arrow to origin
    double tipx = x2 - x1;
    double tipy = y2 - y1;

    // draw two barbs
    for ( int barb = 0; barb<2; barb++ )
    {
      // rotate shaft to slight angle from its original position
      double newx = tipx*Math.cos( angle ) - tipy*Math.sin( angle );
      double newy = tipx*Math.sin( angle ) + tipy*Math.cos( angle );
      
      // shrink it, so its end is now endpoint of a barb
      newx *= 0.90; newy *= 0.90;
      
      // translate endpoint back to original location
      newx += x1;   newy += y1;

      // connect tip of arrow to end of barb
      drawLine( x2, y2, newx, newy );
      
      // start second barb
      angle *= -1;
    }
  }


  public void labelArrow( String label, double x1, double y1, double x2, double y2)
  {
    // midpoint of the arrow
    double xm = x1+(x2-x1)/2.0; double ym = y1+(y2-y1)/2.0; 

    // perpendicular to the arrow
    double xp = -y2+y1;      double yp = x2-x1;
    double plength = Math.sqrt( xp*xp + yp*yp );
    xp /= plength;
    yp /= plength;

    // point to place the label
    int lx =  transformX(xm + xp*0.5);
    int ly =  transformY(ym + yp*0.5);

    // draw the label
    gr.drawString( label, lx, ly );

  }

  public boolean mouseDown ( Event evt, int x, int y)
  {
    if ( (numberOfVectors < vector.length ) && drawEnabled ) 
    {
      workingOnLine = true;
      numberOfVectors++ ;
      setnumberOfVectors( numberOfVectors ); 
      vector[ numberOfVectors-1 ][0] = inverseX( x );
      vector[ numberOfVectors-1 ][1] = inverseY( y );
      vector[ numberOfVectors-1 ][2] = inverseX( x );
      vector[ numberOfVectors-1 ][3] = inverseY( y );
    }
    return true;
  }

  public boolean mouseDrag (  Event evt, int x, int y)
  {
    if ( workingOnLine )
    {
      vector[ numberOfVectors-1 ][2] = inverseX( x );
      vector[ numberOfVectors-1 ][3] = inverseY( y );
      repaint();
    }
    return true;
  }


  public boolean mouseUp  ( Event evt, int x, int y)
  {
    if ( workingOnLine )
    {
      workingOnLine = false;
      vector[ numberOfVectors-1 ][2] = inverseX( x );
      vector[ numberOfVectors-1 ][3] = inverseY( y );
      repaint();
   }
    return true;
  }

  // draw the picture on the graphpaper
  public void paint(Graphics  g)
  {
    
    // possibly draw grid lines---do this first
    if ( drawGrids )
    {
      setForeground( Color.gray.brighter() );
      gr = getGraphics();
      drawGrid();
    }
    
    // outline the graph paper---overwrite grid lines
    setForeground( Color.gray );
    gr = getGraphics();
    drawLine( xMin, yMax, xMax, yMax );
    drawLine( xMax, yMax, xMax, yMin );
    drawLine( xMax, yMin, xMin, yMin );
    drawLine( xMin, yMin, xMin, yMax );
    
    // draw the coordinate axes
    drawLine( xMin, 0, xMax, 0 );
    drawLine( 0, yMin, 0, yMax );
    
    // put in the tick marks
    for ( double tick = xMin; tick<=xMax; tick++ )
    {
      drawLine( tick, 0.2, tick, -0.2 );
    }
    for ( double tick = yMin; tick<=yMax; tick++ )
    {
      drawLine( 0.2, tick, -0.2, tick);
    }
    
    // draw the vectors
    for ( int j=0; j<numberOfVectors; j++ )
    {
      setForeground( colors[j] );
      gr = getGraphics();
      drawArrow( vector[j][0], vector[j][1], vector[j][2], vector[j][3] );
    }
    
    // optionally label the vectors
    if ( drawLabels )
    {
      for ( int j=0; j<numberOfVectors; j++ )
      {
        if ( labels[j] != null )
        {
          setForeground( colors[j] );
          gr = getGraphics();
          labelArrow( labels[j], vector[j][0], 
            vector[j][1], vector[j][2], vector[j][3] );
        }
      }
    }
    
    // draw the points
    for ( int j=0; j<numberOfPoints; j++ )
    {
      setForeground( Color.black );
      gr = getGraphics();
      drawPoint( points[j][0], points[j][1] );
    }
    
    // optionally label the points
    if ( drawLabels )
    {
      for ( int j=0; j<numberOfPoints; j++ )
      {
        if ( pLabels[j] != null )
        {
          setForeground( Color.black );
          gr = getGraphics();
          labelPoint( pLabels[j], points[j][0], points[j][1] );
        }
      }
    }
    
    // draw the ants
    for ( int j=0; j<numberOfAnts; j++ )
    {
      setForeground( Color.black );
      gr = getGraphics();
      drawAnt( ants[j][0], ants[j][1] );
    }
    
    // optionally label the ants
    if ( drawLabels )
    {
      for ( int j=0; j<numberOfAnts; j++ )
      {
        if ( antLabels[j] != null )
        {
          setForeground( Color.black );
          gr = getGraphics();
          labelAnt( antLabels[j], ants[j][0], ants[j][1] );
        }
      }
    }
    
  }


}
