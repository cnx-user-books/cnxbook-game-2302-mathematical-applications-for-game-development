// drawVector3D.java --- vector-drawing tool for web pages.
//
// revised version 010-13-97

import java.awt.* ;
import java.applet.*;
import java.lang.Math;
import java.util.StringTokenizer;
import java.lang.Thread;

class point3D
{
  double x, y, z;

  public point3D()
  {
    super();
  }

  public point3D( double x, double y, double z )
  {
    this.x = x; this.y = y; this.z = z;
  }
}

class graphObject3D
{
  Color  color = null;
  String label = null;

  public graphObject3D()
  {
  }

  public void setColor( Color c )
  {
    color =  c;
  }

  public void setLabel( String lb )
  {
    label = new String( lb );
  }
}

class Arrow3D extends graphObject3D
{
  double x1, y1, z1;
  double x2, y2, z2;

  public Arrow3D( )
  {
    this.x1 = 0; this.y1 = 0; this.z1 = 0;
    this.x2 = 0; this.y2 = 0; this.z2 = 0;
  }

  public Arrow3D( double x1, double y1, double z1, 
                  double x2, double y2, double z2 )
  {
    this.x1 = x1; this.y1 = y1; this.z1 = z1;
    this.x2 = x2; this.y2 = y2; this.z2 = z2;
  }

  public Arrow3D( double x1, double y1, double z1,
                  double x2, double y2, double z2, Color c )
  {
    this( x1, y1, z1, x2, y2, z2 );
    color = c;
  }

  public Arrow3D(double x1, double y1, double z1,
                 double x2, double y2, double z2, Color c, String l )
  {
    this( x1, y1, z1, x2, y2, z2, c );
    label = new String( l );
  }

}// end Arrow3D

// class arrow deals with applet events and get the parameter from the web page
public class drawVector3D extends Applet 
{
 
  // the viewscreen is the XY plane
  double xMin = -10;
  double xMax =  10;
  double yMin = -10;
  double yMax =  10;
  double zMin = -10;
  double zMax =  10;

  // components
  graphPaper3D gr;
  Checkbox   labelsCB;
  Checkbox   gridCB;
  Button     eraseB;
  Label      angleL;
  Scrollbar  angleSB;

  boolean drawGrids  = false;
  boolean drawLabels = true;

  boolean enableDraw = false;

  // number of vectors, number of points, number of ants
  final int aSize = 16;

  // get parameters from the applet
  //
  public void getAppletDimensions()
  {
    // get parameters for range of the x and y values
    try
    {
      String parameter;
      parameter = getParameter("xMin") ;
      xMin = (parameter == null ? -10 : new Double( parameter ).doubleValue() );
      parameter = getParameter("xMax") ;
      xMax = (parameter == null ?  10 : new Double( parameter ).doubleValue() ); 
      parameter = getParameter("yMin") ;
      yMin = (parameter == null ? -10 : new Double( parameter ).doubleValue() ); 
      parameter = getParameter("yMax") ;
      yMax = (parameter == null ?  10 : new Double( parameter ).doubleValue() ); 
      parameter = getParameter("zMin") ;
      zMin = (parameter == null ? -10 : new Double( parameter ).doubleValue() ); 
      parameter = getParameter("zMax") ;
      zMax = (parameter == null ?  10 : new Double( parameter ).doubleValue() ); 
    }
    catch ( NumberFormatException e )
    {
      showStatus("bad range parameter --- ignored");
      xMin = -10;
      xMax =  10;
      yMin = -10;
      yMax =  10;
      zMin = -10;
      zMax =  10;
    }
  }


  // get parameters for the vectors to draw
  public void getAppletVectors()
  {
    for ( int vect=0; vect<15; vect++ )
    {
      String vectorName = "vector" + vect ;
      String parameter  = getParameter(vectorName) ;

      if ( parameter != null )
      {
        try
        {
          StringTokenizer st = new StringTokenizer( parameter, ",", true ) ; 
          String x1parm      = st.nextToken() ;
          String delimiter   = st.nextToken() ;
          String y1parm      = st.nextToken() ;
          delimiter          = st.nextToken() ;
          String z1parm      = st.nextToken() ;
          delimiter          = st.nextToken() ;

          String x2parm      = st.nextToken() ;
          delimiter          = st.nextToken() ;
          String y2parm      = st.nextToken() ;
          delimiter          = st.nextToken() ;
          String z2parm      = st.nextToken() ;
          
          double x1 = new Double( x1parm ).doubleValue() ;
          double y1 = new Double( y1parm ).doubleValue() ;
          double z1 = new Double( z1parm ).doubleValue() ;

          double x2 = new Double( x2parm ).doubleValue() ;
          double y2 = new Double( y2parm ).doubleValue() ;
          double z2 = new Double( z2parm ).doubleValue() ;
                   
          Color  cl = getColor(vect) ;
          String lb = getLabel(vect) ;
          gr.addVector( new Arrow3D( x1, y1, z1, x2, y2, z2, cl, lb ) ) ;
        }
        catch (NumberFormatException e )
        {
          showStatus("bad vector parameter") ;
        }
      }
      
    }
    
  }


  public Color getColor( int count )
  {
    String colorNumber = "color" + count;
    String parameter   = getParameter(colorNumber) ;
    
    if ( parameter != null )
    {
      parameter = parameter.trim();
      if      ( parameter.equalsIgnoreCase("black") )     
        return( Color.black );
      else if ( parameter.equalsIgnoreCase("blue") )      
        return( Color.blue  );
      else if ( parameter.equalsIgnoreCase("cyan") )      
        return( Color.cyan );
      else if ( parameter.equalsIgnoreCase("darkGray") )  
        return( Color.darkGray  );
      else if ( parameter.equalsIgnoreCase("gray") )      
        return( Color.gray  );
      else if ( parameter.equalsIgnoreCase("green") )     
        return( Color.green  );
      else if ( parameter.equalsIgnoreCase("lightGray") ) 
        return( Color.lightGray  );
      else if ( parameter.equalsIgnoreCase("magenta") )  
        return( Color.magenta  );
      else if ( parameter.equalsIgnoreCase("orange") )    
        return( Color.orange  );
      else if ( parameter.equalsIgnoreCase("pink") )      
        return( Color.pink  );
      else if ( parameter.equalsIgnoreCase("red") )       
        return( Color.red  );
      else if ( parameter.equalsIgnoreCase("white") )     
        return( Color.white  );
      else if ( parameter.equalsIgnoreCase("yellow") )    
        return( Color.yellow  );
      else
        return( Color.black );     
    }
    else
    {
      return( Color.black );     
    }
  }
      
 
  // get labels for  the vectors (if any)
  public String getLabel( int count )
  {
    String labelNumber = "label" + count;
    String parameter   = getParameter(labelNumber) ;    
    if ( parameter != null )
      return( parameter.trim() );    
    else
      return null;
  }

  public void  getAppletDrawEnable()
  {
    String parameter = getParameter("enableDraw");
    if ( parameter != null )
      enableDraw = true;
    else
      enableDraw = false;
  }

  public void init()
  {

    getAppletDimensions();
    gr = new graphPaper3D( xMin, xMax, yMin, yMax, zMin, zMax );
    getAppletVectors();
    getAppletDrawEnable();

    gr.resize( bounds().width, (int)Math.round( bounds().height*0.75) );
    gr.setDrawEnabled( enableDraw );
    add( gr );

    labelsCB = new Checkbox("labels");
    labelsCB.setState( drawLabels );
    gridCB   = new Checkbox("grid");
    gridCB.setState( drawGrids );
    add( labelsCB );
    add( gridCB );
    angleL  = new Label("Rotate View");
    add( angleL );
    angleSB = new Scrollbar( Scrollbar.HORIZONTAL, -20, 1, -45, 45 );
    add( angleSB );
  
    if ( enableDraw ) 
    {
      eraseB = new Button("erase");
      add( eraseB );
    }

  }


  // Respond to click on the gridCB checkBox and the labelsCB checkBox
  public boolean action ( Event evt, Object obj )
  {
    if ( evt.target == gridCB )
    {
      gr.setGrids( gridCB.getState() );
      gr.repaint();
    }
    else if ( evt.target == labelsCB )
    {
      gr.setLabels( labelsCB.getState() );
      gr.repaint();
    }
    return true;
  }

  public boolean handleEvent( Event evt )
  {
    if ( evt.target == angleSB )
    {
      gr.setAngle( -(angleSB.getValue()) );
      gr.repaint();
      return true;
    }
    return super.handleEvent( evt );
  }
}


////////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////////
class graphPaper3D extends Canvas
{
  
  // range of values that this graphPaper is expected to plot
  double xMin = -10;
  double xMax =  10;
  double yMin = -10;
  double yMax =  10;
  double zMin = -10;
  double zMax =  10;
  
  boolean drawGrids     = false; 
  boolean drawLabels    = true;
  boolean workingOnLine = false;
  boolean drawEnabled   = false;

  double  angle = 20.0;  // amount to rotate lines

  // array of vectors to draw. 
  final int aSize = 15;
  Arrow3D[] vector  = new Arrow3D[aSize];
  int       numberOfVectors  = 0;
  
  // graphics context
  Graphics grContext;
  
  public void setAngle( int a )
  {
    angle = (double)a;
  }

  public void addVector( Arrow3D v )
  {
    vector[ numberOfVectors++ ] = v;
  }

  public graphPaper3D( double xm, double xM, double ym, double yM, double zm, double zM )
  {
    xMin = xm;
    xMax = xM;
    yMin = ym;
    yMax = yM;
    zMin = zm;
    zMax = zM;
  }
  
  public void setGrids( boolean value )
  { 
    drawGrids = value;
    repaint();
  }
  
  public void setLabels( boolean value )
  {
    drawLabels = value ;
    repaint();
  }
  
  public void setDrawEnabled ( boolean value )
  {
    drawEnabled = value;
    repaint();
  }
  
  // transform a graph paper x into an applet x
  int transformX( double x )
  {
    double range = (xMax - xMin) ;
    if ( range == 0.0 ) range = 1.0;
    double width = bounds().width-1;
    return (int)Math.round( (width/range)*x - (width*xMin)/range );
  }
  
  // transform a graph paper y into an applet y
  int transformY( double y )
  {
    double range  = yMax - yMin;
    if ( range == 0.0 ) range = 1.0;
    double height = bounds().height-1;
    return (int)Math.round( (-height/range)*y + (height*yMax)/range );
  }
  
  // transform an applet x into a graph paper x
  double inverseX ( int x )
  {
    double range = xMax - xMin;
    double width = bounds().width-1;
    return (range/width)*x + xMin;
  }
  
  // transform an applet y into a graph paper y
  double inverseY ( int y )
  {
    double range = yMax - yMin;
    double height = bounds().height-1;
    return (-range/height)*y + yMax;
  }
  
  // draw the grid lines on the graph paper
  void drawGrid()
  {
    int step = 1;

    // draw lines in XY plane
    for ( double x = xMin; x < xMax; x+=step )
      draw3DLine( x, yMin, 0, x, yMax, 0 );
    for ( double y = yMin; y < yMax; y+=step )
      draw3DLine( xMin, y, 0, xMax, y, 0 );

    // draw lines in YZ plane
    for ( double y = yMin; y < yMax; y+=step )
      draw3DLine( 0, y, zMin, 0, y, zMax );
    for ( double z = zMin; z < zMax; z+=step )
      draw3DLine( 0, yMin, z, 0, yMax, z );

    // draw the floor
    for ( double x = xMin; x < xMax; x+=step )
      draw3DLine( x, 0, zMin, x, 0, zMax );
    for ( double z = zMin; z < zMax; z+=step )
      draw3DLine( xMin, 0, z, xMax, 0, z );
  }
  
  // draw a  line in the XY plane
  void drawLine(  double x1, double y1, double x2, double y2 )
  {
    grContext.drawLine( transformX( x1 ), transformY( y1 ), 
      transformX( x2 ), transformY( y2 ) );
  }

  // draw a 3D line
  void draw3DLine(  double x1, double y1, double z1,
                    double x2, double y2, double z2 )
  {
    // rotate the points about the y axis
    double radians =  angle*(Math.PI/180.0);
    x1 = x1*Math.cos( radians ) - z1*Math.sin( radians );
    z1 = x1*Math.sin( radians ) + z1*Math.cos( radians );

    x2 = x2*Math.cos( radians ) - z2*Math.sin( radians );
    z2 = x2*Math.sin( radians ) + z2*Math.cos( radians );

    // move the line in 3D space
    z1 = z1-5; y1 = y1-3;
    z2 = z2-5; y2 = y2-3;

    // transform the endpoints to 2D
    double newx1 = transform3D( x1, z1, 8.0 );
    double newy1 = transform3D( y1, z1, 8.0 );
    double newx2 = transform3D( x2, z2, 8.0 );
    double newy2 = transform3D( y2, z2, 8.0 );

    drawLine( newx1, newy1+2, newx2, newy2+2 );
  }

  // transform x or y coordintate based on eye position and z
  double transform3D ( double xy, double z, double eye )
  {
    return xy/( 1.0 - z/eye );
  }

  public void placeLabel( String label, double x, double y, double z)
  {
    // rotate the point about the y axis
    double radians =  angle*(Math.PI/180.0);
    x = x*Math.cos( radians ) - z*Math.sin( radians );
    z = x*Math.sin( radians ) + z*Math.cos( radians );

    // move the point in 3D space
    z = z-5; y = y-3;
    double lx = transform3D( x, z, 8.0 );
    double ly = transform3D( y, z, 8.0 );

    int lbx   = transformX( lx );
    int lby   = transformY( ly+2 );

    // draw the label
    grContext.drawString( label, lbx, lby );
  }
  
  // draw the picture on the graphpaper
  public void paint( Graphics g)
  {
    grContext =   getGraphics();

    // possibly draw grid lines---do this first
    if ( drawGrids )
    {
      grContext.setColor( Color.gray.brighter() );
      drawGrid();
    }
    
    // outline the graph paper---overwrite grid lines
    grContext.setColor( Color.gray );
    drawLine( xMin, yMax, xMax, yMax );
    drawLine( xMax, yMax, xMax, yMin );
    drawLine( xMax, yMin, xMin, yMin );
    drawLine( xMin, yMin, xMin, yMax );
    
    // draw the coordinate axes
    draw3DLine( xMin, 0, 0,   xMax, 0, 0 ); placeLabel( "X", xMax, 0.0, 0.0 );
    draw3DLine( 0, yMin, 0,   0, yMax, 0 ); placeLabel( "Y", 1, yMax, 0.0 );
    draw3DLine( 0, 0,   zMin, 0, 0, zMax ); placeLabel( "Z", .1, 0.1, zMax );
    
    // put in the tick marks
    for ( double tick = xMin; tick<=xMax; tick++ )
      draw3DLine( tick, 0.2, 0.0, tick, -0.2, 0.0 );
    for ( double tick = yMin; tick<=yMax; tick++ )
      draw3DLine( 0.2, tick, 0.0, -0.2, tick, 0.0);
    for ( double tick = zMin; tick<=zMax; tick++ )
      draw3DLine( 0.0, -0.2, tick, 0.0, 0.2, tick );
    
    // draw each vector
    for ( int j=0; j< numberOfVectors; j++ )
    {
      drawArrow( vector[j] );
      if ( drawLabels )
      {
        double xp = (vector[j].x2 - vector[j].x1)/2;
        double yp = (vector[j].y2 - vector[j].y1)/2;
        double zp = (vector[j].z2 - vector[j].z1)/2;

        placeLabel( vector[j].label, xp, yp, zp );
      }
    }
  }


  public void drawArrow( Arrow3D a )
  {

    grContext.setColor( a.color );
    double length = Math.sqrt( (a.x2-a.x1)*(a.x2-a.x1) + 
                               (a.y2-a.y1)*(a.y2-a.y1) +
                               (a.z2-a.z1)*(a.z2-a.z1)) + 0.2;
    double angle  = 0.2/Math.pow( length, 1.3);

    // draw the shaft of the arrow
    draw3DLine( a.x1, a.y1, a.z1, a.x2, a.y2, a.z2 );

    // translate end of arrow to origin
    double tipx = a.x2 - a.x1;
    double tipy = a.y2 - a.y1;

    // draw two barbs
    for ( int barb = 0; barb<2; barb++ )
    {
      // rotate shaft to slight angle from its original position
      double newx = tipx*Math.cos( angle ) - tipy*Math.sin( angle );
      double newy = tipx*Math.sin( angle ) + tipy*Math.cos( angle );
      
      // shrink it, so its end is now endpoint of a barb
      newx *= 0.90; newy *= 0.90;
      
      // translate endpoint back to original location
      newx += a.x1;   newy += a.y1;

      // connect tip of arrow to end of barb
      draw3DLine( a.x2, a.y2, a.z2, newx, newy, a.z2 );
      
      // start second barb
      angle *= -1;
    }
  }
  
}
