//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//======================================================//

/*Exercise02.java
Copyright 2012, R.G.Baldwin

Using Java and the game math library named GM2D01, write
a program that:

-Creates a new GM2D01.Point object with coordinate values
of 3.4 and 9.7.
-Uses the overridden toString method to get and display
the location of the point in 2D space in the format shown
by the first line in Figure 8.
-Uses the getData method to get and display the location
of the point in 2D space in the format shown by the last
two lines in Figure 8.

Your screen output should display the values shown in
Figure 8.


Tested using JDK 1.7 under WinXP and Win 7.
*********************************************************/

class Exercise02{
  public static void main(String[] args){

    GM2D01.Point point = new GM2D01.Point(
                           new GM2D01.ColMatrix(3.4,9.7));
    System.out.println(point);
    System.out.println(point.getData(0));
    System.out.println(point.getData(1));

  }//end main
}//end controlling class Exercise02
