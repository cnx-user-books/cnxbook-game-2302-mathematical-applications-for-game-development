//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//======================================================//

/*GM2D01.java 
Copyright 2008, R.G.Baldwin

The name GM2D01 is an abbreviation for GameMath2D01.

This is a game-math class, which will be expanded over 
time. The class is provided solely for educational 
purposes. No effort has been expended to optimize it in
any way. Rather, it was designed and implemented for
maximum clarity in order to help students understand
the programming details of various mathematical operations
commonly used in game programming.

Each time the class is expanded or modified, it will be
given a new name by incrementing the two digits at the
end of the name. No attempt will be made to maintain
backward compatibility from one version of the class to
the next.

This class contains a number of static top level classes.
This organizational approach was used primarily for the
purpose of gathering such classes under a single naming
unbrella while avoiding name conflicts within a single
package. For example, as time passes, and this library is 
expanded, my default package may contain class files with 
the following names:

GM2D01$Point.class
GM2D02$Point.class
GM2D03$Point.class

All real-number values used in this class are maintained
as type double.

Tested using JDK 1.6 under WinXP.
*********************************************************/

public class GM2D01{

  //An object of this class represents a 2D column matrix.
  // An object of this class is the fundamental building
  // block for several of the other classes in the
  // library.
  public static class ColMatrix{
    double[] data = new double[2];
    
    ColMatrix(double data0,double data1){
      data[0] = data0;
      data[1] = data1;
    }//end constructor
    
    public String toString(){
      return data[0] + "," + data[1];
    }//end overridden toString method
    
    public double getData(int index){
      if((index < 0) || (index > 1)) 
                    throw new IndexOutOfBoundsException();
      return data[index];
    }//end getData
    
  }//end class ColMatrix
  //====================================================//
  
  public static class Point{
    GM2D01.ColMatrix point;
    
    Point(GM2D01.ColMatrix point){
      this.point = point;
    }//end constructor
    
    public String toString(){
      return point.getData(0) + "," + point.getData(1);
    }//end toString
    
    public double getData(int index){
      if((index < 0) || (index > 1)) 
                    throw new IndexOutOfBoundsException();
      return point.getData(index);
    }//end getData
    
  }//end class Point
  //====================================================//
  
  public static class Vector{
    GM2D01.ColMatrix vector;
    
    Vector(GM2D01.ColMatrix vector){
      this.vector = vector;
    }//end constructor
    
    public String toString(){
      return vector.getData(0) + "," + vector.getData(1);
    }//end toString
    
    public double getData(int index){
      if((index < 0) || (index > 1)) 
                    throw new IndexOutOfBoundsException();
      return vector.getData(index);
    }//end getData
    
  }//end class Vector
  //====================================================//
  
  //A line is defined by two points. One is called the
  // tail and the other is called the head.
  public static class Line{
    GM2D01.Point[] line = new GM2D01.Point[2];
    
    Line(GM2D01.Point tail,GM2D01.Point head){
      this.line[0] = tail;
      this.line[1] = head;
    }//end constructor
    
    public String toString(){
      return "Tail = " + line[0].getData(0) + "," 
             + line[0].getData(1) + "\nHead = " 
             + line[1].getData(0) + "," 
             + line[1].getData(1);
    }//end toString
    
    public GM2D01.Point getTail(){
      return line[0];
    }//end getTail
    
    public GM2D01.Point getHead(){
      return line[1];
    }//end getTail

  }//end class Line
    
}//end class GM2D01
//======================================================//