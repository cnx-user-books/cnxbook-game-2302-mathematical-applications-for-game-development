//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//======================================================//

/*PointLine02.java 
Copyright 2008, R.G.Baldwin

The purpose of this program is to introduce the use of a
game-math class library named GM2D01. The class name 
GM2D01 is an abbreviation for GameMath2D01.

The program instantiates objects from the following static
top-level classes belonging to the class named GM2D01 and
then displays the contents of those objects in two 
different ways on the standard output device.

ColMatrix
Point
Vector
Line

Tested using JDK 1.6 under WinXP.
*********************************************************/

class PointLine02{
  public static void main(String[] args){

    System.out.println(
                  "Instantiate and display the contents\n"
                  + "of a new ColMatrix object");
    GM2D01.ColMatrix colMatrix = 
                            new GM2D01.ColMatrix(2.5,6.8);
    System.out.println(colMatrix);
    try{
      System.out.println(colMatrix.getData(0));
      System.out.println(colMatrix.getData(1));
      //This statenment will throw an exception on purpose
      System.out.println(colMatrix.getData(2));
    }catch(Exception e){
      System.out.println("Bad index");
    }//end catch

    System.out.println(/*blank line*/);
    System.out.println(
                  "Instantiate and display the contents\n"
                  + "of a new Point object");
    colMatrix = new GM2D01.ColMatrix(3.4,9.7);
    GM2D01.Point point = new GM2D01.Point(colMatrix);
    System.out.println(point);
    try{
      System.out.println(point.getData(0));
      System.out.println(point.getData(1));
      //This statenment will throw an exception on purpose
      System.out.println(point.getData(-1));
    }catch(Exception e){
      System.out.println("Bad index");
    }//end catch
    
    System.out.println(/*blank line*/);
    System.out.println(
                  "Instantiate and display the contents\n"
                  + "of a new Vector object");
    colMatrix = new GM2D01.ColMatrix(-1.9,7.5);
    GM2D01.Vector vector = new GM2D01.Vector(colMatrix);
    System.out.println(vector);
    try{
      System.out.println(vector.getData(0));
      System.out.println(vector.getData(1));
      //This statenment will throw an exception on purpose
      System.out.println(vector.getData(2));
    }catch(Exception e){
      System.out.println("Bad index");
    }//end catch
    
    System.out.println(/*blank line*/);
    System.out.println(
                  "Instantiate and display the contents\n"
                  + "of a new Line object");
    GM2D01.ColMatrix colMatrixTail = 
                            new GM2D01.ColMatrix(1.1,2.2);
    GM2D01.ColMatrix colMatrixHead = 
                            new GM2D01.ColMatrix(3.3,4.4);
    
    GM2D01.Point pointTail = 
                          new GM2D01.Point(colMatrixTail);
    GM2D01.Point pointHead = 
                          new GM2D01.Point(colMatrixHead);
    
    GM2D01.Line line = 
                     new GM2D01.Line(pointTail,pointHead);
    System.out.println(line);

    pointTail = line.getTail();
    System.out.println(pointTail);
    pointHead = line.getHead();
    System.out.println(pointHead);

  }//end main
}//end controlling class PointLine02
