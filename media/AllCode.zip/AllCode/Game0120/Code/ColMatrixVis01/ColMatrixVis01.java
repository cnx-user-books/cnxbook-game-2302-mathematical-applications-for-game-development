//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/03/08
//======================================================//
// zzz update to visualize col matrix
/*ColMatrixVis01.java
Copyright 2012, R.G.Baldwin

The purpose of this program is to help the student 
visualize column matrices. Two column matrices are created
using values obtained from sliders.

Two additional column matrices are created by adding and
subtracting the original matrices.

Mathematical points are created to represent the values
in the matrices in a 2D reference frame.

Displacement vectors are created for each of the points
relative to the origin.

The vectors are drawn along with Cartesian coordinate axes
in the 2D reference frame.

Text output is displayed to show the matrix values as well
as whether the two original matrices are equal.

Tested using JDK 1.7 under WinXP and Windows 7
*********************************************************/
import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JLabel;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.lang.Math;
import java.util.*;

class ColMatrixVis01{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class ColMatrixVis01
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 450;
  int vSize = 600;
  Image osi;//off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas
  
  //Panel to contain the sliders and associated labels.
  private JPanel mainPanel = new JPanel();
  
  //Sliders used to produce values for column matrices.
  private JSlider redSlider0 = new JSlider();
  private JSlider redSlider1 = new JSlider();
  private JSlider greenSlider0 = new JSlider();
  private JSlider greenSlider1 = new JSlider();

  //Storage area for values extracted from sliders.
  private int red0 = 100;
  private int red1 = 100;
  private int green0 = 100;
  private int green1 = -100;

  //Object used to erase the off-screen image.
  private Rectangle rect;

  GUI(){//constructor
    //Configure the sliders.
    redSlider0.setMaximum(100);
    redSlider0.setMinimum(-100);
    redSlider0.setMajorTickSpacing(50);
    redSlider0.setMinorTickSpacing(10);
    redSlider0.setPaintTicks(true);
    redSlider0.setPaintLabels(true);
    redSlider0.setValue(red0);
    
    redSlider1.setMaximum(100);
    redSlider1.setMinimum(-100);
    redSlider1.setMajorTickSpacing(50);
    redSlider1.setMinorTickSpacing(10);
    redSlider1.setPaintTicks(true);
    redSlider1.setPaintLabels(true);
    redSlider1.setValue(red1);
    
    greenSlider0.setMaximum(100);
    greenSlider0.setMinimum(-100);
    greenSlider0.setMajorTickSpacing(50);
    greenSlider0.setMinorTickSpacing(10);
    greenSlider0.setPaintTicks(true);
    greenSlider0.setPaintLabels(true);
    greenSlider0.setValue(green0);
    
    greenSlider1.setMaximum(100);
    greenSlider1.setMinimum(-100);
    greenSlider1.setMajorTickSpacing(50);
    greenSlider1.setMinorTickSpacing(10);
    greenSlider1.setPaintTicks(true);
    greenSlider1.setPaintLabels(true);
    greenSlider1.setValue(green1);
    
    //Set the layout manager for the panel that contains
    // the sliders and the associated labels.
    mainPanel.setLayout(new GridLayout(2,3));
    
    //Add the sliders and associated labels to the panel.
    mainPanel.add(new JLabel("   Red matrix values"));
    mainPanel.add(redSlider0);
    mainPanel.add(redSlider1);

    mainPanel.add(new JLabel("   Green matrix values"));
    mainPanel.add(greenSlider0);
    mainPanel.add(greenSlider1);
    
    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Copyright 2012, R.G.Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //Create a new drawing canvas and add it to the
    // center of the JFrame.
    myCanvas = new MyCanvas();
    this.getContentPane().add(myCanvas);
    this.getContentPane().add(
                            mainPanel,BorderLayout.SOUTH);

    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();
    
    //Configure the object that will be used to erase
    // the off-screen image.
    rect = new Rectangle(
             -osiWidth/2,-osiHeight/2,osiWidth,osiHeight);

    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    final Graphics2D g2D = 
                          (Graphics2D)(osi.getGraphics());

    //Translate the origin to the center of the
    // off-screen image.
    g2D.translate(osiWidth/2.0,osiHeight/2.0);
    
    //Erase the off-screen image.
    g2D.setColor(Color.WHITE);
    g2D.fill(rect);//erase the osi

    //Display the initial values of the column matrices
    displayColumnMatrices(g2D);
    
    //Register a listener on each of the sliders.
    redSlider0.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){
          //Re-display the column matrices each time the
          // thumb is moved on the slider.
          displayColumnMatrices(g2D);
        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener
    
    redSlider1.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){
          displayColumnMatrices(g2D);
        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener

    greenSlider0.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){
          displayColumnMatrices(g2D);
        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener
    
    greenSlider1.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){
          displayColumnMatrices(g2D);
        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener
  }//end constructor
  //----------------------------------------------------//

  //The purpose of this method is to
  // 1. Create two column matrices named redMatrix and 
  //    greenMatrix using values obtained from sliders.
  // 2. Create two more column matrices named blueMatrix
  //    and orangeMatrix by adding and subtracting the red
  //    and green matrices.
  // 3. Display text information about the matrices
  //    including whether the red and green matrices are
  //    equal.
  // 4. Create mathematical points in a 2D coordinate
  //    frame that represents the values in the matrices.
  // 5. Create mathematical displacement vectors that
  //    represent the displacements of each of the points
  //    relative to the origin.
  // 6. Create and draw graphics objects that represent
  //    each of the mathematical displacement vectors
  //    along with Cartesian coordinate axes for the
  //    2D reference frame.
  void displayColumnMatrices(Graphics2D g2D){
    
    //Get two values for each matrix from the sliders.
    red0 = redSlider0.getValue();
    red1 = redSlider1.getValue();
    green0 = greenSlider0.getValue();
    green1 = greenSlider1.getValue();
    
    //Use the slider values to create the two matrices
    // named redMatrix and greenMatrix.
    GM2D03.ColMatrix redMatrix = 
                          new GM2D03.ColMatrix(red0,red1);
    GM2D03.ColMatrix greenMatrix = 
                      new GM2D03.ColMatrix(green0,green1);
    
    //Create two additional matrices by adding and
    // subtracting the red and green matrices.
    GM2D03.ColMatrix blueMatrix = 
                               redMatrix.add(greenMatrix);
    GM2D03.ColMatrix orangeMatrix = 
                          redMatrix.subtract(greenMatrix);
    
    //Display text information about the matrices.
    System.out.println();//blank line
    System.out.println("redMatrix = " + redMatrix);
    System.out.println("greenMatrix = " + greenMatrix);
    System.out.println("redMatrix equals greenMatrix: " +
                           redMatrix.equals(greenMatrix));
    System.out.println(
              "blueMatrix = redMatrix + greenMatrix = " + 
                                              blueMatrix);
    System.out.println(
            "orangeMatrix = redMatrix - greenMatrix = " +
                                            orangeMatrix);
    
    //Create mathematical points in a 2D coordinate
    // frame that represent the values in the matrices.
    // Also create a point that represents the origin.
    GM2D03.Point origin = 
              new GM2D03.Point(new GM2D03.ColMatrix(0,0));
    GM2D03.Point redPoint = 
                              new GM2D03.Point(redMatrix);
    GM2D03.Point greenPoint = 
                            new GM2D03.Point(greenMatrix);
    GM2D03.Point bluePoint = new GM2D03.Point(blueMatrix);
    GM2D03.Point orangePoint = 
                           new GM2D03.Point(orangeMatrix);

    //Create mathematical displacement vectors that
    // represent the displacements of each of the points
    // relative to the origin.
    GM2D03.Vector redVec = 
                   origin.getDisplacementVector(redPoint);
    GM2D03.Vector greenVec = 
                 origin.getDisplacementVector(greenPoint);
    GM2D03.Vector blueVec = 
                  origin.getDisplacementVector(bluePoint);
    GM2D03.Vector orangeVec = 
                origin.getDisplacementVector(orangePoint);
    
    //The remaining code is used to create and draw
    // graphical objects.
    //Erase the off-screen image
    g2D.setColor(Color.WHITE);
    g2D.fill(rect);
   
    //Set the line thickness so that the vectors will be
    // drawn with a heavy line.
    g2D.setStroke(new BasicStroke(3));
    
    //Draw the four vectors with their tails at the
    // origin.
    g2D.setColor(Color.BLUE);
    blueVec.draw(g2D,origin);
    
    g2D.setColor(Color.ORANGE);
    orangeVec.draw(g2D,origin);
    
    g2D.setColor(Color.RED);
    redVec.draw(g2D,origin);
    
    g2D.setColor(Color.GREEN);
    greenVec.draw(g2D,origin);

    //Draw the axes with thinner lines.
    g2D.setStroke(new BasicStroke(1));
    g2D.setColor(Color.BLACK);
    drawAxes(g2D);
    
  }//end displayColumnMatrices
  //----------------------------------------------------//

  //The purpose of this method is to draw a pair of
  // Cartesian coordinate axes onto the
  // off-screen image.
  void drawAxes(Graphics2D g2D){

    //Define four points at the edges of the coordinate
    // frame and the ends of the axes.
    GM2D03.Point point0 = new GM2D03.Point(
                     new GM2D03.ColMatrix(-osiWidth/2,0));
    GM2D03.Point point1 = new GM2D03.Point(
                      new GM2D03.ColMatrix(osiWidth/2,0));
    GM2D03.Point point2 = new GM2D03.Point(
                    new GM2D03.ColMatrix(0,-osiHeight/2));
    GM2D03.Point point3 = new GM2D03.Point(
                     new GM2D03.ColMatrix(0,osiHeight/2));

    //Now define the two lines based on the end points..
    GM2D03.Line xAxis = new GM2D03.Line(point0,point1);
    GM2D03.Line yAxis = new GM2D03.Line(point2,point3);

    //Now draw a visual manifestation of each line
    // on g2D.
    xAxis.draw(g2D);
    yAxis.draw(g2D);
    
    //Repaint the display area
    myCanvas.repaint();

  }//end drawAxes
  //====================================================//

  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()

  }//end inner class MyCanvas

}//end class GUI
//======================================================//
