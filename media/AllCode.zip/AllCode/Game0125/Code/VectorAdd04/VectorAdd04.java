//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/15/08
//======================================================//

/*VectorAdd04.java 
Copyright 2008, R.G.Baldwin
Revised 02/15/08

This program illustrates the addition of a Vector to a 
Point producing a new Point. Both points and the vector
are drawn on the screen.

Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.awt.geom.*;

class VectorAdd04{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class VectorAdd04
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 225;
  int vSize = 225;
  Image osi;//an off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas
  
  GUI(){//constructor
    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Copyright 2008,R.G.Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    //Create a new drawing canvas and add it to the
    // center of the JFrame.
    myCanvas = new MyCanvas();
    this.getContentPane().add(myCanvas);
    
    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();

    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    Graphics2D g2D = (Graphics2D)(osi.getGraphics());
    
    //Draw some graphical objects on the off-screen
    // image.
    drawOffScreen(g2D);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();

  }//end constructor
  //----------------------------------------------------//
  
  //The purpose of this method is to add a Vector object
  // to a Point object and to draw the result onto an
  // off-screen image..
  void drawOffScreen(Graphics2D g2D){
    
    //Translate the origin on the off-screen
    // image and draw a pair of orthoganal axes on it.
    setCoordinateFrame(g2D);

    //Define one point
    GM2D04.Point point = new GM2D04.Point(
                            new GM2D04.ColMatrix(50,-25));
    
    //Define one vector.
    GM2D04.Vector vecA = new GM2D04.Vector(
                            new GM2D04.ColMatrix(25,-50));
                           
    //Add the Vector object to the Point object producing
    // a new Point object
    GM2D04.Point newPoint = point.addVectorToPoint(vecA);
    
    //Draw vecA in RED with its tail at the original
    // point.
    g2D.setColor(Color.RED);
    vecA.draw(g2D,point);
    
    //Draw the original point in GREEN.
    g2D.setColor(Color.GREEN);
    point.draw(g2D);
    
    //Draw the new point in BLUE.
    g2D.setColor(Color.BLUE);
    newPoint.draw(g2D);

  }//end drawOffScreen
  //----------------------------------------------------//

  //This method is used to set the origin of the
  // off-screen image and to draw orthogonal axes on the
  // off-screen image that intersect at the origin.
  private void setCoordinateFrame(Graphics2D g2D){

    //Translate the origin to a point near the lower-left
    // corner of the off-screen image.
    g2D.translate(0.2*osiWidth,0.8*osiHeight);

    //Draw new X and Y-axes in default BLACK
    g2D.drawLine(-(int)(0.2*osiWidth),0,
                 (int)(0.8*osiWidth),0);
    
    g2D.drawLine(0,-(int)(0.8*osiHeight),
                 0,(int)(0.2*osiHeight));   
        
  }//end setCoordinateFrame method
  //====================================================//
  
  
  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    //The purpose of this method is to display the
    // off-screen image on the screen.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()
    
  }//end inner class MyCanvas
    
}//end class GUI
//======================================================//
