//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/14/08
//======================================================//

/*CoordinateFrame01.java 
Copyright 2008, R.G.Baldwin
Revised 02/14/08

This program illustrates the relationship between the 
coordinate frame and a geometric object described in that 
coordinate frame. 

A GUI allows the user to move the orgin of the coordinate 
frame. Proper mathematical corrections are made such that 
a geometric object described in that coordinate frame 
maintains its position relative to world coordinates even 
when the coordinate frame is changed. This causes its 
position relative to the coordinate frame to change.

Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.awt.geom.*;
import java.awt.event.*;

class CoordinateFrame01{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class CoordinateFrame01
//======================================================//

class GUI extends JFrame implements ActionListener{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 400;
  int vSize = 400;
  Image osi;//an off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas
  
  //The following offset values are applied to the width
  // and the height of the off-screen image to modify the 
  // coordinate frame. They are used to store user input
  // values.
  double xOffsetFactor = 0.0;
  double yOffsetFactor = 0.0;
  
  //The following offset values are computed using the
  // user-specified offset factor values.
  double xOffset;
  double yOffset;
  
  Graphics2D g2D;//Off-screen graphics context.
  
  //User input fields.
  JTextField xOffsetField;
  JTextField yOffsetField;
  //----------------------------------------------------//
  
  GUI(){//constructor
    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Copyright 2008,R.G.Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    //Create a new drawing canvas and add it to the
    // center of the content pane.
    myCanvas = new MyCanvas();
    this.getContentPane().add(
                            BorderLayout.CENTER,myCanvas);
    
    //Create and populate a JPanel to be used as a user-
    // input panel and add it to the SOUTH position on
    // the content pane.
    JPanel controlPanel = new JPanel();
    controlPanel.add(new JLabel("X-offset"));
    xOffsetField = new JTextField("0.0",3);
    controlPanel.add(xOffsetField);
    
    controlPanel.add(new JLabel("Y-offset"));
    yOffsetField = new JTextField("0.0",3);
    controlPanel.add(yOffsetField);
    
    JButton button = new JButton("Replot");
    controlPanel.add(button);
    this.getContentPane().add(
                         BorderLayout.SOUTH,controlPanel);
    
    //Register this object as an action listener on the
    // button.
    button.addActionListener(this);
    
    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    
    //Make the size of the off-screen image match the
    // size of the canvas.
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();

    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    g2D = (Graphics2D)(osi.getGraphics());
    
    //Create some underlying data objects in
    // 2D space and draw visual manifestations of them.
    drawOffScreen(g2D);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();

  }//end constructor
  //----------------------------------------------------//
  
  //The purpose of this method is to create some Vector
  // objects and to cause visual manifestations of them to
  // be drawn onto an off-screen image.
  void drawOffScreen(Graphics2D g2D){
    
    //Establish the current coordinate frame and prepare
    // the off-screen image with axes, etc.
    setCoordinateFrame(g2D,xOffset,yOffset);

    //Define a Point that will be used to locate three
    // vectors that form a closed polygon. The physical
    // location of the polygon on the canvas (world)
    // remains the same regardless of how the coordinate
    // frame is changed.
    double startPointX = (196 - xOffset);
    double startPointY = (165 - yOffset);
    GM2D04.Point startPoint = new GM2D04.Point(
           new GM2D04.ColMatrix(startPointX,startPointY));

    //Instantiate three Vector objects that form a closed
    // polygon when drawn head-to-tail.
    double vecAx = 25;
    double vecAy = 50;
    GM2D04.Vector vecA = new GM2D04.Vector(
                       new GM2D04.ColMatrix(vecAx,vecAy));

    double vecBx = 37;
    double vecBy = -12;
    GM2D04.Vector vecB = new GM2D04.Vector(
                             new GM2D04.ColMatrix(37,12));
                             
    //Define vecC as the sum of vecA and vecB. It will be
    // of the correct length and direction to close the
    // ploygon when drawn such that its tail coincides
    // with the tail of vecA.
    GM2D04.Vector vecC = vecA.add(vecB);
    
    //Draw vecA in red with its tail at startPoint.    
    g2D.setColor(Color.RED);
    vecA.draw(g2D,startPoint);
    
    //Compute the location of the head of vecA relative to
    // the current coordinate frame.
    double headX = 
                  vecA.getData(0) + startPoint.getData(0);
    double headY = 
                  vecA.getData(1) + startPoint.getData(1);
                              
    //Draw vecB in GREEN with its tail at the head of
    // vecA.
    g2D.setColor(Color.GREEN);
    vecB.draw(g2D,new GM2D04.Point(
                      new GM2D04.ColMatrix(headX,headY)));

    //Draw vecC in BLUE with its tail at startPoint,
    // coinciding with the tail of vecA. This forms a
    // closed polygon.
    g2D.setColor(Color.BLUE);
    vecC.draw(g2D,startPoint);

  }//end drawOffScreen
  //----------------------------------------------------//

  //This method is used to set the coordinate frame of
  // the off-screen image by setting the origin to the
  // specified offset values relative to origin of the
  // world. The origin of the world is the upper-left
  // corner of the off-screen image.
  //The method draws black orthogonal axes on the
  // off-screen image.
  //There is no intention to perform mathematical
  // operations on the axes, so they are drawn
  // independently of the classes and methods in the
  // game-math library.
  //The method paints the background white erasing
  // anything already there.
  private void setCoordinateFrame(
                  Graphics2D g2D,double xOff,double yOff){

    //Paint the background white
    g2D.setColor(Color.WHITE);
    g2D.fillRect(0,0,osiWidth,osiHeight);

    //Translate the origin by the specified amount
    g2D.translate((int)xOff,(int)yOff);

    //Draw new X and Y-axes in BLACK
    g2D.setColor(Color.BLACK);
    g2D.drawLine(-(int)xOff,0,(int)(osiWidth-xOff),0);
    g2D.drawLine(0,-(int)yOff,0,(int)((osiHeight-yOff)));

  }//end setCoordinateFrame method
  //----------------------------------------------------//
  
  //This method must be defined because the class 
  // implements the ActionListener interface. Because an
  // object of this class is registered as a listener on
  // the button, this method is called each time the user
  // presses the button.
  public void actionPerformed(ActionEvent e){
    //Reset the coordinate frame to world coordinates by
    // reversing the most recent translation.
    setCoordinateFrame(g2D,-xOffset,-yOffset);

    //Compute new translation offsets based on user input.
    xOffsetFactor = 
               Double.parseDouble(xOffsetField.getText());
    yOffsetFactor = 
               Double.parseDouble(yOffsetField.getText());

    xOffset = osiWidth*xOffsetFactor;
    yOffset = osiHeight*yOffsetFactor;

    //Draw a new off-screen image based on user inputs
    // and copy it to the canvas. Note that the
    // drawOffScreen method will call the
    // setCoordinateFrame method again with the new
    // offset values for the origin of the coordinate
    // frame.
    drawOffScreen(g2D);
    myCanvas.repaint();
  }//end actionPerformed
  //====================================================//
  
  
  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    //The purpose of this method is to display the
    // off-screen image on the screen.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()
    
  }//end inner class MyCanvas
    
}//end class GUI
//======================================================//
