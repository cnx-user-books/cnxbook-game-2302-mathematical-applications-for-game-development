//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 03/30/08
//======================================================//

/*GM03.java 
Copyright 2008, R.G.Baldwin
Revised 03/30/08

This is an update to the game-math library named GM02.
The primary purpose of the update is to add the ability to
project 3D worlds onto a 2D plane using perspective 
projection in addition to the existing parallel projection
capability. (Some other more minor changes were made as 
well.)

The following draw methods were modified in this version
of the library and are not backward compatible with 
earlier programs. Note that these methods are overloaded.
The first method in each pair calls the second method in
the pair with dummy parameters for the last three 
parameters whenever the first version is called.

The first overloaded version of each draw method is very 
useful when it is known that the value of type is 
either 0, 1, or 2. However, in some cases, it is easier 
to simply pass the last three parameters (using dummy
parameters if necessary) and let the draw method ignore 
them than it is to perform a test for the type every
time the draw method is called.


GM03.Point3D.draw(Graphics2D g2D,
                 int type)
GM03.Point3D.draw(Graphics2D g2D,
                 int type,
                 double scale,
                 Point3D camera,
                 ColMatrix3D angle)
                 
GM03.Vector3D.draw(Graphics2D g2D,
                 Point3D tail,
                 int type)
GM03.Vector3D.draw(Graphics2D g2D,
                 Point3D tail,
                 int type,
                 double scale,
                 Point3D camera,
                 ColMatrix3D angle)

GM03.Line3D.draw(Graphics2D g2D,
                 int type) 
GM03.Line3D.draw(Graphics2D g2D,
                 int type,
                 double scale,
                 Point3D camera,
                 ColMatrix3D angle)
                 
The incompatability mainly stems from the fact that much
more information is required to draw a 3D perspective 
projection than is the case for the parallel projection
that was included in earlier versions of the library.

The value of the parameter named type in the parameter 
lists for the draw methods shown above specifies the type 
of projection that will be employed:
 type = 0, Calls threeDto2DprojectionA described below
 type = 1, Calls threeDto2DprojectionB described below
 type = 2, Calls threeDto2DprojectionC described below
 type = 3, Calls threeDto2DprojectionD described below
 
When the value of type is 0, 1, or 2, the last three 
parameters are simply ignored in all three draw methods
that require those parameters. However, they must
be there and this causes this library to be incompatible 
with drawing programs written to be compatible with 
earlier versions of the game-math library. Even 
without those three parameters, the requirement to 
pass the type of projection format to the draw methods
also causes the draw methods in this library to be
incompatible with code written for compatibility with
earlier versions of the library.

Please see the comments at the beginning of the library
class named GM01 for a general description of the library.

The method convert3Dto2D was removed and replaced by the 
following four methods. These four methods are 
private and are not intended to be called from outside 
the library.

threeDto2DprojectionA - This is a parallel oblique 
 projection with a value of 45 degrees for alpha and a
 value of 30 degrees for phi (see lesson 1618 for an
 explanation of alpha and phi). The camera position is 
 above the xz plane and to the right of the zy plane.
threeDto2DprojectionB - This is a perspective projection 
 with a fixed camera position looking straight down the 
 z-axis.
threeDto2DprojectionC - This is a perspective projection 
 from 3D to 2D with a fixed camera position. The camera 
 position is above the xz plane and to the right of 
 the zy plane looking directly at the origin. This method
 is actually a combination of parallel oblique projection
 and perspective projection.
threeDto2DprojectionD - This is a complex perspective
 projection with a variable camera position and a variable
 camera angle.


The using programmer interfaces with these four methods 
through the six draw methods listed earlier, selecting
the required type of projection on the basis of the value
of the type parameter passed to the draw method.

I also added several new methods to the library as 
described below. These methods are convenience methods
and are not necessarily related to perspective 
projections.

The following new method makes it possible to scale the 
individual components in a vector by different scale 
factors.

GM03.Vector3D.scaleByComponent(ColMatrix3D factor)

The following new method makes it possible to rotate a 
vector around a specified anchor point.

GM03.Vector3D.rotate(Point3D anchorPoint,
                     ColMatrix3D angles)

The following new method makes it possible to get a clone 
of an existing ColMatrix3D object:

GM03.ColMatrix3D clone()

I also added overloaded constructors to the Point2D,
Point3D and Vector3D classes to make it easier to 
instantiate objects of those classes.

Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.geom.*;
import java.awt.*;

public class GM03{
  //----------------------------------------------------//
  
  //This is a parallel projection from 3D to 2D with a
  // fixed camera position. The camera position is above
  // the xz plane and to the right of the zy plane.
  //This method converts a Point3D object into a
  // Point2D object. The purpose is to accept
  // x, y, and z coordinate values and transform those
  // values into a pair of coordinate values suitable for
  // display in two dimensions.
  //See http://local.wasp.uwa.edu.au/~pbourke/geometry/
  // classification/ for technical background on the
  // transform from 3D to 2D.
  //The transform equations are:
  // xp = x + z * cos(phi)/tan(alpha)
  // yp = y + z * sin(phi)/tan(alpha)
  //Let phi = 30 degrees and alpha = 45 degrees
  //Then:cos(phi) = 0.866
  //     sin(phi) = 0.5
  //     tan(alpha) = 1;
  //Note that the signs in the above equations depend
  // on the assumed directions of the angles as well as
  // the assumed positive directions of the axes. The
  // signs used in this method assume the following:
  //   Positive x is to the right.
  //   Positive y is up the screen.
  //   Positive z is protruding out the front of the
  //     screen.
  private static Point2D threeDto2DprojectionA(
                                          Point3D data){
    return new Point2D(
                  data.getData(0) - 0.866*data.getData(2),
                  data.getData(1) - 0.50*data.getData(2));
  }//end threeDto2DprojectionA 
  //----------------------------------------------------//

  //This is a perspective projection with a fixed camera
  // position looking straight down the z-axis.
  //The purpose of this method is to convert the x, y,
  // and z components in a Point3D object into the x
  // and y components in a Point2D object using a
  // relatively simple perspective projection.
  private static Point2D threeDto2DprojectionB(
                                            Point3D data){

    //Extract the important values from the incoming
    // parameters.
    double aX = data.getData(0);
    double aY = data.getData(1);
    double aZ = data.getData(2);

    //The following specifies a fixed camera position
    // looking straight down the z-axis from positive to
    // negative.
    double cZ = 600;

    //Compute the distance from the camera to the data
    // point.
    Point3D camera = new Point3D(0.0,0.0,cZ);
    double dZ = camera.getDisplacementVector(data).
                                              getLength();
        
    if(dZ == 0.0){
      dZ = 0.00001;//prevent DivideByZero error.
    }//end if

    //Compute the x,y coordinates on the 2D display.
    double bX =aX*(cZ/dZ);
    double bY =aY*(cZ/dZ);

    return new Point2D(bX,bY);
  }//end threeDto2DprojectionB 
  //----------------------------------------------------//
  

  //This method provides a perspective projection from 3D
  // to 2D with a fixed camera position. The camera 
  // position is above the xz plane and to the right of
  // the zy plane looking directly at the origin. This
  // method was created by combining the parallel
  // projection algorithm from threeDto2DprojectionA with
  // the perspective projection algorithm from
  // threeDto2DprojectionB.
  private static Point2D threeDto2DprojectionC(
                                        Point3D data){

    //Compute projected x and y values using the algorithm
    // from threeDto2DprojectionA.
    double aX = (data.getData(0) - 0.866*data.getData(2));
    double aY = (data.getData(1) - 0.50*data.getData(2));
    double aZ = data.getData(2);
    
    //Apply the perspective algorithm from
    // threeDto2DprojectionB. Assume that the camera is
    // located at 0,0,600.
    double cZ = 600;

    //Compute the distance from the camera to the data
    // point.
    Point3D camera = new Point3D(0.0,0.0,cZ);
    double dZ = camera.getDisplacementVector(data).
                                              getLength();
        
    if(dZ == 0.0){
      dZ = 0.00001;//prevent DivideByZero error.
    }//end if

    //Compute the x,y coordinates on the 2D display.
    double bX =aX*(cZ/dZ);
    double bY =aY*(cZ/dZ);

    return new Point2D(bX,bY);
  }//end threeDto2DprojectionC 
  //----------------------------------------------------//
  
  
  //This method provides a perspective projection from
  // 3D to 2D with a variable camera position, and a
  // variable camera angle.
  //The purpose of this method is to convert the x, y,
  // and z components in a Point3D object into the x
  // and y components in a Point2D object using a 
  // perspective projection that allows individual
  // control over the camera position and camera angle.
  //BRIEF DESCRIPTION OF PARAMETERS
  //The scale parameter controls the overall size of the
  // projected image.
  //The three components of the camera parameter specify
  // the x, y, and z coordinates for the position of the
  // camera.
  //The three components of the angle parameter specify
  // rotation of the camera around each of its x, y, and
  // z axes respectively. The angles are specified in
  // degrees.
  //IMPORTANT: This method does not provide reliable
  // results if the camera allows the point being 
  // projected to get behind it. However, camera rotation
  // can often be used to prevent the point from getting
  // behind the camera. For example, the camera can move
  // all the way around a point and view it from all
  // sides as long is the camera is rotated in such a way
  // as to cause it to continue pointing at the point.
  private static Point2D threeDto2DprojectionD(
                                       Point3D data,
                                       double scale,
                                       Point3D camera,
                                       ColMatrix3D angle){

    //Rotate the point around the camera in the reverse
    // direction of the specified camera rotation to
    // make it appear that the camera has been rotated.
    //The rotate method requires the rotation angles to
    // be provided in the following order.
    // Rotate around z - rotation in x-y plane.
    // Rotate around x - rotation in y-z plane.
    // Rotate around y - rotation in x-z plane.
    //Rearrange the specified camera rotation angles to
    // comply with this requirement.
    ColMatrix3D tempAngles = new ColMatrix3D(
                                       -angle.getData(2),
                                       -angle.getData(0),
                                       -angle.getData(1));
    
    //Create Point3D objects for the data point and 
    // camera locations so that the rotate method of the
    // Point3D class can be called to perform the
    // rotation. Then perform the rotation.
    Point3D tempPoint = data.rotate(camera,tempAngles);

    //Extract the coordinate values for the rotated
    // data point.
    double aX = tempPoint.getData(0);
    double aY = tempPoint.getData(1);
    double aZ = tempPoint.getData(2);
    
    //Extract the coordinate values for the camera.
    double cX = camera.getData(0);
    double cY = camera.getData(1);;
    double cZ = camera.getData(2);
    
    //Compute the distance from the camera to the
    // data point. The first two distances will
    // be divided by this distance to provide
    // the visual effect of perspective.
    double dX = aX - cX;
    double dY = aY - cY;
    double dZ = camera.getDisplacementVector(tempPoint).
                                              getLength();
    if(dZ == 0.0){
      dZ = 0.00001;//prevent DivideByZero error.
    }//end if

    //Declare variables for storing the output.    
    double bX;
    double bY;

    if(cZ < aZ){
      //The point is at or behind the camera. Make sure
      // that it is no longer visible in the 2D.
      // projection. Note that this solution is far from
      // ideal, but I don't have a better solution. It
      // isn't a problem so long as the camera is outside
      // the 3D scene, but becomes a problem when the
      // camera ventures into the scene.
      bX = 10000*aX;
      bY = 10000*aY;
    }else{
      //Compute the projected values of the 3D x and y
      // coordinate values on the 2D plane. Divide by
      // dZ to give the visual effect of perspective.
      bX = dX*scale/dZ;
      bY = dY*scale/dZ;
    };

    return new Point2D(bX,bY);
  }//end threeDto2DprojectionD 
  //----------------------------------------------------//

  //This method wraps around the translate method of the
  // Graphics2D class. The purpose is to cause the
  // positive direction for the y-axis to be up the screen
  // instead of down the screen. When you use this method,
  // you should program as though the positive direction
  // for the y-axis is up.
  public static void translate(Graphics2D g2D,
                               double xOffset,
                               double yOffset){
    //Flip the sign on the y-coordinate to change the
    // direction of the positive y-axis to go up the
    // screen.
    g2D.translate(xOffset,-yOffset);
  }//end translate
  //----------------------------------------------------//
  
  //This method wraps around the drawLine method of the
  // Graphics class. The purpose is to cause the positive
  // direction for the y-axis to be up the screen instead
  // of down the screen. When you use this method, you
  // should program as though the positive direction for
  // the y-axis is up.
  public static void drawLine(Graphics2D g2D,
                              double x1,
                              double y1,
                              double x2,
                              double y2){
    //Flip the sign on the y-coordinate value.
    g2D.drawLine((int)x1,-(int)y1,(int)x2,-(int)y2);
  }//end drawLine
  //----------------------------------------------------//
  
  //This method wraps around the fillOval method of the
  // Graphics class. The purpose is to cause the positive
  // direction for the y-axis to be up the screen instead
  // of down the screen. When you use this method, you
  // should program as though the positive direction for
  // the y-axis is up.
  public static void fillOval(Graphics2D g2D,
                              double x,
                              double y,
                              double width,
                              double height){
    //Flip the sign on the y-coordinate value.
    g2D.fillOval((int)x,-(int)y,(int)width,(int)height);
  }//end fillOval
  //----------------------------------------------------//

  //This method wraps around the drawOval method of the
  // Graphics class. The purpose is to cause the positive
  // direction for the y-axis to be up the screen instead
  // of down the screen. When you use this method, you
  // should program as though the positive direction for
  // the y-axis is up.
  public static void drawOval(Graphics2D g2D,
                              double x,
                              double y,
                              double width,
                              double height){
    //Flip the sign on the y-coordinate value.
    g2D.drawOval((int)x,-(int)y,(int)width,(int)height);
  }//end drawOval
  //----------------------------------------------------//
  
  //This method wraps around the fillRect method of the
  // Graphics class. The purpose is to cause the positive
  // direction for the y-axis to be up the screen instead
  // of down the screen. When you use this method, you
  // should program as though the positive direction for
  // the y-axis is up.
  public static void fillRect(Graphics2D g2D,
                              double x,
                              double y,
                              double width,
                              double height){
    //Flip the sign on the y-coordinate value.
    g2D.fillRect((int)x,-(int)y,(int)width,(int)height);
  }//end fillRect
  //----------------------------------------------------//
  //----------------------------------------------------//
  
  

  //An object of this class represents a 2D column matrix.
  // An object of this class is the fundamental building
  // block for several of the other classes in the
  // library.
  public static class ColMatrix2D{
    double[] data = new double[2];
    
    public ColMatrix2D(double data0,double data1){
      data[0] = data0;
      data[1] = data1;
    }//end constructor
    //--------------------------------------------------//
    
    //Overridden toString method.
    public String toString(){
      return data[0] + "," + data[1];
    }//end overridden toString method
    //--------------------------------------------------//
    
    public double getData(int index){
      if((index < 0) || (index > 1)){ 
        throw new IndexOutOfBoundsException();
      }else{
        return data[index];
      }//end else
    }//end getData method
    //--------------------------------------------------//
    
    public void setData(int index,double data){
      if((index < 0) || (index > 1)){ 
        throw new IndexOutOfBoundsException();
      }else{
        this.data[index] = data;
      }//end else
    }//end setData method
    //--------------------------------------------------//
    
    //This method overrides the equals method inherited
    // from the class named Object. It compares the values
    // stored in two matrices and returns true if the
    // values are equal or almost equal and returns false
    // otherwise. 
    public boolean equals(Object obj){
      if(obj instanceof GM03.ColMatrix2D &&
         Math.abs(((ColMatrix2D)obj).getData(0) - 
                                 getData(0)) <= 0.00001 &&
         Math.abs(((ColMatrix2D)obj).getData(1) - 
                                  getData(1)) <= 0.00001){
        return true;
      }else{
        return false;
      }//end else
     
    }//end overridden equals method
    //--------------------------------------------------//

    //Adds one ColMatrix2D object to another ColMatrix2D
    // object, returning a ColMatrix2D object.
    public ColMatrix2D add(ColMatrix2D matrix){
      return new ColMatrix2D(
                            getData(0)+matrix.getData(0),
                            getData(1)+matrix.getData(1));
    }//end add
    //--------------------------------------------------//
    
    //Subtracts one ColMatrix2D object from another
    // ColMatrix2D object, returning a ColMatrix2D object.
    // The object that is received as an incoming
    // parameter  is subtracted from the object on which
    // the method is called.
    public ColMatrix2D subtract(ColMatrix2D matrix){
      return new ColMatrix2D(
                            getData(0)-matrix.getData(0),
                            getData(1)-matrix.getData(1));
    }//end subtract
    //--------------------------------------------------//
    
    //Computes the dot product between two ColMatrix2D
    // objects and returns the result as type double.
    public double dot(ColMatrix2D matrix){
      return getData(0) * matrix.getData(0) 
           + getData(1) * matrix.getData(1);
    }//end dot
    //--------------------------------------------------//
  }//end class ColMatrix2D
  //====================================================//


  //An object of this class represents a 3D column matrix.
  // An object of this class is the fundamental building
  // block for several of the other classes in the
  // library.
  public static class ColMatrix3D{
    double[] data = new double[3];
    
    public ColMatrix3D(
                  double data0,double data1,double data2){
      data[0] = data0;
      data[1] = data1;
      data[2] = data2;
    }//end constructor
    //--------------------------------------------------//
    
    public String toString(){
      return data[0] + "," + data[1] + "," + data[2];
    }//end overridden toString method
    //--------------------------------------------------//
    
    public double getData(int index){
      if((index < 0) || (index > 2)){ 
        throw new IndexOutOfBoundsException();
      }else{
        return data[index];
      }//end else
    }//end getData method
    //--------------------------------------------------//
    
    public void setData(int index,double data){
      if((index < 0) || (index > 2)){ 
        throw new IndexOutOfBoundsException();
      }else{
        this.data[index] = data;
      }//end else
    }//end setData method
    //--------------------------------------------------//
    
    //This method overrides the equals method inherited
    // from the class named Object. It compares the values
    // stored in two matrices and returns true if the
    // values are equal or almost equal and returns false
    // otherwise. 
    public boolean equals(Object obj){
      if(obj instanceof GM03.ColMatrix3D &&
         Math.abs(((ColMatrix3D)obj).getData(0) - 
                                 getData(0)) <= 0.00001 &&
         Math.abs(((ColMatrix3D)obj).getData(1) - 
                                 getData(1)) <= 0.00001 &&
         Math.abs(((ColMatrix3D)obj).getData(2) - 
                                  getData(2)) <= 0.00001){
        return true;
      }else{
        return false;
      }//end else
     
    }//end overridden equals method
    //--------------------------------------------------//

    //Adds one ColMatrix3D object to another ColMatrix3D
    // object, returning a ColMatrix3D object.
    public ColMatrix3D add(ColMatrix3D matrix){
      return new ColMatrix3D(
                            getData(0)+matrix.getData(0),
                            getData(1)+matrix.getData(1),
                            getData(2)+matrix.getData(2));
    }//end add
    //--------------------------------------------------//
    
    //Subtracts one ColMatrix3D object from another
    // ColMatrix3D object, returning a ColMatrix3D object.
    // The object that is received as an incoming
    // parameter is subtracted from the object on which
    // the method is called.
    public ColMatrix3D subtract(ColMatrix3D matrix){
      return new ColMatrix3D(
                            getData(0)-matrix.getData(0),
                            getData(1)-matrix.getData(1),
                            getData(2)-matrix.getData(2));
    }//end subtract
    //--------------------------------------------------//
    
    //Computes the dot product between two ColMatrix3D
    // objects and returns the result as type double.
    public double dot(ColMatrix3D matrix){
      return getData(0) * matrix.getData(0) 
           + getData(1) * matrix.getData(1)
           + getData(2) * matrix.getData(2);
    }//end dot
    //--------------------------------------------------//
    
    //Returns a new ColMatrix3D object that is a clone of
    // the object on which the method is called.
    public ColMatrix3D clone(){
      return new ColMatrix3D(getData(0),
                            getData(1),
                            getData(2));
    }//end clone
    //--------------------------------------------------//
    
  }//end class ColMatrix3D
  //====================================================//
  //====================================================//


  public static class Point2D{
    ColMatrix2D point;
    
    public Point2D(double x,double y){
      this(new ColMatrix2D(x,y));
    }//end overloaded constructor
    //--------------------------------------------------//
    public Point2D(ColMatrix2D point){//constructor
      //Create and save a clone of the ColMatrix2D object
      // used to define the point to prevent the point
      // from being corrupted by a later change in the
      // values stored in the original ColMatrix2D object
      // through use of its set method.
      this.point = new ColMatrix2D(
                       point.getData(0),point.getData(1));
    }//end constructor
    //--------------------------------------------------//

    public String toString(){
      return point.getData(0) + "," + point.getData(1);
    }//end toString
    //--------------------------------------------------//
    
    public double getData(int index){
      if((index < 0) || (index > 1)){ 
        throw new IndexOutOfBoundsException();
      }else{
        return point.getData(index);
      }//end else
    }//end getData
    //--------------------------------------------------//
    
    public void setData(int index,double data){
      if((index < 0) || (index > 1)){ 
        throw new IndexOutOfBoundsException();
      }else{
        point.setData(index,data);
      }//end else
    }//end setData
    //--------------------------------------------------//

    //This method draws a small circle around the location
    // of the point on the specified graphics context.
    public void draw(Graphics2D g2D){
      drawOval(g2D,getData(0)-3,
                   getData(1)+3,6,6);
    }//end draw

    //--------------------------------------------------//
    
    //Returns a reference to the ColMatrix2D object that
    // defines this Point2D object.
    public ColMatrix2D getColMatrix(){
      return point;
    }//end getColMatrix
    //--------------------------------------------------//

    //This method overrides the equals method inherited
    // from the class named Object. It compares the values
    // stored in the ColMatrix2D objects that define two
    // Point2D objects and returns true if they are equal
    // and false otherwise. 
    public boolean equals(Object obj){
      if(point.equals(((Point2D)obj).getColMatrix())){
        return true;
      }else{
        return false;
      }//end else
     
    }//end overridden equals method
    //--------------------------------------------------//

    //Gets a displacement vector from one Point2D object
    // to a second Point2D object. The vector points from
    // the object on which the method is called to the
    // object passed as a parameter to the method. Kjell
    // describes this as the distance you would have to
    // walk along the x and then the y axes to get from
    // the first point to the second point.
    public Vector2D getDisplacementVector(
                                      Point2D point){
      return new Vector2D(new ColMatrix2D(
                            point.getData(0)-getData(0),
                            point.getData(1)-getData(1)));
    }//end getDisplacementVector
    //--------------------------------------------------//
    
    //Adds a Vector2D to a Point2D producing a
    // new Point2D.
    public Point2D addVectorToPoint(Vector2D vec){
      return new Point2D(new ColMatrix2D(
                          getData(0) + vec.getData(0),
                          getData(1) + vec.getData(1)));
    }//end addVectorToPoint
    //--------------------------------------------------//
    
    //Returns a new Point2D object that is a clone of
    // the object on which the method is called.
    public Point2D clone(){
      return new Point2D(
                  new ColMatrix2D(getData(0),getData(1)));
    }//end clone
    //--------------------------------------------------//
    
    //The purpose of this method is to rotate a point
    // around a specified anchor point in the x-y plane.
    //The rotation angle is passed in as a double value
    // in degrees with the positive angle of rotation
    // being counter-clockwise.
    //This method does not modify the contents of the
    // Point2D object on which the method is called.
    // Rather, it uses the contents of that object to
    // instantiate, rotate, and return a new Point2D
    // object.
    //For simplicity, this method translates the
    // anchorPoint to the origin, rotates around the
    // origin, and then translates back to the
    // anchorPoint.
    /*
    See http://www.ia.hiof.no/~borres/cgraph/math/threed/
    p-threed.html for a definition of the equations
    required to do the rotation.

    x2 = x1*cos - y1*sin
    y2 = x1*sin + y1*cos
    */ 
    public Point2D rotate(Point2D anchorPoint,
                                            double angle){
      Point2D newPoint = this.clone();
      
      double tempX ;
      double tempY;
 
      //Translate anchorPoint to the origin
      Vector2D tempVec = 
                 new Vector2D(anchorPoint.getColMatrix());
      newPoint = 
              newPoint.addVectorToPoint(tempVec.negate());
      
      //Rotate around the origin.
      tempX = newPoint.getData(0);
      tempY = newPoint.getData(1);
      newPoint.setData(//new x coordinate
                      0,
                      tempX*Math.cos(angle*Math.PI/180) -
                      tempY*Math.sin(angle*Math.PI/180));

      newPoint.setData(//new y coordinate
                      1,
                      tempX*Math.sin(angle*Math.PI/180) +
                      tempY*Math.cos(angle*Math.PI/180));

      //Translate back to anchorPoint
      newPoint = newPoint.addVectorToPoint(tempVec);
      
      return newPoint;

    }//end rotate
    //--------------------------------------------------//
    
    //Multiplies this point by a scaling matrix received
    // as an incoming parameter and returns the scaled
    // point.
    public Point2D scale(ColMatrix2D scale){
      return new Point2D(new ColMatrix2D(
                          getData(0) * scale.getData(0),
                          getData(1) * scale.getData(1)));
    }//end scale
    //--------------------------------------------------//
  }//end class Point2D
  //====================================================//


  public static class Point3D{
    ColMatrix3D point;
    
    //The following is an overloaded constructor  that is
    // intended to make it easier to instantiate objects
    // of this type.
    public Point3D(double x,double y,double z){
      this(new ColMatrix3D(x,y,z));
    }//end constructor
    
    //--------------------------------------------------//
    public Point3D(ColMatrix3D point){//constructor
      //Create and save a clone of the ColMatrix3D object
      // used to define the point to prevent the point
      // from being corrupted by a later change in the
      // values stored in the original ColMatrix3D object
      // through use of its set method.
      this.point = 
         new ColMatrix3D(point.getData(0),
                         point.getData(1),
                         point.getData(2));
    }//end constructor
    //--------------------------------------------------//

    public String toString(){
      return point.getData(0) + "," + point.getData(1) 
                                 + "," + point.getData(2);
    }//end toString
    //--------------------------------------------------//
    
    public double getData(int index){
      if((index < 0) || (index > 2)){ 
        throw new IndexOutOfBoundsException();
      }else{
        return point.getData(index);
      }//end else
    }//end getData
    //--------------------------------------------------//
    
    public void setData(int index,double data){
      if((index < 0) || (index > 2)){ 
        throw new IndexOutOfBoundsException();
      }else{
        point.setData(index,data);
      }//end else
    }//end setData
    //--------------------------------------------------//
    
    //This overloaded draw method calls the method that
    // follows with dummy parameters.
    public void draw(Graphics2D g2D,int type){
      draw(g2D,
           type,
           0,
           new Point3D(0,0,0),
           new ColMatrix3D(0,0,0));
    }//end overloaded draw method
    //--------------------------------------------------//

    //This method draws a small circle around the location
    // of the point on the specified graphics context.
    //Note that this method is overloaded.
    public void draw(Graphics2D g2D,
                     int type,
                     double scale,
                     Point3D camera,
                     ColMatrix3D angle){
      //Get 2D projection coordinate values.
      Point2D temp = null;
      //Test the incoming type value to determine which
      // projection method to call.
      if(type == 0){
        //Get the values required to draw a parallel
        // projection ignoring the last three incoming
        // parameters.
        temp = threeDto2DprojectionA(this);
      }else if(type == 1){
        //Get the values required to draw a simple
        // perspective projection ignoring the last three
        // incoming parameters.
        temp = threeDto2DprojectionB(this);
      }else if(type == 2){
        //Get the values required to draw a perspective
        // projection ignoring the last three incoming
        // parameters.
        temp = threeDto2DprojectionC(this);
        }else if(type == 3){
        //Use all of the incoming parameters and get the
        // values required to draw a complex perspective
        // projection.
        temp = 
           threeDto2DprojectionD(this,scale,camera,angle);
      }//end else

      drawOval(g2D,temp.getData(0)-3,
                   temp.getData(1)+3,
                   6,
                   6);
    }//end draw
    //--------------------------------------------------//
    
    //Returns a reference to the ColMatrix3D object that
    // defines this Point3D object.
    public ColMatrix3D getColMatrix(){
      return point;
    }//end getColMatrix
    //--------------------------------------------------//

    //This method overrides the equals method inherited
    // from the class named Object. It compares the values
    // stored in the ColMatrix3D objects that define two
    // Point3D objects and returns true if they are equal
    // and false otherwise. 
    public boolean equals(Object obj){
      if(point.equals(((Point3D)obj).getColMatrix())){
        return true;
      }else{
        return false;
      }//end else
     
    }//end overridden equals method
    //--------------------------------------------------//

    //Gets a displacement vector from one Point3D object
    // to a second Point3D object. The vector points from
    // the object on which the method is called to the
    // object passed as a parameter to the method. Kjell
    // describes this as the distance you would have to
    // walk along the x and then the y axes to get from
    // the first point to the second point.
    public Vector3D getDisplacementVector(Point3D point){
      return new Vector3D(new ColMatrix3D(
                            point.getData(0)-getData(0),
                            point.getData(1)-getData(1),
                            point.getData(2)-getData(2)));
    }//end getDisplacementVector
    //--------------------------------------------------//
    
    //Adds a Vector3D to a Point3D producing a
    // new Point3D.
    public Point3D addVectorToPoint(Vector3D vec){
      return new Point3D(new ColMatrix3D(
                          getData(0) + vec.getData(0),
                          getData(1) + vec.getData(1),
                          getData(2) + vec.getData(2)));
    }//end addVectorToPoint
    //--------------------------------------------------//
    
    //Returns a new Point3D object that is a clone of
    // the object on which the method is called.
    public Point3D clone(){
      return new Point3D(new ColMatrix3D(getData(0),
                                         getData(1),
                                         getData(2)));
    }//end clone
    //--------------------------------------------------//
    
    //The purpose of this method is to rotate a point
    // around a specified anchor point in the following
    // order:
    // Rotate around z - rotation in x-y plane.
    // Rotate around x - rotation in y-z plane.
    // Rotate around y - rotation in x-z plane.
    //In other words, the method begins by rotating the
    // point around the z-axis of the anchor point. Then
    // it rotates the point around the x-axis of the
    // anchor point. Finally, it rotates the point around
    // the y-axis of the anchor point.
    //The rotation angles are passed in as double values
    // in degrees (based on the right-hand rule) in the
    // order given above, packaged in an object of the
    // class GM03.ColMatrix3D. (Note that in this case,
    // the ColMatrix3D object is simply a convenient
    // container and it has no significance from a matrix
    // viewpoint.)
    //The right-hand rule states that if you point the
    // thumb of your right hand in the positive direction
    // of an axis, the direction of positive rotation
    // around that axis is given by the direction that
    // your fingers will be pointing.
    //This method does not modify the contents of the
    // Point3D object on which the method is called.
    // Rather, it uses the contents of that object to
    // instantiate, rotate, and return a new Point3D
    // object.
    //For simplicity, this method translates the
    // anchorPoint to the origin, rotates around the
    // origin, and then translates back to the
    // anchorPoint.
    /*
    See http://www.ia.hiof.no/~borres/cgraph/math/threed/
    p-threed.html for a definition of the equations
    required to do the rotation.
    z-axis 
    x2 = x1*cos - y1*sin
    y2 = x1*sin + y1*cos
    
    x-axis
    y2 = y1*cos(v) - z1*sin(v)
    z2 = y1*sin(v) + z1* cos(v) 
    
    y-axis
    x2 = x1*cos(v) + z1*sin(v)
    z2 = -x1*sin(v) + z1*cos(v)
    */ 
    public Point3D rotate(Point3D anchorPoint,
                                      ColMatrix3D angles){
      Point3D newPoint = this.clone();
      
      double tempX ;
      double tempY;
      double tempZ;
 
      //Translate anchorPoint to the origin
      Vector3D tempVec = 
                 new Vector3D(anchorPoint.getColMatrix());
      newPoint = 
              newPoint.addVectorToPoint(tempVec.negate());

      double zAngle = angles.getData(0);
      double xAngle = angles.getData(1);
      double yAngle = angles.getData(2);
      
      //Rotate around z-axis
      tempX = newPoint.getData(0);
      tempY = newPoint.getData(1);
      newPoint.setData(//new x coordinate
                      0,
                      tempX*Math.cos(zAngle*Math.PI/180) -
                      tempY*Math.sin(zAngle*Math.PI/180));

      newPoint.setData(//new y coordinate
                      1,
                      tempX*Math.sin(zAngle*Math.PI/180) +
                      tempY*Math.cos(zAngle*Math.PI/180));
      
      //Rotate around x-axis
      tempY = newPoint.getData(1);
      tempZ = newPoint.getData(2);
      newPoint.setData(//new y coordinate
                      1,
                      tempY*Math.cos(xAngle*Math.PI/180) -
                      tempZ*Math.sin(xAngle*Math.PI/180));

      newPoint.setData(//new z coordinate
                      2,
                      tempY*Math.sin(xAngle*Math.PI/180) +
                      tempZ*Math.cos(xAngle*Math.PI/180));
      
      //Rotate around y-axis
      tempX = newPoint.getData(0);
      tempZ = newPoint.getData(2);
      newPoint.setData(//new x coordinate
                      0,
                      tempX*Math.cos(yAngle*Math.PI/180) +
                      tempZ*Math.sin(yAngle*Math.PI/180));

      newPoint.setData(//new z coordinate
                     2,
                     -tempX*Math.sin(yAngle*Math.PI/180) +
                     tempZ*Math.cos(yAngle*Math.PI/180));
      
      //Translate back to anchorPoint
      newPoint = newPoint.addVectorToPoint(tempVec);
      
      return newPoint;

    }//end rotate
    //--------------------------------------------------//
    
    //Multiplies this point by a scaling matrix received
    // as an incoming parameter and returns the scaled
    // point.
    public Point3D scale(ColMatrix3D scale){
      return new Point3D(new ColMatrix3D(
                          getData(0) * scale.getData(0),
                          getData(1) * scale.getData(1),
                          getData(2) * scale.getData(2)));
    }//end scale
    //--------------------------------------------------//
  }//end class Point3D
  //====================================================//
  //====================================================//

  
  public static class Vector2D{
    ColMatrix2D vector;
    
    public Vector2D(ColMatrix2D vector){//constructor
      //Create and save a clone of the ColMatrix2D object
      // used to define the vector to prevent the vector
      // from being corrupted by a later change in the
      // values stored in the original ColVector2D object.
      this.vector = new ColMatrix2D(
                     vector.getData(0),vector.getData(1));
    }//end constructor
    //--------------------------------------------------//

    public String toString(){
      return vector.getData(0) + "," + vector.getData(1);
    }//end toString
    //--------------------------------------------------//
    
    public double getData(int index){
      if((index < 0) || (index > 1)){
        throw new IndexOutOfBoundsException();
      }else{
        return vector.getData(index);
      }//end else
    }//end getData
    //--------------------------------------------------//
    
    public void setData(int index,double data){
      if((index < 0) || (index > 1)){ 
        throw new IndexOutOfBoundsException();
      }else{
        vector.setData(index,data);
      }//end else
    }//end setData
    //--------------------------------------------------//
    
    //This method draws a vector on the specified graphics
    // context, with the tail of the vector located at a
    // specified point, and with a small filled circle at
    // the head.
    public void draw(Graphics2D g2D,Point2D tail){

      drawLine(g2D,
               tail.getData(0),
               tail.getData(1),
               tail.getData(0)+vector.getData(0),
               tail.getData(1)+vector.getData(1));

      fillOval(g2D,
               tail.getData(0)+vector.getData(0)-3,
               tail.getData(1)+vector.getData(1)+3,
               6,
               6);
    }//end draw
    //--------------------------------------------------//
    
    //Returns a reference to the ColMatrix2D object that
    // defines this Vector2D object.
    public ColMatrix2D getColMatrix(){
      return vector;
    }//end getColMatrix
    //--------------------------------------------------//

    //This method overrides the equals method inherited
    // from the class named Object. It compares the values
    // stored in the ColMatrix2D objects that define two
    // Vector2D objects and returns true if they are equal
    // and false otherwise. 
    public boolean equals(Object obj){
      if(vector.equals((
                     (Vector2D)obj).getColMatrix())){
        return true;
      }else{
        return false;
      }//end else
     
    }//end overridden equals method
    //--------------------------------------------------//
    
    //Adds this vector to a vector received as an incoming
    // parameter and returns the sum as a vector.
    public Vector2D add(Vector2D vec){
      return new Vector2D(new ColMatrix2D(
                       vec.getData(0)+vector.getData(0),
                       vec.getData(1)+vector.getData(1)));
    }//end add
    //--------------------------------------------------//
    
    //Returns the length of a Vector2D object.
    public double getLength(){
      return Math.sqrt(
           getData(0)*getData(0) + getData(1)*getData(1));
    }//end getLength
    //--------------------------------------------------//
    
    //Multiplies this vector by a scale factor received as
    // an incoming parameter and returns the scaled
    // vector.
    public Vector2D scale(Double factor){
      return new Vector2D(new ColMatrix2D(
                                    getData(0) * factor,
                                    getData(1) * factor));
    }//end scale
    //--------------------------------------------------//
    
    //Changes the sign on each of the vector components
    // and returns the negated vector.
    public Vector2D negate(){
      return new Vector2D(new ColMatrix2D(-getData(0),
                                          -getData(1)));
    }//end negate
    //--------------------------------------------------//
    
    //Returns a new vector that points in the same
    // direction but has a length of one unit.
    public Vector2D normalize(){
      double length = getLength();
      return new Vector2D(new ColMatrix2D(
                                      getData(0)/length,
                                      getData(1)/length));
    }//end normalize
    //--------------------------------------------------//
    
    //Computes the dot product between two Vector2D
    // objects and returns the result as type double.
    public double dot(Vector2D vec){
      ColMatrix2D matrixA = getColMatrix();
      ColMatrix2D matrixB = vec.getColMatrix();
      return matrixA.dot(matrixB);
    }//end dot
    //--------------------------------------------------//
    
    //Computes and returns the angle between two Vector2D
    // objects. The angle is returned in degrees as type
    // double.
    public double angle(Vector2D vec){
      Vector2D normA = normalize();
      Vector2D normB = vec.normalize();
      double normDotProd = normA.dot(normB);
      return Math.toDegrees(Math.acos(normDotProd));
    }//end angle
    //--------------------------------------------------//
  }//end class Vector2D
  //====================================================//


  public static class Vector3D{
    ColMatrix3D vector;
    
    //This is an overloaded constructor that is intended
    // to make it easier to instantiate objects of this
    // class.
    public Vector3D(double x,double y,double z){
      this(new ColMatrix3D(x,y,z));
    }//end constructor
    
    //--------------------------------------------------//
    public Vector3D(ColMatrix3D vector){//constructor
      //Create and save a clone of the ColMatrix3D object
      // used to define the vector to prevent the vector
      // from being corrupted by a later change in the
      // values stored in the original ColMatris3D object.
      this.vector = new ColMatrix3D(vector.getData(0),
                                    vector.getData(1),
                                    vector.getData(2));
    }//end constructor
    //--------------------------------------------------//

    public String toString(){
      return vector.getData(0) + "," + vector.getData(1) 
                                + "," + vector.getData(2);
    }//end toString
    //--------------------------------------------------//
    
    public double getData(int index){
      if((index < 0) || (index > 2)){
        throw new IndexOutOfBoundsException();
      }else{
        return vector.getData(index);
      }//end else
    }//end getData
    //--------------------------------------------------//
    
    public void setData(int index,double data){
      if((index < 0) || (index > 2)){ 
        throw new IndexOutOfBoundsException();
      }else{
        vector.setData(index,data);
      }//end else
    }//end setData
    //--------------------------------------------------//
    
    //This overloaded draw method calls the method that
    // follows with dummy parameters.
    public void draw(Graphics2D g2D,
                     Point3D tail,
                     int type){
      draw(g2D,
           tail,
           type,
           0,
           new Point3D(0,0,0),
           new ColMatrix3D(0,0,0));
    }//end overloaded draw method
    //--------------------------------------------------//
    
    //This method draws a vector on the specified graphics
    // context, with the tail of the vector located at a
    // specified point, and with a small circle at the
    // head. The type of projection used is specified by
    // the value of the incoming type parameter. Note
    // that this method is overloaded.
    public void draw(Graphics2D g2D,
                     Point3D tail,
                     int type,
                     double scale,
                     Point3D camera,
                     ColMatrix3D angle){
      //Get a projection of the tail
      Point2D tail2D = null;
      if(type == 0){
        //Parallel projection
        tail2D = threeDto2DprojectionA(tail);
      }else if(type == 1){
        //Simple perspective projection
        tail2D = threeDto2DprojectionB(tail);
      }else if(type == 2){
        //Simple perspective projection
        tail2D = threeDto2DprojectionC(tail);
      }else if(type == 3){
        //complex perspective projection
        tail2D = threeDto2DprojectionD(
                             tail,scale,camera,angle);
      }//end if
      
      //Get the 3D location of the head
      Point3D head = new Point3D(
                     tail.point.add(this.getColMatrix()));
      //Get a projection of the head
      Point2D head2D = null;
      if(type == 0){
        //Parallel projection
        head2D = threeDto2DprojectionA(head);
      }else if(type == 1){
        //Simple perspective projection
        head2D = threeDto2DprojectionB(head);
      }else if(type == 2){
        //Simple perspective projection
        head2D = threeDto2DprojectionC(head);
      }else if(type == 3){
        //Complex perspective projection
        head2D = 
           threeDto2DprojectionD(head,scale,camera,angle);
      }//end if

      drawLine(g2D,tail2D.getData(0),
                   tail2D.getData(1),
                   head2D.getData(0),
                   head2D.getData(1));      

      //Draw a small filled circle to identify the head.
      fillOval(g2D,head2D.getData(0)-3,
                   head2D.getData(1)+3,
                   6,
                   6);

    }//end draw
    //--------------------------------------------------//
    
    //Returns a reference to the ColMatrix3D object that
    // defines this Vector3D object.
    public ColMatrix3D getColMatrix(){
      return vector;
    }//end getColMatrix
    //--------------------------------------------------//

    //This method overrides the equals method inherited
    // from the class named Object. It compares the values
    // stored in the ColMatrix3D objects that define two
    // Vector3D objects and returns true if they are equal
    // and false otherwise. 
    public boolean equals(Object obj){
      if(vector.equals(((Vector3D)obj).getColMatrix())){
        return true;
      }else{
        return false;
      }//end else
     
    }//end overridden equals method
    //--------------------------------------------------//
    
    //Adds this vector to a vector received as an incoming
    // parameter and returns the sum as a vector.
    public Vector3D add(Vector3D vec){
      return new Vector3D(new ColMatrix3D(
                       vec.getData(0)+vector.getData(0),
                       vec.getData(1)+vector.getData(1),
                       vec.getData(2)+vector.getData(2)));
    }//end add
    //--------------------------------------------------//
    
    //Returns the length of a Vector3D object.
    public double getLength(){
      return Math.sqrt(getData(0)*getData(0) + 
                       getData(1)*getData(1) + 
                       getData(2)*getData(2));
    }//end getLength
    //--------------------------------------------------//
    
    //Multiplies this vector by a scale factor received as
    // an incoming parameter and returns the scaled
    // vector.
    public Vector3D scale(Double factor){
      return new Vector3D(new ColMatrix3D(
                                    getData(0) * factor,
                                    getData(1) * factor,
                                    getData(2) * factor));
    }//end scale
    //--------------------------------------------------//
    
    //Multiplies the components of this vector by three
    // scale factors received as an incoming parameter
    // and returns the scaled vector.
    public Vector3D scaleByComponent(
                                      ColMatrix3D factor){
      return new Vector3D(new ColMatrix3D(
                         getData(0) * factor.getData(0),
                         getData(1) * factor.getData(1),
                         getData(2) * factor.getData(2)));
    }//end scale
    //--------------------------------------------------//
    
    //Changes the sign on each of the vector components
    // and returns the negated vector.
    public Vector3D negate(){
      return new Vector3D(new ColMatrix3D(-getData(0),
                                          -getData(1),
                                          -getData(2)));
    }//end negate
    //--------------------------------------------------//
    
    //Returns a new vector that points in the same
    // direction but has a length of one unit.
    public Vector3D normalize(){
      double length = getLength();
      return new Vector3D(new ColMatrix3D(
                                      getData(0)/length,
                                      getData(1)/length,
                                      getData(2)/length));
    }//end normalize
    //--------------------------------------------------//
    
    //Computes the dot product between two Vector3D
    // objects and returns the result as type double.
    public double dot(Vector3D vec){
      ColMatrix3D matrixA = getColMatrix();
      ColMatrix3D matrixB = vec.getColMatrix();
      return matrixA.dot(matrixB);
    }//end dot
    //--------------------------------------------------//
    
    //Computes and returns the angle between two Vector3D
    // objects. The angle is returned in degrees as type
    // double.
    public double angle(Vector3D vec){
      Vector3D normA = normalize();
      Vector3D normB = vec.normalize();
      double normDotProd = normA.dot(normB);
      return Math.toDegrees(Math.acos(normDotProd));
    }//end angle
    //--------------------------------------------------//
    
    //Note that a vector is not very conducive to rotation
    // because it has no location. However, it is possible
    // to create a Point3D object with the same components
    // as the vector, rotate the point around a specified
    // anchor, and then create a new vector having the
    // same components as the rotated point. See the 
    // rotate method of the Point3D class for technical
    // details regarding the rotation of a point.
    public Vector3D rotate(Point3D anchorPoint,
                                      ColMatrix3D angles){
                                
      ColMatrix3D tempA = this.getColMatrix();
      Point3D tempB = new Point3D(tempA);
      tempB = tempB.rotate(anchorPoint,angles);
      return new Vector3D(tempB.getColMatrix());
                        
    }//end rotate
    //--------------------------------------------------//
  }//end class Vector3D
  //====================================================//
  //====================================================//

  
  //A line is defined by two points. One is called the
  // tail and the other is called the head. Note that this
  // class has the same name as one of the classes in
  // the Graphics2D class. Therefore, if the class from
  // the Graphics2D class is used in some future upgrade
  // to this program, it will have to be fully qualified.
  public static class Line2D{
    Point2D[] line = new Point2D[2];
    
    public Line2D(Point2D tail,Point2D head){
      //Create and save clones of the points used to
      // define the line to prevent the line from being 
      // corrupted by a later change in the coordinate
      // values of the points.
      this.line[0] = new Point2D(new ColMatrix2D(
                        tail.getData(0),tail.getData(1)));
      this.line[1] = new Point2D(new ColMatrix2D(
                        head.getData(0),head.getData(1)));
    }//end constructor
    //--------------------------------------------------//

    public String toString(){
      return "Tail = " + line[0].getData(0) + "," 
             + line[0].getData(1) + "\nHead = " 
             + line[1].getData(0) + "," 
             + line[1].getData(1);
    }//end toString
    //--------------------------------------------------//

    public Point2D getTail(){
      return line[0];
    }//end getTail
    //--------------------------------------------------//
    
    public Point2D getHead(){
      return line[1];
    }//end getHead
    //--------------------------------------------------//
    
    public void setTail(Point2D newPoint){
      //Create and save a clone of the new point to
      // prevent the line from being corrupted by a
      // later change in the coordinate values of the
      // point.
      this.line[0] = new Point2D(new ColMatrix2D(
                newPoint.getData(0),newPoint.getData(1)));
    }//end setTail
    //--------------------------------------------------//
    
    public void setHead(Point2D newPoint){
      //Create and save a clone of the new point to
      // prevent the line from being corrupted by a
      // later change in the coordinate values of the
      // point.
      this.line[1] = new Point2D(new ColMatrix2D(
                newPoint.getData(0),newPoint.getData(1)));
    }//end setHead
    //--------------------------------------------------//
    
    public void draw(Graphics2D g2D){
      drawLine(g2D,getTail().getData(0),
                   getTail().getData(1),
                   getHead().getData(0),
                   getHead().getData(1));
    }//end draw
    //--------------------------------------------------//
  }//end class Line2D
  //====================================================//


  //A line is defined by two points. One is called the
  // tail and the other is called the head.
  public static class Line3D{
    Point3D[] line = new Point3D[2];
    
    public Line3D(Point3D tail,Point3D head){
      //Create and save clones of the points used to
      // define the line to prevent the line from being 
      // corrupted by a later change in the coordinate
      // values of the points.
      this.line[0] = new Point3D(new ColMatrix3D(
                                        tail.getData(0),
                                        tail.getData(1),
                                        tail.getData(2)));
      this.line[1] = new Point3D(new ColMatrix3D(
                                        head.getData(0),
                                        head.getData(1),
                                        head.getData(2)));
    }//end constructor
    //--------------------------------------------------//

    public String toString(){
      return "Tail = " + line[0].getData(0) + "," 
                       + line[0].getData(1)  + "," 
                       + line[0].getData(2) 
                       + "\nHead = " 
                       + line[1].getData(0) + "," 
                       + line[1].getData(1) + ","      
                       + line[1].getData(2);
    }//end toString
    //--------------------------------------------------//

    public Point3D getTail(){
      return line[0];
    }//end getTail
    //--------------------------------------------------//
    
    public Point3D getHead(){
      return line[1];
    }//end getHead
    //--------------------------------------------------//

    public void setTail(Point3D newPoint){
      //Create and save a clone of the new point to
      // prevent the line from being corrupted by a
      // later change in the coordinate values of the
      // point.
      this.line[0] = new Point3D(new ColMatrix3D(
                                    newPoint.getData(0),
                                    newPoint.getData(1),
                                    newPoint.getData(2)));
    }//end setTail
    //--------------------------------------------------//
    
    public void setHead(Point3D newPoint){
      //Create and save a clone of the new point to
      // prevent the line from being corrupted by a
      // later change in the coordinate values of the
      // point.
      this.line[1] = new Point3D(new ColMatrix3D(
                                    newPoint.getData(0),
                                    newPoint.getData(1),
                                    newPoint.getData(2)));
    }//end setHead
    //--------------------------------------------------//
    
    
    //This overloaded draw method calls the method that
    // follows with dummy parameters.
    public void draw(Graphics2D g2D,
                     int type){
      draw(g2D,
           type,
           0,
           new Point3D(0,0,0),
           new ColMatrix3D(0,0,0));
    }//end overloaded draw method
    //--------------------------------------------------//

    //Project a 3D line onto a 2D plane. The value of the
    // incoming parameter named type is used to determine
    // the type of projection that will be drawn. Note
    // this method is overloaded.
    public void draw(Graphics2D g2D,
                     int type,
                     double scale,
                     Point3D camera,
                     ColMatrix3D angle){
      
      //Get projection coordinates.
      Point2D tail = null;
      Point2D head = null;
      if(type == 0){
        //Parallel projection.
        tail = threeDto2DprojectionA(getTail());
        head = threeDto2DprojectionA(getHead());
      }else if(type == 1){
        //Simple perspective projection.
        tail = threeDto2DprojectionB(getTail());
        head = threeDto2DprojectionB(getHead());
      }else if(type == 2){
        //Simple perspective projection.
        tail = threeDto2DprojectionC(getTail());
        head = threeDto2DprojectionC(getHead());
      }else if(type == 3){
        //Complex perspective projection.
        tail = threeDto2DprojectionD(
                        getTail(),scale,camera,angle);
        head = threeDto2DprojectionD(
                        getHead(),scale,camera,angle);
      }//end if

      drawLine(g2D,tail.getData(0),
                   tail.getData(1),
                   head.getData(0),
                   head.getData(1));
    }//end draw

    //--------------------------------------------------//
  }//end class Line3D
  //====================================================//

}//end class GM03
//======================================================//
