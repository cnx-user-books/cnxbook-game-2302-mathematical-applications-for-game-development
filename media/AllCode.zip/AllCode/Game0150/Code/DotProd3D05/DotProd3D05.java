//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 03/06/08
//======================================================//

/*DotProd3D05.java 
Copyright 2008, R.G.Baldwin
Revised 03/06/08

The purpose of this program is to demonstrate how the dot 
product can be used to compute nine different angles of 
interest that a vector makes with various elements in 3D 
space.

First, the program computes and displays the angle between
a user-specified vector and each of the X, Y, and Z axes.
These values are displayed with the labels Angle X, 
Angle Y, and Angle Z.

Then the program computes and displays the angle between
the vector and each of the XY, YZ, and ZX planes. In
this case, the program computes the smallest possible 
angle by projecting the vector onto the plane and then 
computing the angle between the vector and its projection.
These values are displayed with the labels Angle XY, 
Angle YZ, and Angle ZX.

Finally, the program computes and displays the angle 
between the projection of the vector on each of the three 
planes and one of the axes that defines each plane. 
Obviously, the angle between the projection and the other 
vector that defines the plane is 90 degrees less the 
computed angle.  Specifically the values that are computed
and displayed are:

Projection onto the XY plane relative to the x-axis,
displayed with the label Angle PX.

Projection onto the YZ plane relative to the y-axis,
displayed with the label Angle PY.

Projection onto the ZX plane relative to the z-axis,
displayed with the label Angle PZ.

All angles are reported as positive angles in degrees.
  
Study Kjell through Chapter 10, Angle between 3D Vectors.

A GUI is provided that allows the user to enter three
double values that define a GM02.Vector3D object.  The GUI
also provides an OK button as well as nine text fields 
used to display the computed results described above.

In addition, the GUI provides a 3D drawing area.

When the user clicks the OK button, the program draws the
user-specified vector in black with the tail located at 
the origin in 3D space. It also draws the projection of
that vector in magenta on each of the XY, YZ, AND ZX
planes

Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class DotProd3D05{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class DotProd3D05
//======================================================//

class GUI extends JFrame implements ActionListener{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 400;
  int vSize = 400;
  Image osi;//an off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas 
  Graphics2D g2D;//off-screen graphics context.

  //User input components.
  JTextField vecX = new JTextField("50.0");
  JTextField vecY = new JTextField("100.0");
  JTextField vecZ = new JTextField("0.0");

  JTextField angleX = new JTextField("0");
  JTextField angleY = new JTextField("0");
  JTextField angleZ = new JTextField("0");
  
  JTextField angleXY = new JTextField("0");
  JTextField angleYZ = new JTextField("0");
  JTextField angleZX = new JTextField("0");
  
  JTextField anglePX = new JTextField("0");
  JTextField anglePY = new JTextField("0");
  JTextField anglePZ = new JTextField("0");

  JButton button = new JButton("OK");
  
  //----------------------------------------------------//
  
  GUI(){//constructor

    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Copyright 2008,R.G.Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    //Instantiate a JPanel that will house the user input
    // components and set its layout manager.
    JPanel controlPanel = new JPanel();
    controlPanel.setLayout(new GridLayout(0,6));

    //Add the user input components and appropriate labels
    // to the control panel.
    controlPanel.add(new JLabel(" Vec X "));    
    controlPanel.add(vecX);

    controlPanel.add(new JLabel(" Vec Y "));    
    controlPanel.add(vecY);
    
    controlPanel.add(new JLabel(" Vec Z "));    
    controlPanel.add(vecZ);
    
    controlPanel.add(new JLabel(" Angle X "));    
    controlPanel.add(angleX);
    
    controlPanel.add(new JLabel(" Angle Y "));    
    controlPanel.add(angleY);
    
    controlPanel.add(new JLabel(" Angle Z "));    
    controlPanel.add(angleZ);
    
    controlPanel.add(new JLabel(" Angle XY "));    
    controlPanel.add(angleXY);
    
    controlPanel.add(new JLabel(" Angle YZ "));    
    controlPanel.add(angleYZ);
    
    controlPanel.add(new JLabel(" Angle ZX "));
    controlPanel.add(angleZX);
    
    controlPanel.add(new JLabel(" Angle PX "));    
    controlPanel.add(anglePX);
    
    controlPanel.add(new JLabel(" Angle PY "));    
    controlPanel.add(anglePY);
    
    controlPanel.add(new JLabel(" Angle PZ "));
    controlPanel.add(anglePZ);
    
    controlPanel.add(button);

    //Add the control panel to the SOUTH position in the
    // JFrame.
    this.getContentPane().add(
                        BorderLayout.SOUTH,controlPanel);

    
    //Create a new drawing canvas and add it to the
    // CENTER of the JFrame above the control panel.
    myCanvas = new MyCanvas();
    this.getContentPane().add(
                            BorderLayout.CENTER,myCanvas);

    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    
    //Make the size of the off-screen image match the
    // size of the canvas.
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();
    
    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    g2D = (Graphics2D)(osi.getGraphics());
    

    //Translate the origin to the center.
    GM02.translate(g2D,0.5*osiWidth,-0.5*osiHeight);

    
    //Register this object as an action listener on the
    // button.
    button.addActionListener(this);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();
    
  }//end constructor
  //----------------------------------------------------//
  
  //This method is used to draw orthogonal 3D axes on the
  // off-screen image that intersect at the origin.
  private void setCoordinateFrame(Graphics2D g2D){

    //Erase the screen
    g2D.setColor(Color.WHITE);
    GM02.fillRect(g2D,-osiWidth/2,osiHeight/2,
                                      osiWidth,osiHeight);

    //Draw x-axis in RED
    g2D.setColor(Color.RED);
    GM02.Point3D pointA = new GM02.Point3D(
                   new GM02.ColMatrix3D(-osiWidth/2,0,0));
    GM02.Point3D pointB = new GM02.Point3D(
                    new GM02.ColMatrix3D(osiWidth/2,0,0));
    new GM02.Line3D(pointA,pointB).draw(g2D);
    
    //Draw y-axis in GREEN
    g2D.setColor(Color.GREEN);
    pointA = new GM02.Point3D(
                  new GM02.ColMatrix3D(0,-osiHeight/2,0));
    pointB = new GM02.Point3D(
                   new GM02.ColMatrix3D(0,osiHeight/2,0));
    new GM02.Line3D(pointA,pointB).draw(g2D);
    
    //Draw z-axis in BLUE. Make its length the same as the
    // length of the x-axis.
    g2D.setColor(Color.BLUE);
    pointA = new GM02.Point3D(
                   new GM02.ColMatrix3D(0,0,-osiWidth/2));
    pointB = new GM02.Point3D(
                    new GM02.ColMatrix3D(0,0,osiWidth/2));
    new GM02.Line3D(pointA,pointB).draw(g2D);

  }//end setCoordinateFrame method
  //----------------------------------------------------//
  
  //This method is called to respond to a click on the
  // button.
  public void actionPerformed(ActionEvent e){
    
    //Erase the off-screen image and draw the axes.
    setCoordinateFrame(g2D);
    
    //Create one ColMatrix3D object based on the user
    // input values.
    GM02.ColMatrix3D matrixA = new GM02.ColMatrix3D(
                  Double.parseDouble(vecX.getText()),
                  Double.parseDouble(vecY.getText()),
                  Double.parseDouble(vecZ.getText()));
                  
    //Create ColMatrix3D objects that represent each of
    // the three axes.
    GM02.ColMatrix3D matrixX = 
                              new GM02.ColMatrix3D(1,0,0);
    GM02.ColMatrix3D matrixY = 
                              new GM02.ColMatrix3D(0,1,0);
    GM02.ColMatrix3D matrixZ = 
                              new GM02.ColMatrix3D(0,0,1);
    
    //Create ColMatrix3D objects that represent the
    // projection of the user-specified vector onto each
    // of the three planes.
    GM02.ColMatrix3D matrixXY = new GM02.ColMatrix3D(
                      Double.parseDouble(vecX.getText()),
                      Double.parseDouble(vecY.getText()),
                      0);
                  
    GM02.ColMatrix3D matrixYZ = new GM02.ColMatrix3D(
                      0,
                      Double.parseDouble(vecY.getText()),
                      Double.parseDouble(vecZ.getText()));
                  
    GM02.ColMatrix3D matrixZX = new GM02.ColMatrix3D(
                      Double.parseDouble(vecX.getText()),
                      0,
                      Double.parseDouble(vecZ.getText()));
    


    //Use the ColMatrix3D objects to create Vector3D
    // objects representing the user-specified vector and
    // each of the axes.
    GM02.Vector3D vecA = new GM02.Vector3D(matrixA);
    GM02.Vector3D vecX = new GM02.Vector3D(matrixX);
    GM02.Vector3D vecY = new GM02.Vector3D(matrixY);
    GM02.Vector3D vecZ = new GM02.Vector3D(matrixZ);
    
    //Create Vector3D objects that represent the
    // projection of the user-specified vector on each of
    // the planes.
    GM02.Vector3D vecXY = new GM02.Vector3D(matrixXY);
    GM02.Vector3D vecYZ = new GM02.Vector3D(matrixYZ);
    GM02.Vector3D vecZX = new GM02.Vector3D(matrixZX);
    	                    
    //Draw the projection of the user specified vector on
    // each of the three planes.
    g2D.setColor(Color.MAGENTA);
    vecXY.draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));
    vecYZ.draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));
    vecZX.draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));
    
    //Draw the user-specified vector with its tail at the
    // origin.
    g2D.setColor(Color.BLACK);
    vecA.draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));
    
    	                    

    //Compute and display the angle relative to the
    // x-axis.
    double angle = vecA.angle(vecX);
    angleX.setText("" +  prepareForDisplay(angle));

    //Compute and display the angle relative to the
    // y-axis.
    angle = vecA.angle(vecY);
    angleY.setText("" +  prepareForDisplay(angle));
    
    //Compute and display the angle relative to the
    // z-axis.
    angle = vecA.angle(vecZ);
    angleZ.setText("" +  prepareForDisplay(angle));
    
    
    //Compute and display the angle relative to the
    // XY plane
    angle = vecA.angle(vecXY);
    angleXY.setText("" +  prepareForDisplay(angle));
    
    //Compute and display the angle relative to the
    // YZ plane
    angle = vecA.angle(vecYZ);
    angleYZ.setText("" +  prepareForDisplay(angle));
    
    //Compute and display the angle relative to the
    // ZX plane
    angle = vecA.angle(vecZX);
    angleZX.setText("" +  prepareForDisplay(angle));
    
    
    //Compute and display the angle of the projection onto
    // the XY plane relative to the x-axis
    angle = vecXY.angle(vecX);
    anglePX.setText("" +  prepareForDisplay(angle));
    
    //Compute and display the angle of the projection onto
    // the YZ plane relative to the y-axis
    angle = vecYZ.angle(vecY);
    anglePY.setText("" +  prepareForDisplay(angle));
    
    //Compute and display the angle of the projection onto
    // the ZX plane relative to the z-axis
    angle = vecZX.angle(vecZ);
    anglePZ.setText("" +  prepareForDisplay(angle));    
    

    myCanvas.repaint();//Copy off-screen image to canvas.
    
    
  }//end actionPerformed
  //----------------------------------------------------//
  
  //The code in this method prepares a double value for
  // display in a text field by eliminating exponential
  // format for very small values and setting the number
  // of decimal digits to four.
  private double prepareForDisplay(double data){
      //Eliminate exponential notation in the display.
      if(Math.abs(data) < 0.001){
        data = 0.0;
      }//end if
      
      //Convert to four decimal digits.
      return ((int)(10000*data))/10000.0;
  }//end prepareForDisplay
  
  //====================================================//
  
  
  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    //The purpose of this method is to display the
    // off-screen image on the screen.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()
    
  }//end inner class MyCanvas
    
}//end class GUI
//======================================================//
