//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 03/07/08
//======================================================//

/*DotProd3D04.java 
Copyright 2008, R.G.Baldwin
Revised 03/07/08

The purpose of this program is serve as a counterpoint to 
the program named Prob3D03, which demonstrates backface 
culling.

This program draws the same 3D object as the one drawn in 
DotProd3D03 but without the benefit of backface culling.

Study Kjell through Chapter 10, Angle between 3D Vectors.

The program draws a 3D circular cylinder by stacking 20 
circular disks on the x-z plane. The disks are centered on
the y-axis and are parallel to the x-z plane. The 
thickness of each disk is 5 vertical units.

There is no backface culling in this program, so all of 
the lines that should be hidden show through.


Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.*;
import javax.swing.*;

class DotProd3D04{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class DotProd3D04
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 230;
  int vSize = 250;
  Image osi;//an off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas 
  Graphics2D g2D;//off-screen graphics context.
  //----------------------------------------------------//
  
  GUI(){//constructor

    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Copyright 2008,R.G.Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    //Create a new drawing canvas and add it to the
    // CENTER of the JFrame above the control panel.
    myCanvas = new MyCanvas();
    this.getContentPane().add(
                            BorderLayout.CENTER,myCanvas);

    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    
    //Make the size of the off-screen image match the
    // size of the canvas.
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();
    
    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    g2D = (Graphics2D)(osi.getGraphics());

    //Call a method that sets the axes and draws the 
    // cylinder.
    drawTheCylinder(g2D);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();
    
  }//end constructor
  //----------------------------------------------------//
  
  //This method is used to set the axes to the center of
  // the off-screen image and to draw a 3D cylinder that
  // is centered on the y-axis.
  private void drawTheCylinder(Graphics2D g2D){

    //Translate the origin to the center of the off-screen
    // image.
    GM02.translate(g2D,0.5*osiWidth,-0.5*osiHeight);
    
    //Erase the screen
    g2D.setColor(Color.WHITE);
    GM02.fillRect(g2D,-osiWidth/2,osiHeight/2,
                                      osiWidth,osiHeight);
    //Draw a cylinder by stacking 20 circular disks on
    // the x-z plane. The disks are centered on the
    // y-axis and are parallel to the x-z plane. The
    // thickness of each disk is 5 vertical units.
    GM02.Point3D tempPointA;
    GM02.Point3D tempPointB;
    g2D.setColor(Color.BLACK);
    
    for(int y = 0;y < 105;y += 5){//iterate on disks
      //Define the starting point on the circle for this
      // disk.
      tempPointA = new GM02.Point3D(
              new GM02.ColMatrix3D(76,y - osiHeight/4,0));
      //Iterate on points on the circle that represents
      // this disk.
      for(int cnt = 0;cnt < 360;cnt++){//360 points
        //Compute the next point on the circle.
        tempPointB = 
            new GM02.Point3D(new GM02.ColMatrix3D(
              76*Math.cos(Math.toRadians(cnt*360/360)),
              y - osiHeight/4,
              76*Math.sin(Math.toRadians(cnt*360/360))));

        //Draw the line in 3D. Note that there is no
        // backface culling in this program.
        new GM02.Line3D(tempPointA,tempPointB).draw(g2D);

        //Save the point for use in drawing the next line.
        tempPointA = tempPointB;
      }//end for loop on points
    }//end for loop on disks

  }//end drawTheCylinder method
  //====================================================//
  
  
  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    //The purpose of this method is to display the
    // off-screen image on the screen.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()
    
  }//end inner class MyCanvas
    
}//end class GUI
//======================================================//
