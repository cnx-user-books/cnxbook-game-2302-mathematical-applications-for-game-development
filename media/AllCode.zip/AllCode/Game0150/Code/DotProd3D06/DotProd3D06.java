//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 03/09/08
//======================================================//

/*DotProd3D06.java 
Copyright 2008, R.G.Baldwin
Revised 03/09/08

This program demonstrates how the dot product can be used
to find vectors that are perpendicular to a given vector.

The program computes and displays normalized and scaled
versions of six of the infinite set of vectors that are 
perpendicular to a user specified vector.

If the user specifies one of the coordinates to be zero
or close to zero, the program only computes and displays 
four of the possible vectors in order to avoid performing 
division by a near-zero value. For a value of zero, the
orientation of two of the vectors will overlay the 
orientation of the other two, but depending on the values
of the two vectors, you may see four heads.

If the user specifies two of the coordinates to be zero
or close to zero, the program doesn't produce a valid
result.  Instead, it displays the coordinates for a 
perpendicular vector where all of the coordinates are
zero and displays NaN for the angle.

Study Kjell through Chapter 10, Angle between 3D Vectors.

A GUI is provided that allows the user to enter three
double values that define a GM02.Vector3D object.  The GUI
also provides an OK button.

In addition, the GUI provides a 3D drawing area.

When the user clicks the OK button, the program draws the
user-specified vector in black with the tail located at 
the origin in 3D space. It also draws normalized versions
of the perpendicular vectors in magenta with their tails 
located at the origin.  Each normalized vector is scaled
by a factor of 50 before it is drawn.

The program also displays the values of three of the
perpendicular vectors on the command-line screen along
with the angle between the perpendicular vector and the
user-specified vector. The angle should be 90 degrees or
at least very very close to 90 degrees. The other three
perpendicular vectors are simply negated versions of the
three for which the values are displayed.

Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class DotProd3D06{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class DotProd3D06
//======================================================//

class GUI extends JFrame implements ActionListener{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 400;
  int vSize = 400;
  Image osi;//an off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas 
  Graphics2D g2D;//off-screen graphics context.

  //User input components.
  JTextField vecX = new JTextField("50.0");
  JTextField vecY = new JTextField("50.0");
  JTextField vecZ = new JTextField("50.0");

  JButton button = new JButton("OK");
  
  //----------------------------------------------------//
  
  GUI(){//constructor

    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Copyright 2008,R.G.Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    //Instantiate a JPanel that will house the user input
    // components and set its layout manager.
    JPanel controlPanel = new JPanel();
    controlPanel.setLayout(new GridLayout(0,6));

    //Add the user input components and appropriate labels
    // to the control panel.
    controlPanel.add(new JLabel(" Vec X "));    
    controlPanel.add(vecX);

    controlPanel.add(new JLabel(" Vec Y "));    
    controlPanel.add(vecY);
    
    controlPanel.add(new JLabel(" Vec Z "));    
    controlPanel.add(vecZ);

    controlPanel.add(button);

    //Add the control panel to the SOUTH position in the
    // JFrame.
    this.getContentPane().add(
                        BorderLayout.SOUTH,controlPanel);

    
    //Create a new drawing canvas and add it to the
    // CENTER of the JFrame above the control panel.
    myCanvas = new MyCanvas();
    this.getContentPane().add(
                            BorderLayout.CENTER,myCanvas);

    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    
    //Make the size of the off-screen image match the
    // size of the canvas.
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();
    
    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    g2D = (Graphics2D)(osi.getGraphics());
    

    //Translate the origin to the center.
    GM02.translate(g2D,0.5*osiWidth,-0.5*osiHeight);

    
    //Register this object as an action listener on the
    // button.
    button.addActionListener(this);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();
    
  }//end constructor
  //----------------------------------------------------//
  
  //This method is used to draw orthogonal 3D axes on the
  // off-screen image that intersect at the origin.
  private void setCoordinateFrame(Graphics2D g2D){

    //Erase the screen
    g2D.setColor(Color.WHITE);
    GM02.fillRect(g2D,-osiWidth/2,osiHeight/2,
                                      osiWidth,osiHeight);

    //Draw x-axis in RED
    g2D.setColor(Color.RED);
    GM02.Point3D pointA = new GM02.Point3D(
                   new GM02.ColMatrix3D(-osiWidth/2,0,0));
    GM02.Point3D pointB = new GM02.Point3D(
                    new GM02.ColMatrix3D(osiWidth/2,0,0));
    new GM02.Line3D(pointA,pointB).draw(g2D);
    
    //Draw y-axis in GREEN
    g2D.setColor(Color.GREEN);
    pointA = new GM02.Point3D(
                  new GM02.ColMatrix3D(0,-osiHeight/2,0));
    pointB = new GM02.Point3D(
                   new GM02.ColMatrix3D(0,osiHeight/2,0));
    new GM02.Line3D(pointA,pointB).draw(g2D);
    
    //Draw z-axis in BLUE. Make its length the same as the
    // length of the x-axis.
    g2D.setColor(Color.BLUE);
    pointA = new GM02.Point3D(
                   new GM02.ColMatrix3D(0,0,-osiWidth/2));
    pointB = new GM02.Point3D(
                    new GM02.ColMatrix3D(0,0,osiWidth/2));
    new GM02.Line3D(pointA,pointB).draw(g2D);

  }//end setCoordinateFrame method
  //----------------------------------------------------//
  
  //This method is called to respond to a click on the
  // button.
  public void actionPerformed(ActionEvent e){
    
    //Erase the off-screen image and draw the axes.
    setCoordinateFrame(g2D);
    
    //Get and save the user specified coordinate values.
    double xCoor = Double.parseDouble(vecX.getText());
    double yCoor = Double.parseDouble(vecY.getText());
    double zCoor = Double.parseDouble(vecZ.getText());
    
    //Create a ColMatrix3D object based on the user input
    // values.
    GM02.ColMatrix3D matrixA = 
                  new GM02.ColMatrix3D(xCoor,yCoor,zCoor);
    
    //Use the ColMatrix3D object to create a Vector3D
    // object representing the user-specified vector.
    GM02.Vector3D vecA = new GM02.Vector3D(matrixA);
    
    //Draw the user-specified vector with its tail at the
    // origin.
    g2D.setColor(Color.BLACK);
    vecA.draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));
    
    //Create and draw the perpendicular vectors.  However,
    // if a coordinate value is near zero, don't attempt
    // to create and draw the perpendicular vector that
    // would require division by the near-zero value.
    GM02.Vector3D tempVec;
    GM02.ColMatrix3D tempMatrix;
    g2D.setColor(Color.MAGENTA);
    
    if(Math.abs(zCoor) > 0.001){
      tempMatrix = new GM02.ColMatrix3D(
          xCoor,yCoor,-(xCoor*xCoor + yCoor*yCoor)/zCoor);
      tempVec = new GM02.Vector3D(tempMatrix);
      System.out.println(tempVec);
      //Normalize and scale the perpendicular vector.
      tempVec = tempVec.normalize().scale(50.0);
      tempVec.draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));
      tempVec.negate().draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));
      System.out.println(vecA.angle(tempVec));
    }//end if
    
    if(Math.abs(yCoor) > 0.001){
      tempMatrix = new GM02.ColMatrix3D(
          xCoor,-(xCoor*xCoor + zCoor*zCoor)/yCoor,zCoor);
      tempVec = new GM02.Vector3D(tempMatrix);
      System.out.println(tempVec);
      //Normalize and scale the perpendicular vector.
      tempVec = tempVec.normalize().scale(50.0);
      tempVec.draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));
      tempVec.negate().draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));
      System.out.println(vecA.angle(tempVec));
    }//end if
    
    if(Math.abs(xCoor) > 0.001){
      tempMatrix = new GM02.ColMatrix3D(
         -(yCoor*yCoor + zCoor*zCoor)/xCoor, yCoor,zCoor);
      tempVec = new GM02.Vector3D(tempMatrix);
      System.out.println(tempVec);
      //Normalize and scale the perpendicular vector.
      tempVec = tempVec.normalize().scale(50.0);
      tempVec.draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));
      tempVec.negate().draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));
      System.out.println(vecA.angle(tempVec));
    }//end if


    myCanvas.repaint();//Copy off-screen image to canvas.
    System.out.println();//blank line
  }//end actionPerformed
  //----------------------------------------------------//
 
  //====================================================//
  
  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    //The purpose of this method is to display the
    // off-screen image on the screen.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()
    
  }//end inner class MyCanvas
    
}//end class GUI
//======================================================//
