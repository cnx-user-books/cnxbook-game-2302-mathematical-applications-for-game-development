//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish 02/03/08
//======================================================//

/*PointLine04.java 
Copyright 2008, R.G.Baldwin
Revised 02/03/08

This program emphasizes the differences between graphics 
objects and underlying data objects.  It also illustrates 
the use of the new setData methods of the Point class and 
the Vector class, along with the new setTail and setHead 
methods of the Line class. The methods were added to the
game-math library when it was updated to the GM2D02
version.

This program produces the same graphic output as that 
produced by PointLine03, but it produces that output in
a significantly different way.

Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.*;
import javax.swing.*;

class PointLine04{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class PointLine04
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 400;
  int vSize = 200;
  Image osiA;//one off-screen image
  Image osiB;//another off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas
  
  GUI(){//constructor
    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Copyright 2008,R.G.Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    //Create a new drawing canvas and add it to the
    // center of the JFrame.
    myCanvas = new MyCanvas();
    this.getContentPane().add(myCanvas);
    
    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    osiWidth = myCanvas.getWidth()/2;
    osiHeight = myCanvas.getHeight();

    //Create two off-screen images and get a graphics
    // context on each.
    osiA = createImage(osiWidth,osiHeight);
    Graphics2D g2Da = (Graphics2D)(osiA.getGraphics());
    
    osiB = createImage(osiWidth,osiHeight);
    Graphics2D g2Db = (Graphics2D)(osiB.getGraphics());
  
    //Draw some points, lines, and vectors on the two
    // off-screen images.
    drawOffscreen(g2Da,g2Db);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();

  }//end constructor
  //----------------------------------------------------//
  
  //The purpose of this method is to define points, lines,
  // and vectors and then to cause a visual manifestation
  // of some of the points, lines, and vectors to be
  // drawn onto two separate off-screen images. The method
  // uses a minimum number of underlying data objects to 
  // produce the output, thereby emphasizing the
  // differences between graphics objects and underlying
  // data objects.
  void drawOffscreen(Graphics2D g2Da,Graphics2D g2Db){

    //Draw a label on each off-screen image.
    g2Da.drawString("Off-screen image A",
                    osiWidth/8,
                    osiHeight/8);
    g2Db.drawString("Off-screen image B",
                    osiWidth/8,
                    osiHeight/8);
    
    //Draw borders on each of the off-screen images by
    // drawing lines parallel to the edges of the
    // off-screen. Each line is offset by one pixel toward
    // the center of the off-screen image.
    //First define and save a point at the upper left
    // corner that will be used as an end point of the
    // top and left borders.
    GM2D02.Point upperLeftPoint = new GM2D02.Point(
                           new GM2D02.ColMatrix(1.0,1.0));

    //Define a point that will be used as an end point for
    // all four lines. The location of this point will be
    // modified several times during the drawing of the
    // border by calling the set method on the point. The
    // initial location of this point is the upper-right
    // corner. Remember, the origin is at the upper-left
    // corner of the off-screen images at this point in
    // the program. Make the y-coordinate the same as the
    // y-coordinate for the upperLeftPoint.
    GM2D02.Point aPoint = new GM2D02.Point(
         new GM2D02.ColMatrix(osiWidth-1,
                              upperLeftPoint.getData(1)));

    //Define a line that will be modified several times in
    // seccession by calling its set methods to draw the
    // top, right, bottom, and left lines that make up the
    // border. Use it here to draw the line at the top
    // of both of the off-screen images.
    GM2D02.Line theLine = new GM2D02.Line(
                                   upperLeftPoint,aPoint);
    theLine.draw(g2Da);
    theLine.draw(g2Db);                    

    //Draw right border.
    //Save the previous head as the new tail.
    theLine.setTail(theLine.getHead());
    //Modify the location of aPoint. There's no need to
    // change the x-coordinate. Just change the
    // y-coordinate to move the point down the screen in
    // the positive y direction to the lower-right corner.
    aPoint.setData(1,osiHeight-1);
    //Use the new location of aPoint as the new head.
    theLine.setHead(aPoint);
    theLine.draw(g2Da);
    theLine.draw(g2Db);
    
    //Draw bottom border. There's no need to change the
    // y-coordinate in the new point, which is located
    // at the lower-left corner.
    theLine.setTail(theLine.getHead());
    aPoint.setData(0,1.0);
    theLine.setHead(aPoint);
    theLine.draw(g2Da);
    theLine.draw(g2Db);

    //Draw left border to close the rectangular border.
    theLine.setTail(theLine.getHead());
    theLine.setHead(upperLeftPoint);
    theLine.draw(g2Da);
    theLine.draw(g2Db);


    //Translate the origin of g2Da to the center of the
    // off-screen image.
    g2Da.translate(osiWidth/2.0,osiHeight/2.0);
    
    //Define a point at the new origin and draw a visual
    // manifestation of the point.
    GM2D02.Point origin = new GM2D02.Point(
                           new GM2D02.ColMatrix(0.0,0.0));
    origin.draw(g2Da);
    
    //Define two points and one line and use them to
    // define and draw a hexagon that is symmetrically
    // located relative to the origin.  Begin at the right
    // and move clockwise around the origin.

    //First establish three constants to make it easier
    // to write the code.
    final double aVal = osiWidth/4.0*0.5;
    final double bVal = osiWidth/4.0*0.866;
    final double cVal = osiWidth/4.0;

    //The coordinates of the following point are modified
    // several times in succession to define the vertices
    // of the hexagon.  Instantiate the point and draw it.
    GM2D02.Point thePoint = new GM2D02.Point(
                          new GM2D02.ColMatrix(cVal,0.0));
    thePoint.draw(g2Da);
    
    //Save a clone of thePoint to be used to draw the
    // first line and the last line that closes the
    // hexagon.
    GM2D02.Point startAndEndPoint = new GM2D02.Point(
              new GM2D02.ColMatrix(
                thePoint.getData(0),thePoint.getData(1)));
    
    //Now call the set method twice to modify the location
    // of thePoint, Draw thePoint, and use it to
    // instantiate and draw a line from the starting
    // location to the new location.
    thePoint.setData(0,aVal);
    thePoint.setData(1,bVal);
    thePoint.draw(g2Da);
    GM2D02.Line aLine = new GM2D02.Line(
                               startAndEndPoint,thePoint);
    aLine.draw(g2Da);
   
    //Repeat the process four more times using
    // startAndEndPoint, thePoint, and aLine to draw the
    // remaining vertices and lines.
    //Modify aLine, saving the previous head as the new
    // tail.
    aLine.setTail(aLine.getHead());
    //Modify the location of aPoint and draw it. There's
    // no need to change the y-coordinate of the point.
    thePoint.setData(0,-aVal);
    thePoint.draw(g2Da);
    //Modify the end point of aLine and draw it.
    aLine.setHead(thePoint);  
    aLine.draw(g2Da);

    aLine.setTail(aLine.getHead());
    thePoint.setData(0,-cVal);
    thePoint.setData(1,0.0);
    thePoint.draw(g2Da);
    aLine.setHead(thePoint);
    aLine.draw(g2Da);

    aLine.setTail(aLine.getHead());
    thePoint.setData(0,-aVal);
    thePoint.setData(1,-bVal);
    thePoint.draw(g2Da);
    aLine.setHead(thePoint);
    aLine.draw(g2Da);
    
    aLine.setTail(aLine.getHead());
    thePoint.setData(0,aVal);
    //No need to change the y-coordinate.
    thePoint.draw(g2Da);
    aLine.setHead(thePoint);
    aLine.draw(g2Da);
    
    //Now modify and draw aLine to close the hexagon.
    aLine.setTail(aLine.getHead());
    aLine.setHead(startAndEndPoint);
    aLine.draw(g2Da);

    
    //Now define a vector, call the set method to modify
    // it several times, and draw different visual
    // manifestations of the vector on g2Db.
    //First define two constants to make it easier to
    // write the code.
    final double firstTail = 50;
    final double firstHead = 100;    
    
    GM2D02.Vector vec = new GM2D02.Vector(
               new GM2D02.ColMatrix(firstTail,firstHead));
    //Draw vec in red with its tail at the origin, which
    // is still at the upper-left corner of the g2Db
    // off-screen image
    g2Db.setColor(Color.RED);
    vec.draw(g2Db,new GM2D02.Point(
                              new GM2D02.ColMatrix(0,0)));
                            
    //Call the set method to modify vec.
    vec.setData(0,75);
    vec.setData(1,25);
    //Draw three visual manifestations of vec.  Cause
    // the tail to coincide with the head of the previous
    // visual manifestation of vec in one of the three new
    // visual manifestations. Make all three of them
    // green.
    g2Db.setColor(Color.GREEN);
    vec.draw(g2Db,new GM2D02.Point(new GM2D02.ColMatrix(
                                   firstTail,firstHead)));
    vec.draw(g2Db,new GM2D02.Point(new GM2D02.ColMatrix(
                             firstTail-10,firstHead+15)));
    vec.draw(g2Db,new GM2D02.Point(new GM2D02.ColMatrix(
                             firstTail+10,firstHead-60)));

    //Call the set method to modify vec again.
    vec.setData(0,125);
    vec.setData(1,125);

    //Draw the modified vec in blue with its tail at the
    // origin.
    g2Db.setColor(Color.BLUE);
    vec.draw(g2Db,new GM2D02.Point(
                              new GM2D02.ColMatrix(0,0)));

  }//end drawOffScreen
  //====================================================//
  
  
  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    //The purpose of this method is to display the two
    // off-screen images on the screen in a side-by-side
    // format.
    public void paint(Graphics g){
      g.drawImage(osiA,0,0,this);
      g.drawImage(osiB,this.getWidth()/2,0,this);
    }//end overridden paint()
    
  }//end inner class MyCanvas
    
}//end class GUI
//======================================================//
