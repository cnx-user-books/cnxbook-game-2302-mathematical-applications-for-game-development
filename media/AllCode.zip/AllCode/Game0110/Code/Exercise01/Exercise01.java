//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/03/08
//======================================================//

/*Exercise01.java
Copyright 2012, R.G.Baldwin
Using Java and the game-math library named GM2D02, or
using the programming environment of your choice, write a
program that draws a horizontal line segment and a
vertical line segment representing the x and y axes in a
2D Cartesian coordinate system as shown in Figure 2.

Cause the origin of your reference frame be at the
center of your drawing.

Cause the positive x direction be to the right.

Cause the positive y direction be either up or down
according to your choice.

Cause the program to display your name in some manner.

Tested using JDK 1.7 under WinXP and Windows 7
*********************************************************/
import java.awt.*;
import javax.swing.*;

class Exercise01{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class Exercise01
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 300;
  int vSize = 300;
  Image osi;//off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas

  GUI(){//constructor
    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Ex01, Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //Create a new drawing canvas and add it to the
    // center of the JFrame.
    myCanvas = new MyCanvas();
    this.getContentPane().add(myCanvas);

    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();

    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    Graphics2D g2Da = (Graphics2D)(osi.getGraphics());

    //Translate the origin to the center of the
    // off-screen image.
    g2Da.translate(osiWidth/2.0,osiHeight/2.0);

    //Draw the Cartesian coordinate axes
    drawAxes(g2Da);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();

  }//end constructor
  //----------------------------------------------------//

  //The purpose of this method is to draw a pair of
  // Cartesian coordinate axes onto the
  // off-screen image.
  void drawAxes(Graphics2D g2Da){

    //Define four points at the edges of the coordinate
    // frame and the ends of the axes.
    GM2D02.Point point0 = new GM2D02.Point(
                     new GM2D02.ColMatrix(-osiWidth/2,0));
    GM2D02.Point point1 = new GM2D02.Point(
                      new GM2D02.ColMatrix(osiWidth/2,0));
    GM2D02.Point point2 = new GM2D02.Point(
                    new GM2D02.ColMatrix(0,-osiHeight/2));
    GM2D02.Point point3 = new GM2D02.Point(
                     new GM2D02.ColMatrix(0,osiHeight/2));

    //Now define the two lines based on the end points..
    GM2D02.Line xAxis = new GM2D02.Line(point0,point1);
    GM2D02.Line yAxis = new GM2D02.Line(point2,point3);

    //Now draw a visual manifestation of each line
    // on g2Da.
    xAxis.draw(g2Da);
    yAxis.draw(g2Da);

  }//end drawAxes
  //====================================================//

  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()

  }//end inner class MyCanvas

}//end class GUI
//======================================================//
