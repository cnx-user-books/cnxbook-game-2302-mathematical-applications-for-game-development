//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/03/08
//======================================================//

/*PointLine03.java 
Copyright 2008, R.G.Baldwin
Revised 02/03/08

This program illustrates the use of draw methods that
were added to the GM2D02 game-math library to produce 
visual manifestations of point, line, and vector objects 
instantiated from classes in the game-math library
named GM2D02.

The program also illustrates drawing on off-screen images
and then copying those images to a Canvas object in an
overridden paint method.

Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.*;
import javax.swing.*;

class PointLine03{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class PointLine03
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 400;
  int vSize = 200;
  Image osiA;//one off-screen image
  Image osiB;//another off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas
  
  GUI(){//constructor
    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Copyright 2008,R.G.Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    //Create a new drawing canvas and add it to the
    // center of the JFrame.
    myCanvas = new MyCanvas();
    this.getContentPane().add(myCanvas);
    
    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    osiWidth = myCanvas.getWidth()/2;
    osiHeight = myCanvas.getHeight();

    //Create two off-screen images and get a graphics
    // context on each.
    osiA = createImage(osiWidth,osiHeight);
    Graphics2D g2Da = (Graphics2D)(osiA.getGraphics());
    
    osiB = createImage(osiWidth,osiHeight);
    Graphics2D g2Db = (Graphics2D)(osiB.getGraphics());
    
    //Draw some points, lines, and vectors on the two
    // off-screen images.
    drawOffscreen(g2Da,g2Db);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();

  }//end constructor
  //----------------------------------------------------//
  
  //The purpose of this method is to define points, lines,
  // and vectors and then to cause a visual manifestation
  // of some of the points, lines, and vectors to be
  // drawn onto two separate off-screen images.
  void drawOffscreen(Graphics2D g2Da,Graphics2D g2Db){
    
    //Draw a label on each off-screen image.
    g2Da.drawString("Off-screen image A",
                    osiWidth/8,
                    osiHeight/8);
    g2Db.drawString("Off-screen image B",
                    osiWidth/8,
                    osiHeight/8);
    
    //Define four lines that can be used to draw borders
    // on each of the off-screen images.
    //First define four points that will be used to define
    // the ends of the four lines.
    GM2D02.Point upperLeftPoint = new GM2D02.Point(
                           new GM2D02.ColMatrix(1.0,1.0));
    GM2D02.Point upperRightPoint = new GM2D02.Point(
                    new GM2D02.ColMatrix(osiWidth-1,1.0));
    GM2D02.Point lowerRightPoint = new GM2D02.Point(
            new GM2D02.ColMatrix(osiWidth-1,osiHeight-1));
    GM2D02.Point lowerLeftPoint = new GM2D02.Point(
                   new GM2D02.ColMatrix(1.0,osiHeight-1));
    
    //Now define the four lines based on the end points..
    GM2D02.Line top = new GM2D02.Line(upperLeftPoint,
                                      upperRightPoint);
    GM2D02.Line rightSide = new GM2D02.Line(
                                         upperRightPoint,
                                         lowerRightPoint);
    GM2D02.Line bottom = new GM2D02.Line(lowerLeftPoint,
                                         lowerRightPoint);
    GM2D02.Line leftSide = new GM2D02.Line(upperLeftPoint,
                                          lowerLeftPoint);
    
    //Now draw a visual manifestation of each line
    // on g2Da.
    top.draw(g2Da);
    rightSide.draw(g2Da);
    bottom.draw(g2Da);
    leftSide.draw(g2Da);
    
    //Now draw a visual manifestation of each of the same
    // four lines on g2Db
    top.draw(g2Db);
    rightSide.draw(g2Db);
    bottom.draw(g2Db);
    leftSide.draw(g2Db);
    
    //Translate the origin of g2Da to the center of the
    // off-screen image.
    g2Da.translate(osiWidth/2.0,osiHeight/2.0);
    
    //Define a point at the new origin and draw a visual
    // manifestation of the point.
    GM2D02.Point origin = new GM2D02.Point(
                           new GM2D02.ColMatrix(0.0,0.0));
    origin.draw(g2Da);
    
    //Define six points that define the vertices of a
    // hexagon that is symmetrically located relative to
    // the origin.  Begin at the right and move clockwise
    // around the origin.
    //First define three constants to make it easier to
    // write the code.
    final double aVal = osiWidth/4.0*0.5;
    final double bVal = osiWidth/4.0*0.866;
    final double cVal = osiWidth/4.0;
    //Now define the points.
    GM2D02.Point point0 = new GM2D02.Point(
                          new GM2D02.ColMatrix(cVal,0.0));
    GM2D02.Point point1 = new GM2D02.Point(
                         new GM2D02.ColMatrix(aVal,bVal));
    GM2D02.Point point2 = new GM2D02.Point(
                        new GM2D02.ColMatrix(-aVal,bVal));
    GM2D02.Point point3 = new GM2D02.Point(
                         new GM2D02.ColMatrix(-cVal,0.0));
    GM2D02.Point point4 = new GM2D02.Point(
                       new GM2D02.ColMatrix(-aVal,-bVal));
    GM2D02.Point point5 = new GM2D02.Point(
                        new GM2D02.ColMatrix(aVal,-bVal));
    
    //Now draw a visual manifestation of each of the six
    // points on g2Da.
    point0.draw(g2Da);
    point1.draw(g2Da);
    point2.draw(g2Da);
    point3.draw(g2Da);
    point4.draw(g2Da);
    point5.draw(g2Da);
    
    //Now define six lines using the six points taken in
    // pairs to define the end points of the lines.
    GM2D02.Line line01 = new GM2D02.Line(point0,point1);
    GM2D02.Line line12 = new GM2D02.Line(point1,point2);
    GM2D02.Line line23 = new GM2D02.Line(point2,point3);
    GM2D02.Line line34 = new GM2D02.Line(point3,point4);
    GM2D02.Line line45 = new GM2D02.Line(point4,point5);
    GM2D02.Line line50 = new GM2D02.Line(point5,point0);

    //Now draw a visual manifestation of each line
    // on g2Da.
    line01.draw(g2Da);
    line12.draw(g2Da);
    line23.draw(g2Da);
    line34.draw(g2Da);
    line45.draw(g2Da);
    line50.draw(g2Da);

    
    //Now define three vectors and draw visual
    // manifestations of the vectors on g2Db.
    GM2D02.Vector vecA = new GM2D02.Vector(
                            new GM2D02.ColMatrix(50,100));
    GM2D02.Vector vecB = new GM2D02.Vector(
                             new GM2D02.ColMatrix(75,25));
    GM2D02.Vector vecC = new GM2D02.Vector(
                           new GM2D02.ColMatrix(125,125));
    
    //Draw vecA in red with its tail at the origin, which
    // is still at the upper-left corner of the g2Db
    // off-screen image
    g2Db.setColor(Color.RED);
    vecA.draw(g2Db,new GM2D02.Point(
                              new GM2D02.ColMatrix(0,0)));
    
    //Draw three visual manifestations of vecB.  Cause
    // the tail of vecB to coincide with the head of vecA
    // in one of the three visual manifestations. Make all
    // three of them green.
    g2Db.setColor(Color.GREEN);
    vecB.draw(g2Db,new GM2D02.Point(new GM2D02.ColMatrix(
                       vecA.getData(0),vecA.getData(1))));
    vecB.draw(g2Db,new GM2D02.Point(new GM2D02.ColMatrix(
                 vecA.getData(0)-10,vecA.getData(1)+15)));
    vecB.draw(g2Db,new GM2D02.Point(new GM2D02.ColMatrix(
                 vecA.getData(0)+10,vecA.getData(1)-60)));

    //Draw vecC in blue with its tail at the origin.
    g2Db.setColor(Color.BLUE);
    vecC.draw(g2Db,new GM2D02.Point(
                              new GM2D02.ColMatrix(0,0)));

  }//end drawOffScreen
  //====================================================//
  
  
  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    //The purpose of this method is to display the two
    // off-screen images on the screen in a side-by-side
    // format.
    public void paint(Graphics g){
      g.drawImage(osiA,0,0,this);
      g.drawImage(osiB,this.getWidth()/2,0,this);
    }//end overridden paint()
    
  }//end inner class MyCanvas
    
}//end class GUI
//======================================================//
