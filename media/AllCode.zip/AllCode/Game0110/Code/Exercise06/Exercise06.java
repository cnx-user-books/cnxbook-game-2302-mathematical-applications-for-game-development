//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/03/08
//======================================================//

/*Exercise06.java
Copyright 2012, R.G.Baldwin

Using Java and the game-math library named GM2D02, or 
using a different programming environment of your choice,
write a program that draws 24 vectors tail-to-head in 
alternating colors of red, green, and blue as shown in 
Figure 8.
The first vector is red. 
The length of each vector is approximately 17 pixels. 
Draw the symbol of your choice to identify the head of 
each vector. 
Draw the axes for a Cartesian coordinate system in the 
reference frame. 
Cause the positive x direction to be to the right. 
Cause the positive y direction be either up or down 
according to your choice. 
Cause positive angles to be either clockwise or 
counter-clockwise according to your choice. 
Cause the program to display your name in some manner.

Tested using JDK 1.7 under WinXP and Windows 7
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.lang.Math;
import java.util.*;

class Exercise06{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class Exercise06
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 300;
  int vSize = 300;
  Image osi;//off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas

  GUI(){//constructor

    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Ex06, Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setBackground(Color.WHITE);

    //Create a new drawing canvas and add it to the
    // center of the JFrame.
    myCanvas = new MyCanvas();
    this.getContentPane().add(myCanvas);

    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();

    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    Graphics2D g2D = (Graphics2D)(osi.getGraphics());

    //Translate the origin to the center of the
    // off-screen image.
    g2D.translate(osiWidth/2.0,osiHeight/2.0);

    //Draw the axes
    drawAxes(g2D);

    //Draw some vectors on the off-screen image.
    drawVectors(g2D);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();

  }//end constructor
  //----------------------------------------------------//

  //The purpose of this method is to define vectors and
  // to cause a visual manifestation of each vector to be
  // drawn onto the off-screen image.
  void drawVectors(Graphics2D g2D){

    //Accumulate the x and y displacement values as each
    // each vector is drawn.
    double sumX = 0;
    double sumY = 0;

    //Used to specify the location of the tail when a
    // vector is drawn.
    GM2D02.Point tailSpot =
        new GM2D02.Point(new GM2D02.ColMatrix(sumX,sumY));

    //This starting angle will cause the circle of
    // vectors to be in the two right-hand quadrants.
    double angle = -97.5;//starting angle in degrees
    Color[] colors = {Color.RED,Color.GREEN,Color.BLUE};

    //The properties of this vector object will be
    // modified using calls to the set method to reflect
    // 24 different directions with a constant length.
    // It will be drawn with its tail at the tailSpot each
    // time it is modified.
    GM2D02.Vector vec =
             new GM2D02.Vector(new GM2D02.ColMatrix(0,0));

    //Set the line thickness
    g2D.setStroke(new BasicStroke(3));

    //Draw the 24 vectors.
    for(int cnt = 0;cnt < 24;cnt++){

      //Set new x and y values for the GM2D02.Vector
      // object. Increase the angle by 15 degrees during\
      // each iteration of the for loop.
      vec.setData(
               0,17*Math.cos(Math.toRadians(angle+=15)));
      vec.setData(1,17*Math.sin(Math.toRadians(angle)));

      //Draw the vector at tailSpot in a different color.
      g2D.setColor(colors[(cnt)%3]);
      vec.draw(g2D,tailSpot);

      //Update tailSpot to the location of the head of
      // the current vector. Will be used to position
      // the vector during the next iteration.
      sumX += vec.getData(0);
      sumY += vec.getData(1);
      tailSpot = new GM2D02.Point(
                         new GM2D02.ColMatrix(sumX,sumY));
    }//end for loop

  }//end drawVectors
  //----------------------------------------------------//

  //The purpose of this method is to draw a pair of
  // Cartesian coordinate axes onto the
  // off-screen image.
  void drawAxes(Graphics2D g2Da){

    //Define four points at the edges of the coordinate
    // frame and the ends of the axes.
    GM2D02.Point point0 = new GM2D02.Point(
                     new GM2D02.ColMatrix(-osiWidth/2,0));
    GM2D02.Point point1 = new GM2D02.Point(
                      new GM2D02.ColMatrix(osiWidth/2,0));
    GM2D02.Point point2 = new GM2D02.Point(
                    new GM2D02.ColMatrix(0,-osiHeight/2));
    GM2D02.Point point3 = new GM2D02.Point(
                     new GM2D02.ColMatrix(0,osiHeight/2));

    //Now define the two lines based on the end points..
    GM2D02.Line xAxis = new GM2D02.Line(point0,point1);
    GM2D02.Line yAxis = new GM2D02.Line(point2,point3);

    //Now draw a visual manifestation of each line
    // on g2Da.
    xAxis.draw(g2Da);
    yAxis.draw(g2Da);

  }//end drawAxes
  //====================================================//

  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()

  }//end inner class MyCanvas

}//end class GUI
//======================================================//
