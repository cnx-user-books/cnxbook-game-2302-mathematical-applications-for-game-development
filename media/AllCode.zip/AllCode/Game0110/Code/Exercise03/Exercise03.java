//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/03/08
//======================================================//

/*Exercise03.java
Copyright 2012, R.G.Baldwin

Using Java and the game-math library named GM2D02, or 
using a different programming environment of your choice,
write a program that draws x and y axes in a 2D Cartesian
coordinate system as shown in Figure 4.

Cause the origin of your reference frame be at the center
of your drawing. 

Cause the positive x direction be to the right. 

Cause the positive y direction be either up or down 
according to your choice. 

Create six random values in the range from -128 to +127. 
Use those values as the x and y coordinates for three 
points in the 2D reference frame. (The code fragment in 
Listing 29 shows how to generate random values in the 
required range in Java.)

Display the six values on a text screen labeled in such 
a way that it is possible to associate the values with 
the points as shown in Figure 5. 

Draw three small circles that represent the locations of 
the points. 

Draw three line segments that connect the three points 
in pairs creating the shape of a triangle.
 
Cause the program to display your name in some manner.

Tested using JDK 1.7 under WinXP and Windows 7
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.lang.Math;
import java.util.*;

class Exercise03{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class Exercise03
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 300;
  int vSize = 300;
  Image osi;//off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas

  //Coordinates of three points
  int point0X;
  int point0Y;
  int point1X;
  int point1Y;
  int point2X;
  int point2Y;

  //Declare three Point variables
  GM2D02.Point point0 = null;
  GM2D02.Point point1 = null;
  GM2D02.Point point2 = null;

  GUI(){//constructor
    //Define three randomly located points.
    Random generator = new Random(new Date().getTime());
    point0X = (byte)generator.nextInt();
    point0Y = (byte)generator.nextInt();
    point1X = (byte)generator.nextInt();
    point1Y = (byte)generator.nextInt();
    point2X = (byte)generator.nextInt();
    point2Y = (byte)generator.nextInt();
    
    //Display the coordinates of the points.
    System.out.println("point0X: " + point0X);
    System.out.println("point0Y: " + point0Y);
    System.out.println("point1X: " + point1X);
    System.out.println("point1Y: " + point1Y);
    System.out.println("point2X: " + point2X);
    System.out.println("point2Y: " + point2Y);
  
    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Ex03, Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //Create a new drawing canvas and add it to the
    // center of the JFrame.
    myCanvas = new MyCanvas();
    this.getContentPane().add(myCanvas);

    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();

    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    Graphics2D g2D = (Graphics2D)(osi.getGraphics());

    //Translate the origin to the center of the
    // off-screen image.
    g2D.translate(osiWidth/2.0,osiHeight/2.0);
    
    //Draw the axes
    drawAxes(g2D);

    //Draw some points on the off-screen image.
    drawThreePoints(g2D);

    //Draw lines that connect the points.
    drawLines(g2D);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();

  }//end constructor
  //----------------------------------------------------//

  //The purpose of this method is to define points and
  // cause a visual manifestation of each point to be
  // drawn onto the off-screen image.
  void drawThreePoints(Graphics2D g2D){

    //Define three points.
    point0 = new GM2D02.Point(
                   new GM2D02.ColMatrix(point0X,point0Y));
    point1 = new GM2D02.Point(
                   new GM2D02.ColMatrix(point1X,point1Y));
    point2 = new GM2D02.Point(
                   new GM2D02.ColMatrix(point2X,point2Y));

    //Now draw a visual manifestation of each of the
    // points on g2D.
    point0.draw(g2D);
    point1.draw(g2D);
    point2.draw(g2D);

  }//end drawThreePoints
  //----------------------------------------------------//

  //The purpose of this method is to draw three lines that
  // connect the points in pairs.
  void drawLines(Graphics2D g2D){

    GM2D02.Line lineA = new GM2D02.Line(point0,point1);
    lineA.draw(g2D);

    GM2D02.Line lineB = new GM2D02.Line(point1,point2);
    lineB.draw(g2D);

    GM2D02.Line lineC = new GM2D02.Line(point2,point0);
    lineC.draw(g2D);
  }//end drawLines
  //====================================================//

  //The purpose of this method is to draw a pair of
  // Cartesian coordinate axes onto the
  // off-screen image.
  void drawAxes(Graphics2D g2Da){

    //Define four points at the edges of the coordinate
    // frame and the ends of the axes.
    GM2D02.Point point0 = new GM2D02.Point(
                     new GM2D02.ColMatrix(-osiWidth/2,0));
    GM2D02.Point point1 = new GM2D02.Point(
                      new GM2D02.ColMatrix(osiWidth/2,0));
    GM2D02.Point point2 = new GM2D02.Point(
                    new GM2D02.ColMatrix(0,-osiHeight/2));
    GM2D02.Point point3 = new GM2D02.Point(
                     new GM2D02.ColMatrix(0,osiHeight/2));

    //Now define the two lines based on the end points..
    GM2D02.Line xAxis = new GM2D02.Line(point0,point1);
    GM2D02.Line yAxis = new GM2D02.Line(point2,point3);
    
    //Now draw a visual manifestation of each line
    // on g2Da.
    xAxis.draw(g2Da);
    yAxis.draw(g2Da);

  }//end drawAxes
  //====================================================//

  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()

  }//end inner class MyCanvas

}//end class GUI
//======================================================//
