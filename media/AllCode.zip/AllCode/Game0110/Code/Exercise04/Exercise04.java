//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/03/08
//======================================================//

/*Exercise04.java
Copyright 2012, R.G.Baldwin
Using Java and the game-math library named GM2D02, or 
using a different programming environment of your choice,
write a program that draws three small circles that 
represent the locations of points at the following 
coordinates in a 2D reference frame.
 
point0X = -30 
point0Y = 0 
point1X = 30 
point1Y = 40 
point2X = 30 
point2Y = -40 

Then draw three line segments that extend from 
edge-to-edge of your drawing and intersect the three 
points in pairs as shown in Figure 6. 

Cause the origin of your reference frame be at the center
of your drawing. 

Cause the positive x direction to be to the right. 

Cause the positive y direction be either up or down 
according to your choice. 

Cause the program to display your name in some manner.

Tested using JDK 1.7 under WinXP and Windows 7
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.lang.Math;

class Exercise04{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class Exercise04
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 300;
  int vSize = 300;
  Image osi;//off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas

  //Coordinates of three points
  int point0X = -30;
  int point0Y = 0;
  int point1X = 30;
  int point1Y = 40;
  int point2X = 30;
  int point2Y = -40;

  //Declare three Point variables
  GM2D02.Point point0 = null;
  GM2D02.Point point1 = null;
  GM2D02.Point point2 = null;

  GUI(){//constructor
    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Ex04, Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //Create a new drawing canvas and add it to the
    // center of the JFrame.
    myCanvas = new MyCanvas();
    this.getContentPane().add(myCanvas);

    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();

    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    Graphics2D g2D = (Graphics2D)(osi.getGraphics());

    //Translate the origin to the center of the
    // off-screen image.
    g2D.translate(osiWidth/2.0,osiHeight/2.0);

    //Draw some points on the off-screen image.
    drawThreePoints(g2D);

    //Draw lines that intersect the points.
    drawLines(g2D);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();

  }//end constructor
  //----------------------------------------------------//

  //The purpose of this method is to define points and
  // cause a visual manifestation of each point to be
  // drawn onto the off-screen image.
  void drawThreePoints(Graphics2D g2D){

    //Define three points.
    point0 = new GM2D02.Point(
                   new GM2D02.ColMatrix(point0X,point0Y));
    point1 = new GM2D02.Point(
                   new GM2D02.ColMatrix(point1X,point1Y));
    point2 = new GM2D02.Point(
                   new GM2D02.ColMatrix(point2X,point2Y));

    //Now draw a visual manifestation of each of the
    // points on g2D.
    point0.draw(g2D);
    point1.draw(g2D);
    point2.draw(g2D);

  }//end drawThreePoints
  //----------------------------------------------------//

  //The purpose of this method is to draw three lines that
  // intersect the three points in pairs and extend to
  // the edge of the drawing.
  void drawLines(Graphics2D g2D){

    GM2D02.Point[] ptsA = getIntercepts(point0,point1);
    GM2D02.Line lineA = new GM2D02.Line(ptsA[0],ptsA[1]);
    lineA.draw(g2D);

    GM2D02.Point[] ptsB = getIntercepts(point1,point2);
    GM2D02.Line lineB = new GM2D02.Line(ptsB[0],ptsB[1]);
    lineB.draw(g2D);

    GM2D02.Point[] ptsC = getIntercepts(point2,point0);
    GM2D02.Line lineC = new GM2D02.Line(ptsC[0],ptsC[1]);
    lineC.draw(g2D);
  }//end drawLines
  //====================================================//

  //This method implements the equation of a straight line
  // y = m*x + b
  // to find and return the points where a straight line
  // that intersects two points also intersects the edges
  // of a drawing of size osiWidth by osiHeight. The
  // method assumes that the origin is at the center of
  // the drawing.
  GM2D02.Point[] getIntercepts(GM2D02.Point pointM,
                               GM2D02.Point pointN){

    int x0 = 0;
    int y0 = 0;
    int x1 = 0;
    int y1 = 0;

    //Compute the slope of the line that intersects the
    // two points.
    double xLen = pointN.getData(0)-pointM.getData(0);
    //Avoid division by zero
    if(Math.abs(xLen) < 0.00000001){
      xLen = 0.00000001;
    }//end if

    double yLen = pointN.getData(1)-pointM.getData(1);
    double slope = yLen/xLen;

    //Get the y-intercept using y=m*x+b
    double yIntercept =
            pointN.getData(1) - slope * pointN.getData(0);

    //Determine if the line intersects the left vertical
    // border
    y0 = (int)(slope * (-osiWidth/2) + yIntercept);
    if( (y0 > -osiHeight/2) && (y0 < osiHeight/2)){
      //The line does intersect the left vertical border.
      x0 = -osiWidth/2;
    }else if((y0 > osiHeight/2)){
      //The line intersects the positive horizontal border
      y0 = osiHeight/2;
      x0 = (int)((y0 - yIntercept)/slope);
    }else{
      //The line intersects the negative horizontal border
      y0 = -osiHeight/2;
      x0 = (int)((y0 - yIntercept)/slope);
    }//end else

    //Determine if the line intersects with the right
    // vertical border.
    y1 = (int)(slope * (osiWidth/2) + yIntercept);
    if( (y1 > -osiHeight/2) && (y1 < osiHeight/2)){
      //The line does intersect the right vertical border.
      x1 = osiWidth/2;
    }else if((y1 > osiHeight/2)){
      //The line intersects the positive horizontal border
      y1 = osiHeight/2;
      x1 = (int)((y1 - yIntercept)/slope);
    }else{
      //The line intersects the negative horizontal border
      y1 = -osiHeight/2;
      x1 = (int)((y1 - yIntercept)/slope);
    }//end else

    //Populate a two-element array with the two points
    // for return to the calling method.
    GM2D02.Point[] returnVal = {
           new GM2D02.Point(new GM2D02.ColMatrix(x0,y0)),
           new GM2D02.Point(new GM2D02.ColMatrix(x1,y1))
           };
    return returnVal;

  }//end getIntercepts

  //====================================================//

  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()

  }//end inner class MyCanvas

}//end class GUI
//======================================================//
