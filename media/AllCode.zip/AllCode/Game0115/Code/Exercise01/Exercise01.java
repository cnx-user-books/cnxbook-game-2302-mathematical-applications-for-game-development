//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/03/08
//======================================================//

/*Exercise01.java 
Copyright 2012, R.G.Baldwin

Using Java and the game-math library named GM2D03, or 
using a different programming environment of your choice, 
write a program that creates four column matrix objects 
using the following names and values:

matA = (1.5,-2.6)
matB = (1.5,-2.6)
matC = (8.5,-13.4)
matD = (5.5,-8.2)

Then use matrix addition and subtraction to compute and 
display the values of the following matrices:

matE = matA + matB
matF = matC - matD

Finally, test matE and matF for equality and display the 
result.

Cause the program to display your name in some manner.

My version of the program produces the text output shown in Figure 4.

Tested using JDK 1.6 under WinXP.
*********************************************************/

public class Exercise01{
  public static void main(String[] args){
    System.out.println("Prof. Baldwin");
    //Create two column matrices, add them and display the
    // sum.
    GM2D03.ColMatrix matA = 
                           new GM2D03.ColMatrix(1.5,-2.6);
    GM2D03.ColMatrix matB = 
                           new GM2D03.ColMatrix(1.5,-2.6);
    GM2D03.ColMatrix matE = matA.add(matB);
    System.out.println("matE = " + matE);
    
    //Create two column matrices, subtract the second
    // from the first, and display the difference.
    GM2D03.ColMatrix matC = 
                          new GM2D03.ColMatrix(8.5,-13.4);
    GM2D03.ColMatrix matD = 
                           new GM2D03.ColMatrix(5.5,-8.2);
    GM2D03.ColMatrix matF = matC.subtract(matD);
    System.out.println("matF = " + matF);
    
    //Test the resulting sum and difference matrices for
    // equality and display the result.
    System.out.println(
                 "matE equals matF: " +matE.equals(matF));

  }//end main
}//end Exercise01 class