//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/03/08
//======================================================//

/*Exercise02.java 
Copyright 2008, R.G.Baldwin
Revised 02/08/08

The purpose of this program is to confirm the behavior of
the equals methodS of the GM2D03.ColMatrix, Point, and
Vector classes.

Cause the program to display your name in some manner.

Tested using JDK 1.6 under WinXP.
*********************************************************/

public class Exercise02{
  public static void main(String[] args){
    System.out.println("Prof. Baldwin");
    
    //Create three column matrices.
    GM2D03.ColMatrix matA = 
                           new GM2D03.ColMatrix(-1.5,2.6);
    GM2D03.ColMatrix matB = 
                           new GM2D03.ColMatrix(-1.5,2.6);
    GM2D03.ColMatrix matC = 
                          new GM2D03.ColMatrix(8.5,-13.4);
                          
    //Use the three column matrices to create three
    // vectors.
    GM2D03.Vector vecA = new GM2D03.Vector(matA);
    GM2D03.Vector vecB = new GM2D03.Vector(matB);
    GM2D03.Vector vecC = new GM2D03.Vector(matC);
    
    //Display the three vectors.
    System.out.println("vecA = " + vecA);
    System.out.println("vecB = " + vecB);
    System.out.println("vecC = " + vecC);
    
    //Test vecA for equality against vecB and then vecC
    // and display the results.
    System.out.println(
                 "vecA equals vecB: " +vecA.equals(vecB));
    System.out.println(
                 "vecA equals vecC: " +vecA.equals(vecC));

  }//end main
}//end Exercise02 class