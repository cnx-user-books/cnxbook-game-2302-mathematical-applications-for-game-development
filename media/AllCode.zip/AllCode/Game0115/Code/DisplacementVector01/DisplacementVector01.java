//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/03/08
//======================================================//

/*DisplacementVector01.java 
Copyright 2008, R.G.Baldwin
Revised 02/08/08

The purpose of this program is to confirm the behavior of
the getDisplacementVector method of the GM2D03.Point
class.

Because that method calls the subtract method of the
GM2D03.ColMatrix class, this program also confirms the
behavior of that method.

Tested using JDK 1.6 under WinXP.
*********************************************************/

public class DisplacementVector01{
  public static void main(String[] args){
    GM2D03.Point pointA = new GM2D03.Point(
                          new GM2D03.ColMatrix(6.5,-9.7));
    GM2D03.Point pointB = new GM2D03.Point(
                          new GM2D03.ColMatrix(-6.0,9.0));
    
    System.out.println(pointA.getDisplacementVector(
                                                 pointB));
    System.out.println(pointB.getDisplacementVector(
                                                 pointA));

  }//end main
}//end DisplacementVector01 class