//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/03/08
//======================================================//

/*ColMatrixEquals01.java 
Copyright 2008, R.G.Baldwin
Revised 02/08/08

The purpose of this program is to confirm the behavior of
the equals methodS of the GM2D03.ColMatrix, Point, and
Vector classes.

Tested using JDK 1.6 under WinXP.
*********************************************************/

public class ColMatrixEquals01{
  public static void main(String[] args){
    GM2D03.ColMatrix matA = 
                           new GM2D03.ColMatrix(1.5,-2.6);
    GM2D03.ColMatrix matB = 
                           new GM2D03.ColMatrix(1.5,-2.6);
    GM2D03.ColMatrix matC = 
                 new GM2D03.ColMatrix(1.500001,-2.600001);
    GM2D03.ColMatrix matD = 
                   new GM2D03.ColMatrix(1.50001,-2.60001);
    System.out.println(matA.equals(matA));
    System.out.println(matA.equals(matB));
    System.out.println(matA.equals(matC));
    System.out.println(matA.equals(matD));
    
    GM2D03.Point pointA = new GM2D03.Point(
                       new GM2D03.ColMatrix(15.6,-10.11));
    GM2D03.Point pointB = new GM2D03.Point(
                       new GM2D03.ColMatrix(15.6,-10.11));
    GM2D03.Point pointC = new GM2D03.Point(
                       new GM2D03.ColMatrix(-15.6,10.11));
    System.out.println(/*Blank line*/);
    System.out.println(pointA.equals(pointA));
    System.out.println(pointA.equals(pointB));
    System.out.println(pointA.equals(pointC));
    
    GM2D03.Vector vecA = new GM2D03.Vector(
                       new GM2D03.ColMatrix(15.6,-10.11));
    GM2D03.Vector vecB = new GM2D03.Vector(
                       new GM2D03.ColMatrix(15.6,-10.11));
    GM2D03.Vector vecC = new GM2D03.Vector(
                       new GM2D03.ColMatrix(-15.6,10.11));
    System.out.println(/*Blank line*/);
    System.out.println(vecA.equals(vecA));
    System.out.println(vecA.equals(vecB));
    System.out.println(vecA.equals(vecC));

  }//end main
}//end ColMatrixEquals01 class