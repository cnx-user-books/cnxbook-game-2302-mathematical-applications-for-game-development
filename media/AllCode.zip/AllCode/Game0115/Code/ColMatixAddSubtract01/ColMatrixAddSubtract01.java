//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/03/08
//======================================================//

/*ColMatrixAddSubtract01.java 
Copyright 2008, R.G.Baldwin
Revised 02/08/08

The purpose of this program is to confirm the behavior of
the add and subtract methods of the GM2D03.ColMatrix 
class.

Tested using JDK 1.6 under WinXP.
*********************************************************/

public class ColMatrixAddSubtract01{
  public static void main(String[] args){
  
    GM2D03.ColMatrix matrixA = 
                         new GM2D03.ColMatrix(3.14,-6.01);
    GM2D03.ColMatrix matrixB = 
                        new GM2D03.ColMatrix(-14.0,-12.2);
    
    GM2D03.ColMatrix matrixC = matrixA.add(matrixB);
    GM2D03.ColMatrix matrixD = matrixC.subtract(matrixA);
    GM2D03.ColMatrix matrixE = matrixD.subtract(matrixB);
    
    System.out.println(matrixC);
    System.out.println(matrixD);
    System.out.println(matrixE);
  }//end main

}//end class ColMatrixAddSubtract01