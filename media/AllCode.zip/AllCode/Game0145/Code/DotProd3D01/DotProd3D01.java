//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 03/04/08
//======================================================//

/*DotProd3D01.java 
Copyright 2008, R.G.Baldwin
Revised 03/04/08

Study Kjell through Chapter 8 - Length, Orthogonality, and
the Column Matrix Dot product.

The purpose of this program is to confirm proper operation
of the ColMatrix3D.dot method.

The program creates a GUI that allows the usr to enter
three values for each of a pair of ColMatrix3D objects 
along with a button labeled OK.

When the user clicks the OK button, the dot product
between the two ColMatrix3D objects is computed. The
resulting value is converted to four decimal digits and
displayed in a text field on the GUI.

Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class DotProd3D01{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class DotProd3D01
//======================================================//

class GUI extends JFrame implements ActionListener{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 470;
  int vSize = 150;

  JTextField colMatA0 = new JTextField("0.57735");
  JTextField colMatA1 = new JTextField("0.57735");
  JTextField colMatA2 = new JTextField("0.57735");
  
  JTextField colMatB0 = new JTextField("-0.57735");
  JTextField colMatB1 = new JTextField("-0.57735");
  JTextField colMatB2 = new JTextField("-0.57735");
  
  JTextField dotProduct = new JTextField();
  JButton button = new JButton("OK");

  //----------------------------------------------------//
  
  GUI(){//constructor

    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Copyright 2008,R.G.Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    

    //Instantiate a JPanel that will house the user input
    // components and set its layout manager.
    JPanel controlPanel = new JPanel();
    controlPanel.setLayout(new GridLayout(0,6));

    //Add the user input components and appropriate labels
    // to the control panel.
    controlPanel.add(new JLabel(" colMatA0 = "));    
    controlPanel.add(colMatA0);

    controlPanel.add(new JLabel(" colMatA1 = "));    
    controlPanel.add(colMatA1);
    
    controlPanel.add(new JLabel(" colMatA2 = "));    
    controlPanel.add(colMatA2);
    
    controlPanel.add(new JLabel(" colMatB0 = "));    
    controlPanel.add(colMatB0);
    
    controlPanel.add(new JLabel(" colMatB1 = "));    
    controlPanel.add(colMatB1);
    
    controlPanel.add(new JLabel(" colMatB2 = "));    
    controlPanel.add(colMatB2);
    
    controlPanel.add(new JLabel(" Dot Prod = "));
    controlPanel.add(dotProduct);

    controlPanel.add(new JLabel(""));//spacer
    controlPanel.add(button);

    //Add the control panel to the CENTER position in the
    // JFrame.
    this.getContentPane().add(
                        BorderLayout.CENTER,controlPanel);
    setVisible(true);

    //Register this object as an action listener on the
    // button.
    button.addActionListener(this);

  }//end constructor
  //----------------------------------------------------//

  //This method is called to respond to a click on the
  // button.
  public void actionPerformed(ActionEvent e){
    //Create two ColMatrix3D objects.
    GM02.ColMatrix3D matrixA = new GM02.ColMatrix3D(
      Double.parseDouble(colMatA0.getText()),
      Double.parseDouble(colMatA1.getText()),
      Double.parseDouble(colMatA2.getText()));
      
    GM02.ColMatrix3D matrixB = new GM02.ColMatrix3D(
      Double.parseDouble(colMatB0.getText()),
      Double.parseDouble(colMatB1.getText()),
      Double.parseDouble(colMatB2.getText()));
      
    //Compute the dot product.
    double dotProd = matrixA.dot(matrixB);

    //Eliminate exponential notation in the display.
    if(Math.abs(dotProd) < 0.001){
      dotProd = 0.0;
    }//end if

    //Convert to four decimal digits and display.
    dotProd =((int)(10000*dotProd))/10000.0;
    dotProduct.setText("" +  dotProd);

  }//end actionPerformed
  //====================================================//

}//end class GUI
//======================================================//
