//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 03/07/08
//======================================================//

/*Exercise02.java 
Copyright 2012, R.G.Baldwin

This code is based on DotProd3D02

Using Java and the game-math library named GM02, or 
using a different programming environment of your choice, 
write a program that behaves as follows.

When the program starts running, an image similar to 
Figure 18 appears on the screen. Each of the text fields 
is blank and the drawing area at the top is also blank.

Each time you click the Plot button, the program generates
five random values in the general range of -128 to 127. 
The first three values are used as the x, y, and z values 
for a vector. The three values are displayed in the fields
labeled VecAx, VecAy, and VecAz. Also, the three values 
are used to create and draw a black vector with its tail 
at the origin as shown in Figure 18.

The fourth and fifth random values are used as the x and y
values for a second vector. They are displayed in the 
fields labeled VecBx and VecBy. A z-value is computed that
will cause that vector to be perpendicular to the black 
vector. That value is displayed in the field labeled 
VecBz and the three values are used to draw the magenta 
vector shown in Figure 18.

The dot product between the two vectors is computed and 
displayed in the field labeled Dot Prod. The angle between
the two vectors is computed and displayed in the field 
labeled Angle (deg). Obviously, if the two vectors are 
perpendicular, that value should be very close to 90 
degrees.

Cause your name to appear in the screen output in some 
manner.

Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;

class Exercise02{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class Exercise02
//======================================================//

class GUI extends JFrame implements ActionListener{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 400;
  int vSize = 400;
  Image osi;//an off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas 
  Graphics2D g2D;//off-screen graphics context.

  //User input components.
  JTextField vecAx = new JTextField("");
  JTextField vecAy = new JTextField("");
  JTextField vecAz = new JTextField("");
  JTextField vecBx = new JTextField("");
  JTextField vecBy = new JTextField("");
  JTextField vecBz = new JTextField("");
  JTextField dotProduct = new JTextField();
  JTextField angleDisplay = new JTextField();
  JButton button = new JButton("Plot");
  
  //----------------------------------------------------//
  
  GUI(){//constructor

    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Ex02,Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    //Instantiate a JPanel that will house the user input
    // components and set its layout manager.
    JPanel controlPanel = new JPanel();
    controlPanel.setLayout(new GridLayout(0,6));
    
    //Make the text fields non-editable
    vecAx.setEditable(false);
    vecAy.setEditable(false);
    vecAz.setEditable(false);
    vecBx.setEditable(false);
    vecBy.setEditable(false);
    vecBz.setEditable(false);
    dotProduct.setEditable(false);
    angleDisplay.setEditable(false);

    //Add the user input components and appropriate labels
    // to the control panel.
    controlPanel.add(new JLabel(" VecAx = "));    
    controlPanel.add(vecAx);

    controlPanel.add(new JLabel(" VecAy = "));    
    controlPanel.add(vecAy);
    
    controlPanel.add(new JLabel(" VecAz = "));    
    controlPanel.add(vecAz);
    
    controlPanel.add(new JLabel(" VecBx = "));    
    controlPanel.add(vecBx);
    
    controlPanel.add(new JLabel(" VecrBy = "));    
    controlPanel.add(vecBy);
    
    controlPanel.add(new JLabel(" VecBz = "));    
    controlPanel.add(vecBz);
    
    controlPanel.add(new JLabel(" Dot Prod = "));
    controlPanel.add(dotProduct);
    
    controlPanel.add(new JLabel(" Ang(deg)"));
    controlPanel.add(angleDisplay);
    
    controlPanel.add(new JLabel(""));//spacer

    controlPanel.add(button);

    //Add the control panel to the SOUTH position in the
    // JFrame.
    this.getContentPane().add(
                        BorderLayout.SOUTH,controlPanel);

    
    //Create a new drawing canvas and add it to the
    // CENTER of the JFrame above the control panel.
    myCanvas = new MyCanvas();
    this.getContentPane().add(
                            BorderLayout.CENTER,myCanvas);

    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    
    //Make the size of the off-screen image match the
    // size of the canvas.
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();
    
    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    g2D = (Graphics2D)(osi.getGraphics());
    

    //Translate the origin to the center.
    GM02.translate(g2D,0.5*osiWidth,-0.5*osiHeight);

    
    //Register this object as an action listener on the
    // button.
    button.addActionListener(this);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();
    
  }//end constructor
  //----------------------------------------------------//
  
  //This method is used to draw orthogonal 3D axes on the
  // off-screen image that intersect at the origin.
  private void setCoordinateFrame(Graphics2D g2D){

    //Erase the screen
    g2D.setColor(Color.WHITE);
    GM02.fillRect(g2D,-osiWidth/2,osiHeight/2,
                                      osiWidth,osiHeight);

    //Draw x-axis in RED
    g2D.setColor(Color.RED);
    GM02.Point3D pointA = new GM02.Point3D(
                   new GM02.ColMatrix3D(-osiWidth/2,0,0));
    GM02.Point3D pointB = new GM02.Point3D(
                    new GM02.ColMatrix3D(osiWidth/2,0,0));
    new GM02.Line3D(pointA,pointB).draw(g2D);
    
    //Draw y-axis in GREEN
    g2D.setColor(Color.GREEN);
    pointA = new GM02.Point3D(
                  new GM02.ColMatrix3D(0,-osiHeight/2,0));
    pointB = new GM02.Point3D(
                   new GM02.ColMatrix3D(0,osiHeight/2,0));
    new GM02.Line3D(pointA,pointB).draw(g2D);
    
    //Draw z-axis in BLUE. Make its length the same as the
    // length of the x-axis.
    g2D.setColor(Color.BLUE);
    pointA = new GM02.Point3D(
                   new GM02.ColMatrix3D(0,0,-osiWidth/2));
    pointB = new GM02.Point3D(
                    new GM02.ColMatrix3D(0,0,osiWidth/2));
    new GM02.Line3D(pointA,pointB).draw(g2D);

  }//end setCoordinateFrame method
  //----------------------------------------------------//
  
  //This method is called to respond to a click on the
  // button.
  public void actionPerformed(ActionEvent e){
    
    //Erase the off-screen image and draw the axes.
    setCoordinateFrame(g2D);

    Random generator = new Random(new Date().getTime());
    double x1 = (byte)generator.nextInt();
    double y1 = (byte)generator.nextInt();
    double z1 = 0.0;
    
    double x2 = (byte)generator.nextInt();
    double z2 = 0.0;
    //For a perpendicular vector:
    // y2 = -(x1*x2 + z1*z2)/y1
    double y2 = -(x1*x2 + z1*z2)/y1;
    
    vecAx.setText("" + x1);
    vecAy.setText("" + y1);
    vecAz.setText("" + z1);
    
    vecBx.setText("" + x2);
    vecBz.setText("" + z2);
    double y2out = ((int)(100*y2))/100.0;
    vecBy.setText("" + y2out);


    //Create two ColMatrix3D objects based on the user
    // input values.
    GM02.ColMatrix3D matrixA = new GM02.ColMatrix3D(
                  Double.parseDouble(vecAx.getText()),
                  Double.parseDouble(vecAy.getText()),
                  Double.parseDouble(vecAz.getText()));
      
    GM02.ColMatrix3D matrixB = new GM02.ColMatrix3D(
                  Double.parseDouble(vecBx.getText()),
                  Double.parseDouble(vecBy.getText()),
                  Double.parseDouble(vecBz.getText()));
      

    //Use the ColMatrix3D objects to create two Vector3D
    // objects.
    GM02.Vector3D vecA = new GM02.Vector3D(matrixA);
    GM02.Vector3D vecB = new GM02.Vector3D(matrixB);
    
    //Draw the two vectors with their tails at the origin.
    g2D.setColor(Color.BLACK);
    vecA.draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));
    g2D.setColor(Color.MAGENTA);
    vecB.draw(g2D,new GM02.Point3D(
                            new GM02.ColMatrix3D(0,0,0)));

    //Compute the dot product between the two vectors.
    double dotProd = vecA.dot(vecB);
    
    //Eliminate exponential notation in the display.
    if(Math.abs(dotProd) < 0.001){
      dotProd = 0.0;
    }//end if
    
    //Convert to four decimal digits and display.
    dotProd =((int)(10000*dotProd))/10000.0;
    dotProduct.setText("" +  dotProd);


    //Compute the angle between the two vectors.
    double angle = vecA.angle(vecB);
    
    //Eliminate exponential notation in the display.
    if(Math.abs(angle) < 0.001){
      angle = 0.0;
    }//end if
    
    //Convert to four decimal digits and display.
    angle =((int)(10000*angle))/10000.0;
    angleDisplay.setText("" +  angle);

    myCanvas.repaint();//Copy off-screen image to canvas.
  }//end actionPerformed
  //====================================================//
  
  
  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    //The purpose of this method is to display the
    // off-screen image on the screen.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()
    
  }//end inner class MyCanvas
    
}//end class GUI
//======================================================//
