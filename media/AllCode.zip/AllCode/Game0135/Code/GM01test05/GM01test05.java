//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/24/08
//======================================================//

/*GM01test05.java 
Copyright 2008, R.G.Baldwin
Revised 02/24/08

This program illustrates vector addition in 3D.

Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.awt.geom.*;

class GM01test05{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class GM01test05
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 300;
  int vSize = 200;
  Image osi;//an off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas
  
  GUI(){//constructor
    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Copyright 2008,R.G.Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    //Create a new drawing canvas and add it to the
    // center of the JFrame.
    myCanvas = new MyCanvas();
    this.getContentPane().add(myCanvas);
    
    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();

    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    Graphics2D g2D = (Graphics2D)(osi.getGraphics());
    
    //Draw on the off-screen image.
    drawOffScreen(g2D);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();

  }//end constructor
  //----------------------------------------------------//

  //The purpose of this method is to illustrate vector
  // addition in 3D
  void drawOffScreen(Graphics2D g2D){
    
    //Translate the origin on the off-screen image, draw a
    // pair of orthoganal axes on it that intersect at the
    // origin, and paint the background white.
    setCoordinateFrame(g2D);
    
    //Define two vectors that will be added.
    GM01.Vector3D vecA = new GM01.Vector3D(
                         new GM01.ColMatrix3D(75,75,75));
                        
    GM01.Vector3D vecB = new GM01.Vector3D(
                        new GM01.ColMatrix3D(-15,10,-50));
                        
    //Create a ref point at the origin for convenience.
    GM01.Point3D zeroPoint = new GM01.Point3D(
                             new GM01.ColMatrix3D(0,0,0));
                        
    //Draw vecA in MAGENTA with its tail at the origin.
    g2D.setColor(Color.MAGENTA);
    vecA.draw(g2D,zeroPoint);
    
    //Draw vecB in LIGHT_GRAY with its tail at the head
    // of vecA.
    g2D.setColor(Color.LIGHT_GRAY);
    GM01.Point3D temp = 
                    new GM01.Point3D(vecA.getColMatrix());
    vecB.draw(g2D,temp);
    
    //Draw vecB in LIGHT_GRAY with its tail at the origin.
    vecB.draw(g2D,zeroPoint);
    
    //Draw vecA in MAGENTA with its tail at the the head
    // of vecB. This completes a trapezoid.
    g2D.setColor(Color.MAGENTA);
    vecA.draw(g2D,new GM01.Point3D(vecB.getColMatrix()));
    
    //Add the two vectors.
    GM01.Vector3D sum = vecA.add(vecB);
    //Draw sum in BLACK with its tail at the origin.
    g2D.setColor(Color.BLACK);
    sum.draw(g2D,zeroPoint);

  }//end drawOffScreen
  //----------------------------------------------------//

  //This method is used to set the origin of the
  // off-screen image, set the background color to WHITE,
  // and draw orthogonal 3D axes on the off-screen image
  // that intersect at the origin.
  private void setCoordinateFrame(Graphics2D g2D){

    //Translate the origin to the center.
    GM01.translate(g2D,0.5*osiWidth,-0.5*osiHeight);
    
    //Set background color to WHITE.
    g2D.setColor(Color.WHITE);
    GM01.fillRect(
          g2D,-osiWidth/2,osiHeight/2,osiWidth,osiHeight);

    //Draw x-axis in RED
    g2D.setColor(Color.RED);
    GM01.Point3D pointA = 
          new GM01.Point3D(new GM01.ColMatrix3D(-75,0,0));
    GM01.Point3D pointB = 
           new GM01.Point3D(new GM01.ColMatrix3D(75,0,0));
    pointA.draw(g2D);
    pointB.draw(g2D);
    new GM01.Line3D(pointA,pointB).draw(g2D);
    
    //Draw y-axis in GREEN
    g2D.setColor(Color.GREEN);
    pointA = 
          new GM01.Point3D(new GM01.ColMatrix3D(0,-75,0));
    pointB = 
           new GM01.Point3D(new GM01.ColMatrix3D(0,75,0));
    pointA.draw(g2D);
    pointB.draw(g2D);
    new GM01.Line3D(pointA,pointB).draw(g2D);
    
    //Draw z-axis in BLUE
    g2D.setColor(Color.BLUE);
    pointA = 
          new GM01.Point3D(new GM01.ColMatrix3D(0,0,-75));
    pointB = 
           new GM01.Point3D(new GM01.ColMatrix3D(0,0,75));
    pointA.draw(g2D);
    pointB.draw(g2D);
    new GM01.Line3D(pointA,pointB).draw(g2D);

  }//end setCoordinateFrame method
  //====================================================//
  
  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    //The purpose of this method is to display the
    // off-screen image on the screen.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()
    
  }//end inner class MyCanvas
    
}//end class GUI
//======================================================//
