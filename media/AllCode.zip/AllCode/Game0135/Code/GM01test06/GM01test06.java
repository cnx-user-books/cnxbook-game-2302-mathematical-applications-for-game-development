//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/24/08
//======================================================//

/*GM01test06.java 
Copyright 2008, R.G.Baldwin
Revised 02/24/08

This program is an update of the program named GM01test01.
The purpose is to illustrate scaling a geometric object
by calling the method named GM01.Point3D.scale for each
point that makes up the object.

Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.awt.geom.*;

class GM01test06{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class GM01test06
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 400;
  int vSize = 400;
  Image osi;//an off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas
  
  GUI(){//constructor
    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Copyright 2008,R.G.Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    //Create a new drawing canvas and add it to the
    // center of the JFrame.
    myCanvas = new MyCanvas();
    this.getContentPane().add(myCanvas);
    
    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();

    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    Graphics2D g2D = (Graphics2D)(osi.getGraphics());
    
    //Test many 3D library features using text.
    testUsingText();
    
    //Test many 3D library features using graphics.
    drawOffScreen(g2D);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();

  }//end constructor
  //----------------------------------------------------//

    //The purpose of this method is to test various
    // 3D aspects of the library using text.
  public void testUsingText(){
    System.out.println(
               "Test overridden toString of ColMatrix3D");
    GM01.ColMatrix3D tempA = 
                        new GM01.ColMatrix3D(1.5,2.5,3.5);
    System.out.println(tempA);
    System.out.println();
    
    System.out.println(
               "Test setData and getData of ColMatrix3D");
    tempA.setData(0,4.5);
    System.out.println(tempA.getData(0));
    tempA.setData(1,5.5);
    System.out.println(tempA.getData(1));
    tempA.setData(2,6.5);
    System.out.println(tempA.getData(2));
    System.out.println();
    
    System.out.println(
                     "Test equals method of ColMatrix3D");
    GM01.ColMatrix3D tempB = 
                        new GM01.ColMatrix3D(1.5,2.5,3.5);
    System.out.println(tempA.equals(tempB));
    tempB.setData(0,4.5);
    tempB.setData(1,5.5);
    tempB.setData(2,6.5);
    System.out.println(tempA.equals(tempB));
    System.out.println();
    
    System.out.println("Test add method of ColMatrix3D");
    System.out.println(tempA.add(tempB));
    System.out.println();
    
    System.out.println(
                   "Test subtract method of ColMatrix3D");
    System.out.println(tempA.subtract(tempB));
    System.out.println();
    
    System.out.println("Test toString method of Point3D");
    GM01.Point3D pointA = new GM01.Point3D(tempA);
    System.out.println(pointA);
    System.out.println();
    
    System.out.println(
                   "Test setData and getData of Point3D");
    pointA.setData(0,1.1);
    System.out.println(pointA.getData(0));
    pointA.setData(1,2.2);
    System.out.println(pointA.getData(1));
    pointA.setData(2,3.3);
    System.out.println(pointA.getData(2));
    System.out.println();
    
    System.out.println("Test getColMatrix of Point3D");
    System.out.println(pointA.getColMatrix());
    System.out.println();
    
    System.out.println("Test equals method of Point3D");
    GM01.Point3D pointB = new GM01.Point3D(tempB);
    System.out.println(pointA.equals(pointB));
    pointA = new GM01.Point3D(tempB);
    System.out.println(pointA.equals(pointB));
    System.out.println();
    
    //See the method named drawOffScreen for a test of
    // the draw method of the Point3D class.
    
    System.out.println(
          "Test getDisplacementVector method of Point3D");
    pointA = 
      new GM01.Point3D(new GM01.ColMatrix3D(1.5,2.5,3.5));
    System.out.println(pointA);
    System.out.println(pointB);
    System.out.println(
                    pointA.getDisplacementVector(pointB));
    System.out.println();
    
    System.out.println(
               "Test addVectorToPoint method of Point3D");
    System.out.println(pointA);
    System.out.println(pointA.addVectorToPoint(
                   new GM01.Vector3D(
                     new GM01.ColMatrix3D(5.5,6.5,7.5))));
    System.out.println();
    
    System.out.println(
                      "Test toString method of Vector3D");
    GM01.Vector3D vecA = new GM01.Vector3D(
                       new GM01.ColMatrix3D(1.5,2.5,3.5));
    System.out.println(vecA);
    System.out.println();
    
    System.out.println(
          "Test setData and getData methods of Vector3D");
    vecA.setData(0,4.5);
    System.out.println(vecA.getData(0));
    vecA.setData(1,5.5);
    System.out.println(vecA.getData(1));
    vecA.setData(2,6.5);
    System.out.println(vecA.getData(2));
    System.out.println();
    
    //See the method named drawOffScreen for a test of
    // the draw method of the Vector3D class.
    
    System.out.println(
                  "Test getColMatrix method of Vector3D");
    System.out.println(vecA.getColMatrix());
    System.out.println();
    
    System.out.println("Test equals method of Vector3D");
    GM01.Vector3D vecB = new GM01.Vector3D(
                       new GM01.ColMatrix3D(1.5,2.5,3.5));
    System.out.println(vecA.equals(vecB));
    vecB.setData(0,4.5);
    vecB.setData(1,5.5);
    vecB.setData(2,6.5);
    System.out.println(vecA.equals(vecB));
    
    System.out.println("Test add method of Vector3D");
    System.out.println(vecA);
    vecB = new GM01.Vector3D(
                      new GM01.ColMatrix3D(-1.5,2.5,3.5));
    System.out.println(vecB);
    System.out.println(vecA.add(vecB));
    System.out.println();
    
    System.out.println(
                     "Test getLength method of Vector3D");
    vecA = new GM01.Vector3D(
                       new GM01.ColMatrix3D(3.0,4.0,5.0));
    System.out.println(vecA);
    System.out.println(vecA.getLength());
    System.out.println();
    
    System.out.println("Test toString method of Line3D");
    GM01.Line3D lineA = new GM01.Line3D(pointA,pointB);
    System.out.println(lineA);
    System.out.println();
    
    System.out.println("Test setTail, setHead, getTail, "
                     + "\nand getHead methods of Line3D");
    lineA.setTail(pointB);
    lineA.setHead(pointA);
    System.out.println(lineA.getTail());
    System.out.println(lineA.getHead());
    System.out.println();
  }//end testUsingText
  //----------------------------------------------------//
  
  //The purpose of this method is to test various
  // 3D aspects of the library using graphics.
  void drawOffScreen(Graphics2D g2D){
    
    //Translate the origin on the off-screen
    // image and draw a pair of orthoganal axes on it.
    setCoordinateFrame(g2D);

    //Define eight points that define the corners of
    // a box in 3D that is centered on the origin.
    
    GM01.Point3D[] points = new GM01.Point3D[8];
    //Right side
    points[0] = 
         new GM01.Point3D(new GM01.ColMatrix3D(75,75,75));
    points[1] = 
        new GM01.Point3D(new GM01.ColMatrix3D(75,75,-75));
    points[2] = 
       new GM01.Point3D(new GM01.ColMatrix3D(75,-75,-75));
    points[3] = 
        new GM01.Point3D(new GM01.ColMatrix3D(75,-75,75));
    //Left side
    points[4] = 
        new GM01.Point3D(new GM01.ColMatrix3D(-75,75,75));
    points[5] = 
       new GM01.Point3D(new GM01.ColMatrix3D(-75,75,-75));
    points[6] = 
      new GM01.Point3D(new GM01.ColMatrix3D(-75,-75,-75));
    points[7] = 
       new GM01.Point3D(new GM01.ColMatrix3D(-75,-75,75));
       
    //Scale each of the points that define the corners of
    // the box.
    for(int cnt = 0;cnt < points.length;cnt++){
      points[cnt] = points[cnt].scale(
                     new GM01.ColMatrix3D(0.25,0.5,0.75));
    }//end for loop
    
    //Draw seven of the points in BLACK
    g2D.setColor(Color.BLACK);
    for(int cnt = 1;cnt < points.length;cnt++){
      points[cnt].draw(g2D);
    }//end for loop
    
    //Draw the right top front point in RED to identify
    // it.
    g2D.setColor(Color.RED);
    points[0].draw(g2D);
    g2D.setColor(Color.BLACK);
    
    //Draw lines that connect the points to define the
    // twelve edges of the box.
    //Right side
    new GM01.Line3D(points[0],points[1]).draw(g2D);
    new GM01.Line3D(points[1],points[2]).draw(g2D);
    new GM01.Line3D(points[2],points[3]).draw(g2D);
    new GM01.Line3D(points[3],points[0]).draw(g2D);
    
    //Left side
    new GM01.Line3D(points[4],points[5]).draw(g2D);
    new GM01.Line3D(points[5],points[6]).draw(g2D);
    new GM01.Line3D(points[6],points[7]).draw(g2D);
    new GM01.Line3D(points[7],points[4]).draw(g2D);
    
    //Front
    new GM01.Line3D(points[0],points[4]).draw(g2D);
    new GM01.Line3D(points[3],points[7]).draw(g2D);
    
    //Back
    new GM01.Line3D(points[1],points[5]).draw(g2D);
    new GM01.Line3D(points[2],points[6]).draw(g2D);

  }//end drawOffScreen
  //----------------------------------------------------//

  //This method is used to set the origin of the
  // off-screen image and to draw orthogonal 3D axes on
  // the off-screen image that intersect at the origin.
  // Points are drawn where the axes intersect the
  // surfaces of the box.
  private void setCoordinateFrame(Graphics2D g2D){

    //Translate the origin to the center.
    GM01.translate(g2D,0.5*osiWidth,-0.5*osiHeight);

    //Draw x-axis in RED. Scale the points before
    // drawing them so that they will identify the
    // locations where the axes intersect the surface
    // of the box.
    g2D.setColor(Color.RED);
    GM01.Point3D pointA = 
          new GM01.Point3D(new GM01.ColMatrix3D(-75,0,0));
    GM01.Point3D pointB = 
           new GM01.Point3D(new GM01.ColMatrix3D(75,0,0));
    pointA.scale(
            new GM01.ColMatrix3D(0.25,0.0,0.0)).draw(g2D);
    pointB.scale(
            new GM01.ColMatrix3D(0.25,0.0,0.0)).draw(g2D);
    new GM01.Line3D(pointA,pointB).draw(g2D);
    
    //Draw y-axis in GREEN
    g2D.setColor(Color.GREEN);
    pointA = 
          new GM01.Point3D(new GM01.ColMatrix3D(0,-75,0));
    pointB = 
           new GM01.Point3D(new GM01.ColMatrix3D(0,75,0));
    pointA.scale(
             new GM01.ColMatrix3D(0.0,0.5,0.0)).draw(g2D);
    pointB.scale(
             new GM01.ColMatrix3D(0.0,0.5,0.0)).draw(g2D);
    new GM01.Line3D(pointA,pointB).draw(g2D);
    
    //Draw z-axis in BLUE
    g2D.setColor(Color.BLUE);
    pointA = 
          new GM01.Point3D(new GM01.ColMatrix3D(0,0,-75));
    pointB = 
           new GM01.Point3D(new GM01.ColMatrix3D(0,0,75));
    pointA.scale(
            new GM01.ColMatrix3D(0.0,0.0,0.75)).draw(g2D);
    pointB.scale(
            new GM01.ColMatrix3D(0.0,0.0,0.75)).draw(g2D);
    new GM01.Line3D(pointA,pointB).draw(g2D);

  }//end setCoordinateFrame method
  //====================================================//
  
  
  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    //The purpose of this method is to display the
    // off-screen image on the screen.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()
    
  }//end inner class MyCanvas
    
}//end class GUI
//======================================================//
