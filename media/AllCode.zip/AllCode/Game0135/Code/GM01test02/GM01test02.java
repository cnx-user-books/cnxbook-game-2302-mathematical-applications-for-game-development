//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/18/08
//======================================================//

/*GM01test02.java 
Copyright 2008, R.G.Baldwin
Revised 02/18/08

This program tests many 2D aspects of the GM01 library
using both text and graphics.

Tested using JDK 1.6 under WinXP.
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.awt.geom.*;

class GM01test02{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class GM01test02
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 400;
  int vSize = 400;
  Image osi;//an off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas
  
  GUI(){//constructor
    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Copyright 2008,R.G.Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    //Create a new drawing canvas and add it to the
    // center of the JFrame.
    myCanvas = new MyCanvas();
    this.getContentPane().add(myCanvas);
    
    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();

    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    Graphics2D g2D = (Graphics2D)(osi.getGraphics());
    
    //Perform tests using text.
    testUsingText();
    
    //Perform tests using graphics.
    drawOffScreen(g2D);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();

  }//end constructor
  //----------------------------------------------------//
  
  //The purpose of this method is to test various
  // 2D aspects of the library using text.
  public void testUsingText(){
    System.out.println(
               "Test overridden toString of ColMatrix2D");
    GM01.ColMatrix2D tempA = 
                            new GM01.ColMatrix2D(1.5,2.5);
    System.out.println(tempA);
    System.out.println();
    
    System.out.println(
               "Test setData and getData of ColMatrix2D");
    tempA.setData(0,4.5);
    System.out.println(tempA.getData(0));
    tempA.setData(1,5.5);
    System.out.println(tempA.getData(1));
    System.out.println();
    
    System.out.println(
                     "Test equals method of ColMatrix2D");
    GM01.ColMatrix2D tempB = 
                            new GM01.ColMatrix2D(1.5,2.5);
    System.out.println(tempA.equals(tempB));
    tempB.setData(0,4.5);
    tempB.setData(1,5.5);
    System.out.println(tempA.equals(tempB));
    System.out.println();
    
    System.out.println("Test add method of ColMatrix2D");
    System.out.println(tempA.add(tempB));
    System.out.println();
    
    System.out.println(
                   "Test subtract method of ColMatrix2D");
    System.out.println(tempA.subtract(tempB));
    System.out.println();
    
    System.out.println("Test toString method of Point2D");
    GM01.Point2D pointA = new GM01.Point2D(tempA);
    System.out.println(pointA);
    System.out.println();
    
    System.out.println(
                   "Test setData and getData of Point2D");
    pointA.setData(0,1.1);
    System.out.println(pointA.getData(0));
    pointA.setData(1,2.2);
    System.out.println(pointA.getData(1));
    System.out.println();
    
    System.out.println(
                   "Test getColMatrix method of Point2D");
    System.out.println(pointA.getColMatrix());
    System.out.println();
    
    System.out.println("Test equals method of Point2D");
    GM01.Point2D pointB = new GM01.Point2D(tempB);
    System.out.println(pointA.equals(pointB));
    pointA = new GM01.Point2D(tempB);
    System.out.println(pointA.equals(pointB));
    System.out.println();
    
    System.out.println(
          "Test getDisplacementVector method of Point2D");
    pointA = 
          new GM01.Point2D(new GM01.ColMatrix2D(1.5,2.5));
    System.out.println(pointA);
    System.out.println(pointB);
    System.out.println(
                    pointA.getDisplacementVector(pointB));
    System.out.println();
    
    System.out.println(
               "Test addVectorToPoint method of Point2D");
    System.out.println(pointA);
    System.out.println(pointA.addVectorToPoint(
      new GM01.Vector2D(new GM01.ColMatrix2D(5.5,6.5))));
    System.out.println();
    
    //See the method named drawOffScreen for a test of
    // the draw method of the Point2D class.
    
    System.out.println(
                      "Test toString method of Vector2D");
    GM01.Vector2D vecA = 
         new GM01.Vector2D(new GM01.ColMatrix2D(1.5,2.5));
    System.out.println(vecA);
    System.out.println();
    
    System.out.println(
          "Test setData and getData methods of Vector2D");
    vecA.setData(0,4.5);
    System.out.println(vecA.getData(0));
    vecA.setData(1,5.5);
    System.out.println(vecA.getData(1));
    System.out.println();
    
    //See the method named drawOffScreen for a test of
    // the draw method of the Vector2D class.
    
    System.out.println(
                  "Test getColMatrix method of Vector2D");
    System.out.println(vecA.getColMatrix());
    System.out.println();
    
    System.out.println("Test equals method of Vector2D");
    GM01.Vector2D vecB = 
         new GM01.Vector2D(new GM01.ColMatrix2D(1.5,2.5));
    System.out.println(vecA.equals(vecB));
    vecB.setData(0,4.5);
    vecB.setData(1,5.5);
    System.out.println(vecA.equals(vecB));
    
    System.out.println("Test add method of Vector2D");
    System.out.println(vecA);
    vecB = 
        new GM01.Vector2D(new GM01.ColMatrix2D(-1.5,3.5));
    System.out.println(vecB);
    System.out.println(vecA.add(vecB));
    System.out.println();

    
    System.out.println(
                     "Test getLength method of Vector2D");
    vecA = 
         new GM01.Vector2D(new GM01.ColMatrix2D(3.0,4.0));
    System.out.println(vecA);
    System.out.println(vecA.getLength());
    System.out.println();

    System.out.println("Test toString method of Line2D");
    GM01.Line2D lineA = new GM01.Line2D(pointA,pointB);
    System.out.println(lineA);
    System.out.println();
    
    System.out.println("Test setTail, setHead, getTail, "
                     + "\nand getHead methods of Line2D");
    lineA.setTail(pointB);
    lineA.setHead(pointA);
    System.out.println(lineA.getTail());
    System.out.println(lineA.getHead());
    System.out.println();
    
    //See the method named drawOffScreen for a test of
    // the draw method of the Line2D class.
    
  }//end testUsingText
  //----------------------------------------------------//
  
  //The purpose of this method is test various 2D aspects
  // of the game-math library using graphics.
  void drawOffScreen(Graphics2D g2D){
    
    //Translate the origin on the off-screen
    // image and draw a pair of orthoganal axes on it.
    setCoordinateFrame(g2D);

    //Define the corners of a square in 2D that is
    // centered on the origin.
    GM01.Point2D pointA = 
           new GM01.Point2D(new GM01.ColMatrix2D(75,-75));
    GM01.Point2D pointB = 
          new GM01.Point2D(new GM01.ColMatrix2D(-75,-75));
    GM01.Point2D pointC = 
           new GM01.Point2D(new GM01.ColMatrix2D(-75,75));
    GM01.Point2D pointD = 
            new GM01.Point2D(new GM01.ColMatrix2D(75,75));

    //Draw three of the points in BLACK. Draw the fourth
    // point in RED to identify it.
    g2D.setColor(Color.BLACK);
    pointA.draw(g2D);
    pointB.draw(g2D);
    pointC.draw(g2D);
    g2D.setColor(Color.RED);
    pointD.draw(g2D);
    g2D.setColor(Color.BLACK);
    
    
    //Draw four lines connecting the points to produce
    // the outline of a square.
    GM01.Line2D lineAB = new GM01.Line2D(pointA,pointB);
    lineAB.draw(g2D);
    
    GM01.Line2D lineBC = new GM01.Line2D(pointB,pointC);
    lineBC.draw(g2D);
    
    GM01.Line2D lineCD = new GM01.Line2D(pointC,pointD);
    lineCD.draw(g2D);
    
    GM01.Line2D lineDA = new GM01.Line2D(pointD,pointA);
    lineDA.draw(g2D);    
    
    //Define a vector.
    GM01.Vector2D vecA = new GM01.Vector2D(
                            new GM01.ColMatrix2D(75,75));

    //Draw the vector with its tail at pointB. The length
    // and direction of the vector will cause its head
    // to be at the origin.
    g2D.setColor(Color.MAGENTA);
    vecA.draw(g2D,pointB);

  }//end drawOffScreen
  //----------------------------------------------------//

  //This method is used to set the origin of the
  // off-screen image and to draw orthogonal 2D axes on
  // the image that intersect at the origin.
  private void setCoordinateFrame(Graphics2D g2D){

    //Translate the origin to the center.
    GM01.translate(g2D,0.5*osiWidth,-0.5*osiHeight);

    //Draw x-axis in RED
    g2D.setColor(Color.RED);
    GM01.drawLine(g2D,-75,0,75,0);
    
    //Draw y-axis in GREEN
    g2D.setColor(Color.GREEN);
    GM01.drawLine(g2D,0,75,0,-75);

  }//end setCoordinateFrame method
  //====================================================//
  
  
  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    //The purpose of this method is to display the
    // off-screen image on the screen.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()
    
  }//end inner class MyCanvas
    
}//end class GUI
//======================================================//
