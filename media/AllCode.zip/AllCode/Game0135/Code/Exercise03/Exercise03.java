//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//Ready to publish, 02/18/08
//======================================================//

/*Exercise03.java 
Copyright 2012, R.G.Baldwin

Beginning with the two pyramids that you created in 
Exercise 2, rotate the red pyramid by -30 degrees around
an imaginary vertical line at the center of the pyramid 
as shown in Figure 22.
*********************************************************/
import java.awt.*;
import javax.swing.*;
import java.awt.geom.*;

class Exercise03{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class Exercise03
//======================================================//

class GUI extends JFrame{
  //Specify the horizontal and vertical size of a JFrame
  // object.
  int hSize = 450;
  int vSize = 450;
  Image osi;//an off-screen image
  int osiWidth;//off-screen image width
  int osiHeight;//off-screen image height
  MyCanvas myCanvas;//a subclass of Canvas
  
  GUI(){//constructor
    //Set JFrame size, title, and close operation.
    setSize(hSize,vSize);
    setTitle("Ex02,Baldwin");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    //Create a new drawing canvas and add it to the
    // center of the JFrame.
    myCanvas = new MyCanvas();
    this.getContentPane().add(myCanvas);
    
    //This object must be visible before you can get an
    // off-screen image.  It must also be visible before
    // you can compute the size of the canvas.
    setVisible(true);
    osiWidth = myCanvas.getWidth();
    osiHeight = myCanvas.getHeight();

    //Create an off-screen image and get a graphics
    // context on it.
    osi = createImage(osiWidth,osiHeight);
    Graphics2D g2D = (Graphics2D)(osi.getGraphics());
    
    //Test many 3D library features using graphics.
    drawOffScreen(g2D);

    //Cause the overridden paint method belonging to
    // myCanvas to be executed.
    myCanvas.repaint();

  }//end constructor
  //----------------------------------------------------//
  
  //The purpose of this method is to draw a 20-level 
  // stepped pyramid in black and a translated and 
  // rotated version of the pyramid in red.
  void drawOffScreen(Graphics2D g2D){
    
    //Translate the origin on the off-screen
    // image and draw a pair of orthoganal axes on it.
    setCoordinateFrame(g2D);
   
    //Define the lengths of the sides of the bottom box.
    double widthA = 100;//bottom box
    double heightA = 200;//bottom box
    double depthA = 100;//bottom box
    
    //Define the point to which all of the boxes will be
    // translated
    GM01.Point3D anchorPoint = new GM01.Point3D(
                      new GM01.ColMatrix3D(2*widthA,0,0));

    int levels = 20;
    for(int cnt = 0;cnt < levels;cnt++){
      //Process the boxes.
      //Get points for vertices
      GM01.Point3D[] points = getThePoints(
             widthA-cnt*widthA/levels,heightA/levels,
             depthA-cnt*depthA/levels,cnt*heightA/levels);
  
      //Draw the box in black
      g2D.setStroke(new BasicStroke(3));
      g2D.setColor(Color.BLACK);
      drawTheLines(points,g2D);
      
      //Translate the box to a new location.
      translateThePoints(points,anchorPoint);
      
      //Rotate the points around its vertical axis.
      rotateThePoints(points,
                      anchorPoint,
                      new GM01.ColMatrix3D(0,
                                           0,
                                           -30)
                     );
                     
      //Draw the translated and rotated box in red.
      g2D.setColor(Color.RED);
      drawTheLines(points,g2D);
    }//end for loop

  }//end drawOffScreen
  //----------------------------------------------------//

  //The purpose of this method is to translate a structure
  // defined by the points in an array of 3D points to a
  // new location.
  private void translateThePoints(
                               GM01.Point3D[] points,
                               GM01.Point3D newLocation){
    //Use a for loop to translate each point.
    for(int cnt = 0;cnt < points.length;cnt++){

      GM01.Vector3D tempVec = 
            new GM01.Vector3D(newLocation.getColMatrix());
      points[cnt] = points[cnt].addVectorToPoint(tempVec);

    }//end for loop
  }//end translateThePoints
  //----------------------------------------------------//
  
  //The purpose of this method is to rotate a structure
  // defined by the points in an array of 3D points by
  // three specified angles around a specified point in
  // 3D space.
  //Note that the incoming angles matrix contains angles
  // in the order angZ, angX, and angY.
  private void rotateThePoints(GM01.Point3D[] points,
                               GM01.Point3D anchorPoint,
                               GM01.ColMatrix3D angles){
    
    for(int cnt = 0;cnt < points.length;cnt++){

      //The following statement causes the rotation to be
      //performed.
      points[cnt] = 
                   points[cnt].rotate(anchorPoint,angles);

    }//end for loop
  }//end rotateThePoints
  //----------------------------------------------------//
  
  //The purpose of this method is to define and return
  // the eight points at the vertices of a box
  // with the edges parallel to the three axes. The
  // bottom face of the box is given by elevation.
  private GM01.Point3D[] getThePoints(double width,
                                      double height,
                                      double depth,
                                      double elevation){
    GM01.Point3D[] points = new GM01.Point3D[8];
    //Right side
    points[0] = new GM01.Point3D(new GM01.ColMatrix3D(
                                         width/2,
                                         elevation+height,
                                         depth/2));
    points[1] = new GM01.Point3D(new GM01.ColMatrix3D(
                                         width/2,
                                         elevation+height,
                                         -depth/2));
    points[2] = new GM01.Point3D(new GM01.ColMatrix3D(
                                               width/2,
                                               elevation,
                                               -depth/2));
    points[3] = new GM01.Point3D(new GM01.ColMatrix3D(
                                                width/2,
                                                elevation,
                                                depth/2));
    //Left side
    points[4] =  new GM01.Point3D(new GM01.ColMatrix3D(
                                         -width/2,
                                         elevation+height,
                                         depth/2));
    points[5] = new GM01.Point3D(new GM01.ColMatrix3D(
                                         -width/2,
                                         elevation+height,
                                         -depth/2));
    points[6] = new GM01.Point3D(new GM01.ColMatrix3D(
                                               -width/2,
                                               elevation,
                                               -depth/2));
    points[7] = new GM01.Point3D(new GM01.ColMatrix3D(
                                                -width/2,
                                                elevation,
                                                depth/2));
       
    return points;
  }//end getThePoints
  //----------------------------------------------------//
  
  //The puspose of this method is to draw twelve lines
  // that connect the eight points that define the
  // vertices of a box.
  private void drawTheLines(GM01.Point3D[] points,
                            Graphics2D g2D){
    //Draw lines that connect the points to define the
    // twelve edges of the box.
    //Right side
    new GM01.Line3D(points[0],points[1]).draw(g2D);
    new GM01.Line3D(points[1],points[2]).draw(g2D);
    new GM01.Line3D(points[2],points[3]).draw(g2D);
    new GM01.Line3D(points[3],points[0]).draw(g2D);
   
    //Left side
    new GM01.Line3D(points[4],points[5]).draw(g2D);
    new GM01.Line3D(points[5],points[6]).draw(g2D);
    new GM01.Line3D(points[6],points[7]).draw(g2D);
    new GM01.Line3D(points[7],points[4]).draw(g2D);

    //Front
    new GM01.Line3D(points[0],points[4]).draw(g2D);
    new GM01.Line3D(points[3],points[7]).draw(g2D);

    //Back
    new GM01.Line3D(points[1],points[5]).draw(g2D);
    new GM01.Line3D(points[2],points[6]).draw(g2D);

  }//end drawTheLines
  //----------------------------------------------------//
  
  //The purpose of this method is to set the origin of the
  // off-screen image such that the origin is in the lower
  // left quadrant and to draw red, green, and blue
  // orthogonal 3D axes on the off-screen image that
  // intersect at the origin.
  private void setCoordinateFrame(Graphics2D g2D){

    //Translate the origin.
    GM01.translate(g2D,0.25*osiWidth,-0.75*osiHeight);
    g2D.setStroke(new BasicStroke(2));
    //Draw x-axis in RED
    g2D.setColor(Color.RED);
    GM01.Point3D pointA = 
         new GM01.Point3D(new GM01.ColMatrix3D(-300,0,0));
    GM01.Point3D pointB = 
          new GM01.Point3D(new GM01.ColMatrix3D(300,0,0));
    new GM01.Line3D(pointA,pointB).draw(g2D);
    
    //Draw y-axis in GREEN
    g2D.setColor(Color.GREEN);
    pointA = 
         new GM01.Point3D(new GM01.ColMatrix3D(0,-300,0));
    pointB = 
          new GM01.Point3D(new GM01.ColMatrix3D(0,300,0));
    new GM01.Line3D(pointA,pointB).draw(g2D);
    
    //Draw z-axis in BLUE
    g2D.setColor(Color.BLUE);
    pointA = 
         new GM01.Point3D(new GM01.ColMatrix3D(0,0,-300));
    pointB = 
          new GM01.Point3D(new GM01.ColMatrix3D(0,0,300));
    new GM01.Line3D(pointA,pointB).draw(g2D);

  }//end setCoordinateFrame method
  //====================================================//
  
  
  //This is an inner class of the GUI class.
  class MyCanvas extends Canvas{
    //Override the paint() method. This method will be
    // called when the JFrame and the Canvas appear on the
    // screen or when the repaint method is called on the
    // Canvas object.
    //The purpose of this method is to display the
    // off-screen image on the screen.
    public void paint(Graphics g){
      g.drawImage(osi,0,0,this);
    }//end overridden paint()
    
  }//end inner class MyCanvas
    
}//end class GUI
//======================================================//
